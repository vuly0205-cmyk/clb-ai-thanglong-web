window.CLB_BASE={
"profile": {
"logo": "assets/09a9803890.jpg",
"club_name": "CLB AI THĂNG LONG",
"club_sub": "LÀM CHỦ AI-LÀM CHỦ TRI THỨC",
"hero_kicker": "SÂN CHƠI HỌC TẬP SÁNG TẠO TẠI THĂNG LONG",
"hero_line1": "Tự học",
"hero_pink": "thông minh",
"hero_line2": "cùng",
"hero_purple": "AI",
"hero_image": "assets/66b839124c.jpg",
"school": "Trường THCS&THPT Thăng Long",
"address": "Nam Ban, Lâm Hà, Lâm Đồng",
"footer_slogan": "Hiểu biết để không bị dẫn dắt.\nLàm chủ để không bị phụ thuộc.",
"members_title": "Ban chủ nhiệm CLB",
"members": [
{
"name": "Lưu Thanh huệ",
"role": "Phó chủ nhiệm",
"note": "12A2",
"photo": "assets/8d15222bbc.png"
},
{
"name": "Lê Phan Trí Nhân",
"role": "Phó chủ nhiệm",
"note": "10A3",
"photo": "assets/75334a6fa9.png"
}
]
},
"general": {
"announcement": "HỌC GIỎI HƠN, KHÔNG HỌC ÍT ĐI! · TỰ NGHĨ TRƯỚC – HỎI AI SAU",
"hero_lead": "AI có thể là gia sư 24/7, nhưng người hiểu bài, tự suy nghĩ và quyết định vẫn phải là **chính bạn.**",
"intro_text": "Lấy cảm hứng từ hoạt động giới thiệu, chia sẻ và rèn luyện kỹ năng của các CLB học sinh, chúng mình tạo thêm một không gian **học thật – làm thật – sử dụng AI có trách nhiệm.**",
"motto_title": "“Tự nghĩ trước – Hỏi AI sau”",
"motto_text": "Không cấm dùng AI. Chúng mình học cách **cầm lái**, thay vì để công nghệ lái thay.",
"join_text": "Bạn thích khám phá AI, học nhóm, thiết kế infographic hay tìm lỗi AI? Hãy tham gia CLB cùng chúng mình nhé!",
"join_how": "Liên hệ trực tiếp cô phụ trách CLB hoặc ban chủ nhiệm để đăng ký tham gia.",
"schedule": "",
"contact": "",
"links": [
{
"label": "💌 Gửi lời nhắn cho CLB",
"url": "https://padlet.com/vuly0205/hop-thu-clb-ai-thang-long-s025ju8t0nhrzq1k46ii"
},
{
"label": "🌐 Website CLB AI Thăng Long",
"url": "https://clbaithanglong.pages.dev"
},
{
"label": "📘 Fanpage CLB AI Thăng Long",
"url": "https://get-qr.com/BQtKW7"
},
{
"label": "💬 Nhóm Zalo CLB AI",
"url": "https://get-qr.com/vnb5V-"
},
{
"label": "📖 Cẩm nang điện tử",
"url": "https://get-qr.com/ifi3NK"
}
],
"qrs": [
{
"label": "Website CLB",
"url": "https://clbaithanglong.pages.dev",
"img": "assets/00afdb3e39.png"
},
{
"label": "Hộp thư lời nhắn",
"url": "https://padlet.com/vuly0205/hop-thu-clb-ai-thang-long-s025ju8t0nhrzq1k46ii",
"img": "assets/910414bb83.png"
},
{
"label": "Cẩm nang điện tử",
"url": "https://get-qr.com/ifi3NK",
"img": "assets/f977176e0a.png"
},
{
"label": "Fanpage CLB",
"url": "https://get-qr.com/BQtKW7",
"img": "assets/89405b7b3f.png"
},
{
"label": "Nhóm Zalo CLB AI",
"url": "https://get-qr.com/vnb5V-",
"img": "assets/f49f8b6b55.png"
}
]
},
"news": [
{
"date": "22/11/2026",
"title": "🏆 Kết quả bình chọn logo CLB",
"body": "Cảm ơn các bạn đã tham gia! Logo 1 và Logo 2 là 2 mẫu được yêu thích nhất. Xem chi tiết trong mục Bài viết nhé!",
"link": "#bai-viet"
}
],
"docs": [
{
"id": "d1",
"title": "Cẩm nang Tự học thông minh cùng AI",
"description": "Cẩm nang điện tử 22 trang: 5 chặng tự học, quy trình 4 bước hỏi AI, 20 câu lệnh mẫu, thử thách tự học và mục lục.",
"category": "Cẩm nang",
"url": "assets/cam-nang-tu-hoc-cung-ai.pdf",
"kind": "pdf",
"thumb": "assets/4d98541fd3.jpg"
},
{
"id": "i1",
"title": "Tự học thông minh cùng AI",
"description": "AI giúp gì, vì sao phải tự học, 3 bước dùng AI đúng.",
"category": "Infographic",
"url": "assets/13e3ac1fd2.jpg",
"kind": "image"
},
{
"id": "i2",
"title": "Dùng AI an toàn & trung thực",
"description": "AI có thể sai, mạng có thể lừa, 5 điều không đưa vào AI, mẫu khai báo.",
"category": "Infographic",
"url": "assets/6eb7885bfb.jpg",
"kind": "image"
},
{
"id": "i3",
"title": "4 bước hỏi AI thông minh",
"description": "Tự định hướng – Hỏi gợi ý – Tự làm & phản biện – Tự đánh giá.",
"category": "Infographic",
"url": "assets/00319c7692.jpg",
"kind": "image"
}
],
"stages": [
{
"icon": "💡",
"name": "AI giúp gì, hại gì?",
"short": "Biết đường, biết ổ gà",
"title": "AI là gia sư, không phải người làm hộ",
"desc": "AI có thể giải thích 24/7, giúp chia nhỏ bài và ra đề để bạn tự kiểm tra. Nhưng phụ thuộc vào lời giải sẵn sẽ khiến bạn khó làm bài khi không có AI.",
"items": [
"Nhờ AI giải thích chỗ chưa hiểu.",
"Tự làm trước, không chép bài AI viết.",
"Luôn xem lại kết quả khi không có AI."
]
},
{
"icon": "🧭",
"name": "Quy trình 4 bước",
"short": "Cách cầm lái đúng",
"title": "4 bước giúp bạn thực sự cầm lái",
"desc": "Bắt đầu bằng mục tiêu rõ ràng, tự nghĩ ít nhất 15 phút, chỉ xin gợi ý, sau đó tự làm và tự kiểm tra.",
"items": [
"Tự định hướng → Hỏi gợi ý.",
"Tự làm và nhờ AI phản biện.",
"Tự đánh giá và đối chiếu sách giáo khoa."
]
},
{
"icon": "💬",
"name": "Câu lệnh mẫu",
"short": "Hỏi đúng, AI thành thầy",
"title": "Đổi câu hỏi – đổi cách học",
"desc": "Một câu lệnh tốt nói rõ bạn đang học gì, đã làm đến đâu, cần AI hỗ trợ điều gì và nhất định không muốn AI làm hộ phần nào.",
"items": [
"Thay “Giải bài này” bằng “Gợi ý bước tiếp”.",
"Thay “Viết bài hộ” bằng “Nhận xét dàn ý của mình”.",
"Thử tạo câu lệnh trong Xưởng Prompt Lab bên dưới."
]
},
{
"icon": "🧰",
"name": "Bộ đồ nghề",
"short": "Lên lịch, ra đề, kiểm chứng",
"title": "Bộ đồ nghề của người tự học",
"desc": "Học sinh có thể nhờ AI gợi ý lịch học, ra câu hỏi tự kiểm tra và đóng vai người phản biện, nhưng phải tự lựa chọn và kiểm chứng.",
"items": [
"Lên lịch học theo điều kiện của bản thân.",
"Nhờ ra 5 câu hỏi, tự làm, tự chấm.",
"Sử dụng thẻ 3 câu kiểm chứng trước khi tin."
]
},
{
"icon": "🛡️",
"name": "An toàn & trung thực",
"short": "Lái an toàn, về đích",
"title": "Giỏi hơn phải đi cùng an toàn và trung thực",
"desc": "Không đưa dữ liệu cá nhân vào AI. Khi dùng AI hỗ trợ bài học hay sản phẩm dự thi, hãy khai báo rõ phần mình đã dùng.",
"items": [
"Không gửi mật khẩu, OTP, CCCD hoặc ảnh riêng tư.",
"Ghi rõ AI hỗ trợ phần nào; phần nào tự làm.",
"Không tin nội dung giật gân, lừa “trúng thưởng”."
]
}
],
"quiz": [
{
"q": "[Sử] AI nói: “Bác Hồ đọc Tuyên ngôn Độc lập ngày 2/9/1954.” Bạn thấy sao?",
"options": [
"Sai, phải là 1945.",
"Đúng, không có lỗi.",
"Sai, phải là 1975."
],
"ans": 0,
"explain": "Ngày 2/9/1945, tại Quảng trường Ba Đình, Chủ tịch Hồ Chí Minh đọc Tuyên ngôn Độc lập."
},
{
"q": "[Sử] AI nói: “Chiến dịch Điện Biên Phủ toàn thắng ngày 7/5/1945.” Bạn chọn gì?",
"options": [
"Sai, phải là 1954.",
"Đúng, không có lỗi.",
"Sai, phải là 1972."
],
"ans": 0,
"explain": "Chiến thắng Điện Biên Phủ ngày 7/5/1954 “lừng lẫy năm châu, chấn động địa cầu”."
},
{
"q": "[Sử] AI nói: “Miền Nam được giải phóng, đất nước thống nhất ngày 30/4/1975.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1976.",
"Sai, phải là 1973."
],
"ans": 0,
"explain": "Chính xác! Ngày 30/4/1975, Chiến dịch Hồ Chí Minh toàn thắng. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Chiến thắng Bạch Đằng năm 938 do Lý Thường Kiệt chỉ huy.” Có lỗi không?",
"options": [
"Sai, phải là Ngô Quyền.",
"Đúng, không có lỗi.",
"Sai, phải là Lê Hoàn."
],
"ans": 0,
"explain": "Năm 938, Ngô Quyền đánh tan quân Nam Hán trên sông Bạch Đằng."
},
{
"q": "[Sử] AI nói: “Năm 1010, Lý Thánh Tông dời đô từ Hoa Lư về Thăng Long.” Bạn thấy sao?",
"options": [
"Sai, phải là Lý Thái Tổ.",
"Đúng, không có lỗi.",
"Sai, phải là Trần Thái Tông."
],
"ans": 0,
"explain": "Lý Thái Tổ (Lý Công Uẩn) ban Chiếu dời đô năm 1010."
},
{
"q": "[Sử] AI nói: “Khởi nghĩa Hai Bà Trưng nổ ra vào năm 40.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 248.",
"Sai, phải là 938."
],
"ans": 0,
"explain": "Chính xác! Năm 40, Hai Bà Trưng phất cờ khởi nghĩa ở Mê Linh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Khởi nghĩa Bà Triệu nổ ra vào năm 40.” Đúng hay sai?",
"options": [
"Sai, phải là 248.",
"Đúng, không có lỗi.",
"Sai, phải là 542."
],
"ans": 0,
"explain": "Năm 248, Bà Triệu khởi nghĩa ở Cửu Chân chống quân Ngô."
},
{
"q": "[Sử] AI nói: “Nhà Trần ba lần đánh thắng quân Tống.” Có lỗi không?",
"options": [
"Sai, phải là Mông – Nguyên.",
"Đúng, không có lỗi.",
"Sai, phải là Minh."
],
"ans": 0,
"explain": "Thế kỉ XIII, quân dân nhà Trần ba lần đánh thắng quân Mông – Nguyên."
},
{
"q": "[Sử] AI nói: “Khởi nghĩa Lam Sơn do Lê Lợi lãnh đạo chống quân Minh.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Tống.",
"Sai, phải là Thanh."
],
"ans": 0,
"explain": "Chính xác! Khởi nghĩa Lam Sơn (1418–1427) đánh đuổi quân Minh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Quang Trung đại phá quân Thanh vào mùa xuân năm 1786.” Bạn chọn gì?",
"options": [
"Sai, phải là 1789.",
"Đúng, không có lỗi.",
"Sai, phải là 1802."
],
"ans": 0,
"explain": "Tết Kỷ Dậu 1789, Quang Trung đại phá quân Thanh."
},
{
"q": "[Sử] AI nói: “Đảng Cộng sản Việt Nam được thành lập năm 1945.” Đúng hay sai?",
"options": [
"Sai, phải là 1930.",
"Đúng, không có lỗi.",
"Sai, phải là 1925."
],
"ans": 0,
"explain": "Đảng Cộng sản Việt Nam thành lập ngày 3/2/1930."
},
{
"q": "[Sử] AI nói: “Nguyễn Tất Thành ra đi tìm đường cứu nước năm 1911.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1920.",
"Sai, phải là 1930."
],
"ans": 0,
"explain": "Chính xác! Ngày 5/6/1911, Nguyễn Tất Thành rời bến Nhà Rồng. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Hiệp định Giơ-ne-vơ về Đông Dương được kí năm 1973.” Bạn thấy sao?",
"options": [
"Sai, phải là 1954.",
"Đúng, không có lỗi.",
"Sai, phải là 1946."
],
"ans": 0,
"explain": "Hiệp định Giơ-ne-vơ kí năm 1954, sau chiến thắng Điện Biên Phủ."
},
{
"q": "[Sử] AI nói: “Hiệp định Pa-ri về Việt Nam được kí năm 1954.” Bạn chọn gì?",
"options": [
"Sai, phải là 1973.",
"Đúng, không có lỗi.",
"Sai, phải là 1968."
],
"ans": 0,
"explain": "Hiệp định Pa-ri được kí ngày 27/1/1973."
},
{
"q": "[Sử] AI nói: “Trận “Điện Biên Phủ trên không” diễn ra năm 1972.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1954.",
"Sai, phải là 1968."
],
"ans": 0,
"explain": "Chính xác! Cuối năm 1972, quân dân miền Bắc đánh bại cuộc tập kích B-52. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Công cuộc Đổi mới ở Việt Nam bắt đầu từ năm 1975.” Có lỗi không?",
"options": [
"Sai, phải là 1986.",
"Đúng, không có lỗi.",
"Sai, phải là 1995."
],
"ans": 0,
"explain": "Đại hội VI của Đảng (12/1986) mở đầu công cuộc Đổi mới."
},
{
"q": "[Sử] AI nói: “Việt Nam gia nhập ASEAN năm 1986.” Bạn thấy sao?",
"options": [
"Sai, phải là 1995.",
"Đúng, không có lỗi.",
"Sai, phải là 2007."
],
"ans": 0,
"explain": "Việt Nam trở thành thành viên ASEAN năm 1995."
},
{
"q": "[Sử] AI nói: “Việt Nam gia nhập WTO năm 2007.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1995.",
"Sai, phải là 2000."
],
"ans": 0,
"explain": "Chính xác! Việt Nam là thành viên WTO từ năm 2007. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Chiến tranh thế giới thứ hai kết thúc năm 1918.” Đúng hay sai?",
"options": [
"Sai, phải là 1945.",
"Đúng, không có lỗi.",
"Sai, phải là 1939."
],
"ans": 0,
"explain": "Chiến tranh thế giới thứ hai kết thúc năm 1945."
},
{
"q": "[Sử] AI nói: “Chiến tranh thế giới thứ nhất bùng nổ năm 1918.” Có lỗi không?",
"options": [
"Sai, phải là 1914.",
"Đúng, không có lỗi.",
"Sai, phải là 1939."
],
"ans": 0,
"explain": "Chiến tranh thế giới thứ nhất diễn ra từ 1914 đến 1918."
},
{
"q": "[Sử] AI nói: “Cách mạng tháng Mười Nga diễn ra năm 1917.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1905.",
"Sai, phải là 1945."
],
"ans": 0,
"explain": "Chính xác! Cách mạng tháng Mười Nga thành công năm 1917. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Liên hợp quốc được thành lập năm 1919.” Bạn chọn gì?",
"options": [
"Sai, phải là 1945.",
"Đúng, không có lỗi.",
"Sai, phải là 1955."
],
"ans": 0,
"explain": "Liên hợp quốc ra đời năm 1945."
},
{
"q": "[Sử] AI nói: “Kim tự tháp Gi-za nổi tiếng nằm ở Hy Lạp.” Đúng hay sai?",
"options": [
"Sai, phải là Ai Cập.",
"Đúng, không có lỗi.",
"Sai, phải là Ấn Độ."
],
"ans": 0,
"explain": "Kim tự tháp Gi-za là công trình nổi tiếng của Ai Cập cổ đại."
},
{
"q": "[Sử] AI nói: “Vạn Lý Trường Thành nằm ở Trung Quốc.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Nhật Bản.",
"Sai, phải là Mông Cổ."
],
"ans": 0,
"explain": "Chính xác! Vạn Lý Trường Thành là công trình nổi tiếng của Trung Quốc. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sử] AI nói: “Ngô Quyền xưng vương, đóng đô ở Cổ Loa năm 938.” Bạn thấy sao?",
"options": [
"Sai, phải là 939.",
"Đúng, không có lỗi.",
"Sai, phải là 1009."
],
"ans": 0,
"explain": "Sau chiến thắng Bạch Đằng, năm 939 Ngô Quyền xưng vương."
},
{
"q": "[Sử] AI nói: “Cách mạng tháng Tám thành công vào năm 1930.” Bạn chọn gì?",
"options": [
"Sai, phải là 1945.",
"Đúng, không có lỗi.",
"Sai, phải là 1954."
],
"ans": 0,
"explain": "Cách mạng tháng Tám thành công năm 1945."
},
{
"q": "[Địa] AI nói: “Đỉnh núi cao nhất Việt Nam là Phan Xi Păng.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Bà Đen.",
"Sai, phải là Lang Biang."
],
"ans": 0,
"explain": "Chính xác! Phan Xi Păng được gọi là “nóc nhà Đông Dương”. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Thủ đô của Việt Nam là TP. Hồ Chí Minh.” Có lỗi không?",
"options": [
"Sai, phải là Hà Nội.",
"Đúng, không có lỗi.",
"Sai, phải là Huế."
],
"ans": 0,
"explain": "Hà Nội là thủ đô của nước Việt Nam."
},
{
"q": "[Địa] AI nói: “Châu lục có diện tích lớn nhất thế giới là châu Phi.” Bạn thấy sao?",
"options": [
"Sai, phải là châu Á.",
"Đúng, không có lỗi.",
"Sai, phải là châu Mỹ."
],
"ans": 0,
"explain": "Châu Á là châu lục rộng lớn nhất."
},
{
"q": "[Địa] AI nói: “Đại dương lớn nhất thế giới là Thái Bình Dương.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Đại Tây Dương.",
"Sai, phải là Ấn Độ Dương."
],
"ans": 0,
"explain": "Chính xác! Thái Bình Dương là đại dương lớn nhất. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Hoang mạc nóng lớn nhất thế giới là Gô-bi.” Đúng hay sai?",
"options": [
"Sai, phải là Xa-ha-ra.",
"Đúng, không có lỗi.",
"Sai, phải là Ca-la-ha-ri."
],
"ans": 0,
"explain": "Hoang mạc Xa-ha-ra nằm ở Bắc Phi."
},
{
"q": "[Địa] AI nói: “Đồng bằng lớn nhất Việt Nam là đồng bằng sông Hồng.” Có lỗi không?",
"options": [
"Sai, phải là sông Cửu Long.",
"Đúng, không có lỗi.",
"Sai, phải là sông Mã."
],
"ans": 0,
"explain": "Đồng bằng sông Cửu Long rộng khoảng 40 nghìn km²."
},
{
"q": "[Địa] AI nói: “Thành phố Đà Lạt nằm trên cao nguyên Lâm Viên.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Mộc Châu.",
"Sai, phải là Kon Tum."
],
"ans": 0,
"explain": "Chính xác! Đà Lạt nằm trên cao nguyên Lâm Viên (Lang Biang). Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Quốc gia có diện tích lớn nhất thế giới là Trung Quốc.” Bạn chọn gì?",
"options": [
"Sai, phải là Nga.",
"Đúng, không có lỗi.",
"Sai, phải là Ca-na-đa."
],
"ans": 0,
"explain": "Liên bang Nga có diện tích lớn nhất thế giới."
},
{
"q": "[Địa] AI nói: “Việt Nam nằm ở khu vực Nam Á.” Đúng hay sai?",
"options": [
"Sai, phải là Đông Nam Á.",
"Đúng, không có lỗi.",
"Sai, phải là Đông Á."
],
"ans": 0,
"explain": "Việt Nam nằm ở bán đảo Đông Dương, khu vực Đông Nam Á."
},
{
"q": "[Địa] AI nói: “Vịnh Hạ Long thuộc tỉnh Quảng Ninh.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Hải Phòng.",
"Sai, phải là Thanh Hóa."
],
"ans": 0,
"explain": "Chính xác! Vịnh Hạ Long là di sản thiên nhiên thế giới ở Quảng Ninh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Trái Đất tự quay quanh trục một vòng hết khoảng 12 giờ.” Bạn thấy sao?",
"options": [
"Sai, phải là 24 giờ.",
"Đúng, không có lỗi.",
"Sai, phải là 365 ngày."
],
"ans": 0,
"explain": "Trái Đất tự quay một vòng hết khoảng 24 giờ, sinh ra ngày và đêm."
},
{
"q": "[Địa] AI nói: “Trái Đất quay quanh Mặt Trời một vòng hết khoảng 30 ngày.” Bạn chọn gì?",
"options": [
"Sai, phải là 365 ngày.",
"Đúng, không có lỗi.",
"Sai, phải là 24 giờ."
],
"ans": 0,
"explain": "Một vòng quanh Mặt Trời mất khoảng 365 ngày, tức một năm."
},
{
"q": "[Địa] AI nói: “Hành tinh gần Mặt Trời nhất là Sao Thủy.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Sao Kim.",
"Sai, phải là Sao Hỏa."
],
"ans": 0,
"explain": "Chính xác! Sao Thủy là hành tinh gần Mặt Trời nhất. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Hành tinh lớn nhất Hệ Mặt Trời là Sao Thổ.” Có lỗi không?",
"options": [
"Sai, phải là Sao Mộc.",
"Đúng, không có lỗi.",
"Sai, phải là Trái Đất."
],
"ans": 0,
"explain": "Sao Mộc là hành tinh lớn nhất Hệ Mặt Trời."
},
{
"q": "[Địa] AI nói: “Mặt Trăng quay quanh Mặt Trời.” Bạn thấy sao?",
"options": [
"Sai, phải là Trái Đất.",
"Đúng, không có lỗi.",
"Sai, phải là Sao Hỏa."
],
"ans": 0,
"explain": "Mặt Trăng là vệ tinh tự nhiên của Trái Đất."
},
{
"q": "[Địa] AI nói: “Đường Xích đạo chia Trái Đất thành bán cầu Bắc và bán cầu Nam.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Tây.",
"Sai, phải là Đông."
],
"ans": 0,
"explain": "Chính xác! Xích đạo chia Trái Đất thành bán cầu Bắc và bán cầu Nam. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Địa] AI nói: “Sông Mê Công đổ ra vịnh Thái Lan.” Đúng hay sai?",
"options": [
"Sai, phải là Biển Đông.",
"Đúng, không có lỗi.",
"Sai, phải là Ấn Độ Dương."
],
"ans": 0,
"explain": "Sông Mê Công chảy qua Việt Nam và đổ ra Biển Đông."
},
{
"q": "[Lí] AI nói: “Ở áp suất bình thường, nước sôi ở 50°C.” Có lỗi không?",
"options": [
"Sai, phải là 100°C.",
"Đúng, không có lỗi.",
"Sai, phải là 0°C."
],
"ans": 0,
"explain": "Ở áp suất bình thường, nước sôi ở 100°C."
},
{
"q": "[Lí] AI nói: “Ở áp suất bình thường, nước đông đặc ở 0°C.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 100°C.",
"Sai, phải là -10°C."
],
"ans": 0,
"explain": "Chính xác! Nước đông đặc ở 0°C. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Lí] AI nói: “Đơn vị đo lực là jun (J).” Bạn chọn gì?",
"options": [
"Sai, phải là niutơn (N).",
"Đúng, không có lỗi.",
"Sai, phải là oát (W)."
],
"ans": 0,
"explain": "Lực đo bằng niutơn (N)."
},
{
"q": "[Lí] AI nói: “Đơn vị đo cường độ dòng điện là vôn (V).” Đúng hay sai?",
"options": [
"Sai, phải là ampe (A).",
"Đúng, không có lỗi.",
"Sai, phải là ôm (Ω)."
],
"ans": 0,
"explain": "Cường độ dòng điện đo bằng ampe (A)."
},
{
"q": "[Lí] AI nói: “Đơn vị đo hiệu điện thế là vôn (V).” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là ampe (A).",
"Sai, phải là oát (W)."
],
"ans": 0,
"explain": "Chính xác! Hiệu điện thế đo bằng vôn (V). Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Lí] AI nói: “Đơn vị đo công suất là jun (J).” Bạn thấy sao?",
"options": [
"Sai, phải là oát (W).",
"Đúng, không có lỗi.",
"Sai, phải là niutơn (N)."
],
"ans": 0,
"explain": "Công suất đo bằng oát (W)."
},
{
"q": "[Lí] AI nói: “Đơn vị đo điện trở là vôn (V).” Bạn chọn gì?",
"options": [
"Sai, phải là ôm (Ω).",
"Đúng, không có lỗi.",
"Sai, phải là ampe (A)."
],
"ans": 0,
"explain": "Điện trở đo bằng ôm (Ω)."
},
{
"q": "[Lí] AI nói: “Âm thanh không truyền được trong chân không.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là nước.",
"Sai, phải là không khí."
],
"ans": 0,
"explain": "Chính xác! Âm cần môi trường rắn, lỏng hoặc khí để truyền đi. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Lí] AI nói: “Công thức tính tốc độ là v = s × t.” Có lỗi không?",
"options": [
"Sai, phải là v = s : t.",
"Đúng, không có lỗi.",
"Sai, phải là v = t : s."
],
"ans": 0,
"explain": "Tốc độ bằng quãng đường chia thời gian."
},
{
"q": "[Lí] AI nói: “Ánh sáng truyền trong chân không với tốc độ khoảng 340 m/s.” Bạn thấy sao?",
"options": [
"Sai, phải là 300 000 km/s.",
"Đúng, không có lỗi.",
"Sai, phải là 3 000 km/s."
],
"ans": 0,
"explain": "340 m/s là tốc độ âm thanh trong không khí, còn ánh sáng nhanh hơn rất nhiều."
},
{
"q": "[Lí] AI nói: “Ảnh của vật tạo bởi gương phẳng là ảnh ảo.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là ảnh thật.",
"Sai, phải là ảnh ngược."
],
"ans": 0,
"explain": "Chính xác! Gương phẳng cho ảnh ảo, lớn bằng vật. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Lí] AI nói: “Khối lượng riêng của nước khoảng 100 kg/m³.” Đúng hay sai?",
"options": [
"Sai, phải là 1000 kg/m³.",
"Đúng, không có lỗi.",
"Sai, phải là 10 000 kg/m³."
],
"ans": 0,
"explain": "1 lít nước nặng khoảng 1 kg, nên 1 m³ nước nặng khoảng 1000 kg."
},
{
"q": "[Lí] AI nói: “Trọng lực có phương thẳng đứng, chiều từ dưới lên.” Có lỗi không?",
"options": [
"Sai, phải là từ trên xuống.",
"Đúng, không có lỗi.",
"Sai, phải là nằm ngang."
],
"ans": 0,
"explain": "Trọng lực hướng về phía Trái Đất."
},
{
"q": "[Hóa] AI nói: “Công thức hóa học của nước là H₂O.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là HO₂.",
"Sai, phải là H₂O₂."
],
"ans": 0,
"explain": "Chính xác! H₂O₂ là hiđro peoxit (oxi già), không phải nước. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Hóa] AI nói: “Khí duy trì sự cháy là nitơ.” Bạn chọn gì?",
"options": [
"Sai, phải là oxi.",
"Đúng, không có lỗi.",
"Sai, phải là cacbonic."
],
"ans": 0,
"explain": "Oxi duy trì sự cháy và sự hô hấp."
},
{
"q": "[Hóa] AI nói: “Khí chiếm nhiều nhất trong không khí là oxi.” Đúng hay sai?",
"options": [
"Sai, phải là nitơ.",
"Đúng, không có lỗi.",
"Sai, phải là cacbonic."
],
"ans": 0,
"explain": "Nitơ chiếm khoảng 78% thể tích không khí."
},
{
"q": "[Hóa] AI nói: “Kí hiệu hóa học của sắt là Fe.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là S.",
"Sai, phải là Si."
],
"ans": 0,
"explain": "Chính xác! Sắt là Fe (Ferrum); S là lưu huỳnh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Hóa] AI nói: “Kí hiệu hóa học của natri là N.” Bạn thấy sao?",
"options": [
"Sai, phải là Na.",
"Đúng, không có lỗi.",
"Sai, phải là Ni."
],
"ans": 0,
"explain": "Natri là Na; N là nitơ, Ni là niken."
},
{
"q": "[Hóa] AI nói: “Kí hiệu hóa học của vàng là Ag.” Bạn chọn gì?",
"options": [
"Sai, phải là Au.",
"Đúng, không có lỗi.",
"Sai, phải là Al."
],
"ans": 0,
"explain": "Vàng là Au; Ag là bạc, Al là nhôm."
},
{
"q": "[Hóa] AI nói: “Kí hiệu hóa học của bạc là Ag.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Au.",
"Sai, phải là Ba."
],
"ans": 0,
"explain": "Chính xác! Bạc là Ag; Ba là bari. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Hóa] AI nói: “Kí hiệu hóa học của đồng là Co.” Có lỗi không?",
"options": [
"Sai, phải là Cu.",
"Đúng, không có lỗi.",
"Sai, phải là Ca."
],
"ans": 0,
"explain": "Đồng là Cu; Co là coban, Ca là canxi."
},
{
"q": "[Hóa] AI nói: “Công thức hóa học của muối ăn là KCl.” Bạn thấy sao?",
"options": [
"Sai, phải là NaCl.",
"Đúng, không có lỗi.",
"Sai, phải là NaOH."
],
"ans": 0,
"explain": "Muối ăn là natri clorua, NaCl."
},
{
"q": "[Hóa] AI nói: “Dung dịch axit làm quỳ tím chuyển sang màu đỏ.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là xanh.",
"Sai, phải là vàng."
],
"ans": 0,
"explain": "Chính xác! Axit làm quỳ tím hóa đỏ, bazơ làm quỳ tím hóa xanh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Hóa] AI nói: “Dung dịch bazơ làm quỳ tím chuyển sang màu đỏ.” Đúng hay sai?",
"options": [
"Sai, phải là xanh.",
"Đúng, không có lỗi.",
"Sai, phải là tím đậm."
],
"ans": 0,
"explain": "Bazơ làm quỳ tím hóa xanh."
},
{
"q": "[Hóa] AI nói: “Dung dịch có pH = 7 là môi trường axit.” Có lỗi không?",
"options": [
"Sai, phải là trung tính.",
"Đúng, không có lỗi.",
"Sai, phải là bazơ."
],
"ans": 0,
"explain": "pH = 7 trung tính, pH < 7 axit, pH > 7 bazơ."
},
{
"q": "[Hóa] AI nói: “Khí gây hiệu ứng nhà kính chủ yếu là CO₂.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là O₂.",
"Sai, phải là N₂."
],
"ans": 0,
"explain": "Chính xác! Khí cacbonic (CO₂) là khí nhà kính chủ yếu. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Hóa] AI nói: “Nguyên tử hiđro có số hiệu nguyên tử là 2.” Bạn chọn gì?",
"options": [
"Sai, phải là 1.",
"Đúng, không có lỗi.",
"Sai, phải là 8."
],
"ans": 0,
"explain": "Hiđro đứng đầu bảng tuần hoàn, số hiệu 1."
},
{
"q": "[Sinh] AI nói: “Cây quang hợp chủ yếu ở rễ.” Đúng hay sai?",
"options": [
"Sai, phải là lá.",
"Đúng, không có lỗi.",
"Sai, phải là hoa."
],
"ans": 0,
"explain": "Lá chứa nhiều diệp lục nên quang hợp mạnh nhất."
},
{
"q": "[Sinh] AI nói: “Cá voi thuộc nhóm thú.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là cá.",
"Sai, phải là bò sát."
],
"ans": 0,
"explain": "Chính xác! Cá voi thở bằng phổi, nuôi con bằng sữa. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sinh] AI nói: “Dơi thuộc nhóm chim.” Bạn thấy sao?",
"options": [
"Sai, phải là thú.",
"Đúng, không có lỗi.",
"Sai, phải là bò sát."
],
"ans": 0,
"explain": "Dơi là loài thú duy nhất bay được thật sự."
},
{
"q": "[Sinh] AI nói: “Tim người có 2 ngăn.” Bạn chọn gì?",
"options": [
"Sai, phải là 4.",
"Đúng, không có lỗi.",
"Sai, phải là 3."
],
"ans": 0,
"explain": "Tim người gồm 2 tâm nhĩ và 2 tâm thất."
},
{
"q": "[Sinh] AI nói: “Cơ quan lọc máu và tạo nước tiểu là thận.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là gan.",
"Sai, phải là phổi."
],
"ans": 0,
"explain": "Chính xác! Thận lọc máu và tạo thành nước tiểu. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sinh] AI nói: “Tế bào hồng cầu có chức năng chính là chống vi khuẩn.” Có lỗi không?",
"options": [
"Sai, phải là vận chuyển oxi.",
"Đúng, không có lỗi.",
"Sai, phải là làm đông máu."
],
"ans": 0,
"explain": "Hồng cầu chứa hemoglobin để vận chuyển oxi."
},
{
"q": "[Sinh] AI nói: “Tế bào sinh dưỡng của người có 48 nhiễm sắc thể.” Bạn thấy sao?",
"options": [
"Sai, phải là 46.",
"Đúng, không có lỗi.",
"Sai, phải là 44."
],
"ans": 0,
"explain": "Người có 46 NST, tức 23 cặp."
},
{
"q": "[Sinh] AI nói: “Phân tử ADN có cấu trúc xoắn kép.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là mạch đơn.",
"Sai, phải là hình cầu."
],
"ans": 0,
"explain": "Chính xác! ADN gồm hai mạch xoắn song song. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sinh] AI nói: “Đơn vị cấu tạo cơ bản của cơ thể sống là mô.” Đúng hay sai?",
"options": [
"Sai, phải là tế bào.",
"Đúng, không có lỗi.",
"Sai, phải là cơ quan."
],
"ans": 0,
"explain": "Mọi cơ thể sống đều được cấu tạo từ tế bào."
},
{
"q": "[Sinh] AI nói: “Bào quan thực hiện quang hợp là ti thể.” Có lỗi không?",
"options": [
"Sai, phải là lục lạp.",
"Đúng, không có lỗi.",
"Sai, phải là ribôxôm."
],
"ans": 0,
"explain": "Lục lạp chứa diệp lục, nơi diễn ra quang hợp."
},
{
"q": "[Sinh] AI nói: “Bào quan thực hiện hô hấp tế bào là ti thể.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là lục lạp.",
"Sai, phải là nhân."
],
"ans": 0,
"explain": "Chính xác! Ti thể là “nhà máy năng lượng” của tế bào. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sinh] AI nói: “Ếch thuộc lớp bò sát.” Bạn chọn gì?",
"options": [
"Sai, phải là lưỡng cư.",
"Đúng, không có lỗi.",
"Sai, phải là cá."
],
"ans": 0,
"explain": "Ếch vừa sống dưới nước vừa sống trên cạn: lưỡng cư."
},
{
"q": "[Sinh] AI nói: “Rắn thuộc lớp lưỡng cư.” Đúng hay sai?",
"options": [
"Sai, phải là bò sát.",
"Đúng, không có lỗi.",
"Sai, phải là thú."
],
"ans": 0,
"explain": "Rắn là bò sát, da khô có vảy sừng."
},
{
"q": "[Sinh] AI nói: “Khi quang hợp, cây hấp thụ khí cacbonic.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là oxi.",
"Sai, phải là nitơ."
],
"ans": 0,
"explain": "Chính xác! Cây lấy CO₂ và thải ra O₂ khi quang hợp. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Sinh] AI nói: “Da tiếp xúc ánh nắng nhẹ giúp cơ thể tổng hợp vitamin C.” Bạn thấy sao?",
"options": [
"Sai, phải là D.",
"Đúng, không có lỗi.",
"Sai, phải là A."
],
"ans": 0,
"explain": "Ánh nắng sáng sớm giúp cơ thể tạo vitamin D."
},
{
"q": "[Toán] AI nói: “5 × 8 = 45.” Bạn chọn gì?",
"options": [
"Sai, phải là 40.",
"Đúng, không có lỗi.",
"Sai, phải là 48."
],
"ans": 0,
"explain": "5 × 8 = 40."
},
{
"q": "[Toán] AI nói: “7 × 8 = 56.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 54.",
"Sai, phải là 64."
],
"ans": 0,
"explain": "Chính xác! 7 × 8 = 56. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “9 × 7 = 56.” Có lỗi không?",
"options": [
"Sai, phải là 63.",
"Đúng, không có lỗi.",
"Sai, phải là 72."
],
"ans": 0,
"explain": "9 × 7 = 63."
},
{
"q": "[Toán] AI nói: “12 × 12 = 124.” Bạn thấy sao?",
"options": [
"Sai, phải là 144.",
"Đúng, không có lỗi.",
"Sai, phải là 142."
],
"ans": 0,
"explain": "12 × 12 = 144."
},
{
"q": "[Toán] AI nói: “Căn bậc hai của 81 là 9.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 8.",
"Sai, phải là 18."
],
"ans": 0,
"explain": "Chính xác! 9 × 9 = 81, nên √81 = 9. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “Tổng ba góc trong một tam giác bằng 360°.” Đúng hay sai?",
"options": [
"Sai, phải là 180°.",
"Đúng, không có lỗi.",
"Sai, phải là 90°."
],
"ans": 0,
"explain": "Tổng ba góc của tam giác luôn bằng 180°."
},
{
"q": "[Toán] AI nói: “Tổng bốn góc trong một tứ giác bằng 180°.” Có lỗi không?",
"options": [
"Sai, phải là 360°.",
"Đúng, không có lỗi.",
"Sai, phải là 270°."
],
"ans": 0,
"explain": "Tổng các góc của tứ giác bằng 360°."
},
{
"q": "[Toán] AI nói: “Số π (pi) có giá trị xấp xỉ 3,14.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 2,14.",
"Sai, phải là 3,41."
],
"ans": 0,
"explain": "Chính xác! π ≈ 3,14159… Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “1 km bằng 100 m.” Bạn chọn gì?",
"options": [
"Sai, phải là 1000 m.",
"Đúng, không có lỗi.",
"Sai, phải là 10 000 m."
],
"ans": 0,
"explain": "1 km = 1000 m."
},
{
"q": "[Toán] AI nói: “1 tấn bằng 100 kg.” Đúng hay sai?",
"options": [
"Sai, phải là 1000 kg.",
"Đúng, không có lỗi.",
"Sai, phải là 10 kg."
],
"ans": 0,
"explain": "1 tấn = 1000 kg; 1 tạ = 100 kg."
},
{
"q": "[Toán] AI nói: “Số nguyên tố nhỏ nhất là 2.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1.",
"Sai, phải là 0."
],
"ans": 0,
"explain": "Chính xác! Số 1 và 0 không phải số nguyên tố; 2 là số nguyên tố nhỏ nhất. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “2³ bằng 6.” Bạn thấy sao?",
"options": [
"Sai, phải là 8.",
"Đúng, không có lỗi.",
"Sai, phải là 9."
],
"ans": 0,
"explain": "2³ = 2 × 2 × 2 = 8."
},
{
"q": "[Toán] AI nói: “Diện tích hình vuông cạnh a là 4a.” Bạn chọn gì?",
"options": [
"Sai, phải là a².",
"Đúng, không có lỗi.",
"Sai, phải là 2a."
],
"ans": 0,
"explain": "4a là chu vi, còn diện tích là a × a = a²."
},
{
"q": "[Toán] AI nói: “Chu vi hình tròn bán kính r là 2πr.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là πr².",
"Sai, phải là πr."
],
"ans": 0,
"explain": "Chính xác! πr² là diện tích; chu vi là 2πr. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “Diện tích hình tròn bán kính r là 2πr.” Có lỗi không?",
"options": [
"Sai, phải là πr².",
"Đúng, không có lỗi.",
"Sai, phải là 2πr²."
],
"ans": 0,
"explain": "Diện tích hình tròn S = πr²."
},
{
"q": "[Toán] AI nói: “25% của 200 là 25.” Bạn thấy sao?",
"options": [
"Sai, phải là 50.",
"Đúng, không có lỗi.",
"Sai, phải là 75."
],
"ans": 0,
"explain": "25% = 1/4; 200 : 4 = 50."
},
{
"q": "[Toán] AI nói: “0,5 bằng phân số 1/2.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1/5.",
"Sai, phải là 2/5."
],
"ans": 0,
"explain": "Chính xác! 0,5 = 5/10 = 1/2. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “sin 30° bằng √3/2.” Đúng hay sai?",
"options": [
"Sai, phải là 1/2.",
"Đúng, không có lỗi.",
"Sai, phải là 1."
],
"ans": 0,
"explain": "sin 30° = 1/2; cos 30° = √3/2."
},
{
"q": "[Toán] AI nói: “1 giờ có 100 phút.” Có lỗi không?",
"options": [
"Sai, phải là 60 phút.",
"Đúng, không có lỗi.",
"Sai, phải là 30 phút."
],
"ans": 0,
"explain": "1 giờ = 60 phút = 3600 giây."
},
{
"q": "[Toán] AI nói: “Một năm nhuận có 366 ngày.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 365 ngày.",
"Sai, phải là 360 ngày."
],
"ans": 0,
"explain": "Chính xác! Năm nhuận có 366 ngày, tháng 2 có 29 ngày. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Toán] AI nói: “Trong tam giác vuông, bình phương cạnh huyền bằng tổng hai cạnh góc vuông.” Bạn chọn gì?",
"options": [
"Sai, phải là tổng bình phương hai cạnh góc vuông.",
"Đúng, không có lỗi.",
"Sai, phải là hiệu bình phương hai cạnh góc vuông."
],
"ans": 0,
"explain": "Đó là định lí Pi-ta-go: a² + b² = c²."
},
{
"q": "[Anh] AI nói: “Từ “happy” nghĩa là buồn bã.” Đúng hay sai?",
"options": [
"Sai, phải là vui vẻ.",
"Đúng, không có lỗi.",
"Sai, phải là mệt mỏi."
],
"ans": 0,
"explain": "“Happy” = vui vẻ, hạnh phúc."
},
{
"q": "[Anh] AI nói: “Từ “library” nghĩa là thư viện.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là hiệu sách.",
"Sai, phải là phòng thí nghiệm."
],
"ans": 0,
"explain": "Chính xác! “Library” = thư viện; “bookshop” mới là hiệu sách. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Anh] AI nói: “Từ “teacher” nghĩa là học sinh.” Bạn thấy sao?",
"options": [
"Sai, phải là giáo viên.",
"Đúng, không có lỗi.",
"Sai, phải là bác sĩ."
],
"ans": 0,
"explain": "“Teacher” = giáo viên."
},
{
"q": "[Anh] AI nói: “Quá khứ của động từ “go” là goed.” Bạn chọn gì?",
"options": [
"Sai, phải là went.",
"Đúng, không có lỗi.",
"Sai, phải là goes."
],
"ans": 0,
"explain": "go – went – gone."
},
{
"q": "[Anh] AI nói: “Quá khứ của động từ “eat” là ate.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là eated.",
"Sai, phải là eats."
],
"ans": 0,
"explain": "Chính xác! eat – ate – eaten. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Anh] AI nói: “Số nhiều của “child” là childs.” Có lỗi không?",
"options": [
"Sai, phải là children.",
"Đúng, không có lỗi.",
"Sai, phải là childes."
],
"ans": 0,
"explain": "child → children (bất quy tắc)."
},
{
"q": "[Anh] AI nói: “Số nhiều của “mouse” là mouses.” Bạn thấy sao?",
"options": [
"Sai, phải là mice.",
"Đúng, không có lỗi.",
"Sai, phải là mices."
],
"ans": 0,
"explain": "mouse → mice (bất quy tắc)."
},
{
"q": "[Anh] AI nói: “Từ trái nghĩa với “hot” là cold.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là warm.",
"Sai, phải là big."
],
"ans": 0,
"explain": "Chính xác! hot (nóng) ↔ cold (lạnh). Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Anh] AI nói: “So sánh hơn của “good” là gooder.” Đúng hay sai?",
"options": [
"Sai, phải là better.",
"Đúng, không có lỗi.",
"Sai, phải là best."
],
"ans": 0,
"explain": "good – better – best."
},
{
"q": "[Anh] AI nói: “So sánh nhất của “bad” là baddest.” Có lỗi không?",
"options": [
"Sai, phải là worst.",
"Đúng, không có lỗi.",
"Sai, phải là worse."
],
"ans": 0,
"explain": "bad – worse – worst."
},
{
"q": "[Anh] AI nói: “Câu đúng: “She ___ to school every day.” Từ cần điền là goes.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là go.",
"Sai, phải là going."
],
"ans": 0,
"explain": "Chính xác! Chủ ngữ số ít (she) ở thì hiện tại đơn: động từ thêm -es. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Anh] AI nói: ““Monday” là Chủ nhật.” Bạn chọn gì?",
"options": [
"Sai, phải là thứ Hai.",
"Đúng, không có lỗi.",
"Sai, phải là thứ Ba."
],
"ans": 0,
"explain": "Monday = thứ Hai; Sunday = Chủ nhật."
},
{
"q": "[Anh] AI nói: “Số “twelve” là 20.” Đúng hay sai?",
"options": [
"Sai, phải là 12.",
"Đúng, không có lỗi.",
"Sai, phải là 11."
],
"ans": 0,
"explain": "twelve = 12; twenty = 20; eleven = 11."
},
{
"q": "[Anh] AI nói: “Từ “beautiful” nghĩa là xinh đẹp.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là to lớn.",
"Sai, phải là xấu xí."
],
"ans": 0,
"explain": "Chính xác! “Beautiful” = xinh đẹp. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Anh] AI nói: “Quá khứ của động từ “buy” là buyed.” Bạn thấy sao?",
"options": [
"Sai, phải là bought.",
"Đúng, không có lỗi.",
"Sai, phải là brought."
],
"ans": 0,
"explain": "buy – bought; “brought” là quá khứ của “bring”."
},
{
"q": "[Văn] AI nói: ““Truyện Kiều” là tác phẩm của Nguyễn Trãi.” Bạn chọn gì?",
"options": [
"Sai, phải là Nguyễn Du.",
"Đúng, không có lỗi.",
"Sai, phải là Hồ Xuân Hương."
],
"ans": 0,
"explain": "“Truyện Kiều” (Đoạn trường tân thanh) của Nguyễn Du."
},
{
"q": "[Văn] AI nói: ““Bình Ngô đại cáo” là tác phẩm của Nguyễn Trãi.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Lý Thường Kiệt.",
"Sai, phải là Trần Quốc Tuấn."
],
"ans": 0,
"explain": "Chính xác! Nguyễn Trãi viết “Bình Ngô đại cáo” năm 1428. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: ““Hịch tướng sĩ” là tác phẩm của Nguyễn Trãi.” Có lỗi không?",
"options": [
"Sai, phải là Trần Quốc Tuấn.",
"Đúng, không có lỗi.",
"Sai, phải là Lê Lợi."
],
"ans": 0,
"explain": "Trần Quốc Tuấn (Hưng Đạo Vương) viết “Hịch tướng sĩ”."
},
{
"q": "[Văn] AI nói: ““Nhật kí trong tù” là tập thơ của Tố Hữu.” Bạn thấy sao?",
"options": [
"Sai, phải là Hồ Chí Minh.",
"Đúng, không có lỗi.",
"Sai, phải là Xuân Diệu."
],
"ans": 0,
"explain": "Tập thơ chữ Hán “Nhật kí trong tù” của Hồ Chí Minh."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Lão Hạc” là của Nam Cao.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Ngô Tất Tố.",
"Sai, phải là Kim Lân."
],
"ans": 0,
"explain": "Chính xác! “Lão Hạc” của Nam Cao. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Tiểu thuyết “Tắt đèn” là của Nam Cao.” Đúng hay sai?",
"options": [
"Sai, phải là Ngô Tất Tố.",
"Đúng, không có lỗi.",
"Sai, phải là Nguyên Hồng."
],
"ans": 0,
"explain": "“Tắt đèn” của Ngô Tất Tố, có đoạn “Tức nước vỡ bờ”."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Vợ nhặt” là của Tô Hoài.” Có lỗi không?",
"options": [
"Sai, phải là Kim Lân.",
"Đúng, không có lỗi.",
"Sai, phải là Nam Cao."
],
"ans": 0,
"explain": "“Vợ nhặt” của Kim Lân."
},
{
"q": "[Văn] AI nói: “Truyện “Vợ chồng A Phủ” là của Tô Hoài.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Kim Lân.",
"Sai, phải là Nguyễn Tuân."
],
"ans": 0,
"explain": "Chính xác! “Vợ chồng A Phủ” của Tô Hoài. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: ““Dế Mèn phiêu lưu kí” là của Võ Quảng.” Bạn chọn gì?",
"options": [
"Sai, phải là Tô Hoài.",
"Đúng, không có lỗi.",
"Sai, phải là Nam Cao."
],
"ans": 0,
"explain": "“Dế Mèn phiêu lưu kí” của Tô Hoài."
},
{
"q": "[Văn] AI nói: “Bài thơ “Tây Tiến” là của Tố Hữu.” Đúng hay sai?",
"options": [
"Sai, phải là Quang Dũng.",
"Đúng, không có lỗi.",
"Sai, phải là Chính Hữu."
],
"ans": 0,
"explain": "“Tây Tiến” của Quang Dũng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Đồng chí” là của Chính Hữu.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Quang Dũng.",
"Sai, phải là Phạm Tiến Duật."
],
"ans": 0,
"explain": "Chính xác! “Đồng chí” của Chính Hữu. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Việt Bắc” là của Chế Lan Viên.” Bạn thấy sao?",
"options": [
"Sai, phải là Tố Hữu.",
"Đúng, không có lỗi.",
"Sai, phải là Huy Cận."
],
"ans": 0,
"explain": "“Việt Bắc” của Tố Hữu."
},
{
"q": "[Văn] AI nói: “Bài thơ “Sóng” là của Xuân Diệu.” Bạn chọn gì?",
"options": [
"Sai, phải là Xuân Quỳnh.",
"Đúng, không có lỗi.",
"Sai, phải là Hồ Xuân Hương."
],
"ans": 0,
"explain": "“Sóng” của Xuân Quỳnh."
},
{
"q": "[Văn] AI nói: “Bài thơ “Vội vàng” là của Xuân Diệu.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Xuân Quỳnh.",
"Sai, phải là Huy Cận."
],
"ans": 0,
"explain": "Chính xác! “Vội vàng” của Xuân Diệu. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Tràng giang” là của Xuân Diệu.” Có lỗi không?",
"options": [
"Sai, phải là Huy Cận.",
"Đúng, không có lỗi.",
"Sai, phải là Hàn Mặc Tử."
],
"ans": 0,
"explain": "“Tràng giang” của Huy Cận."
},
{
"q": "[Văn] AI nói: “Bài thơ “Đây thôn Vĩ Dạ” là của Huy Cận.” Bạn thấy sao?",
"options": [
"Sai, phải là Hàn Mặc Tử.",
"Đúng, không có lỗi.",
"Sai, phải là Nguyễn Bính."
],
"ans": 0,
"explain": "“Đây thôn Vĩ Dạ” của Hàn Mặc Tử."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Chí Phèo” là của Nam Cao.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Vũ Trọng Phụng.",
"Sai, phải là Ngô Tất Tố."
],
"ans": 0,
"explain": "Chính xác! “Chí Phèo” của Nam Cao. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Tiểu thuyết “Số đỏ” là của Nam Cao.” Đúng hay sai?",
"options": [
"Sai, phải là Vũ Trọng Phụng.",
"Đúng, không có lỗi.",
"Sai, phải là Nguyễn Công Hoan."
],
"ans": 0,
"explain": "“Số đỏ” của Vũ Trọng Phụng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Bánh trôi nước” là của Bà Huyện Thanh Quan.” Có lỗi không?",
"options": [
"Sai, phải là Hồ Xuân Hương.",
"Đúng, không có lỗi.",
"Sai, phải là Đoàn Thị Điểm."
],
"ans": 0,
"explain": "“Bánh trôi nước” của Hồ Xuân Hương."
},
{
"q": "[Văn] AI nói: “Bài thơ “Qua Đèo Ngang” là của Bà Huyện Thanh Quan.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Hồ Xuân Hương.",
"Sai, phải là Nguyễn Khuyến."
],
"ans": 0,
"explain": "Chính xác! “Qua Đèo Ngang” của Bà Huyện Thanh Quan. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Bạn đến chơi nhà” là của Nguyễn Du.” Bạn chọn gì?",
"options": [
"Sai, phải là Nguyễn Khuyến.",
"Đúng, không có lỗi.",
"Sai, phải là Nguyễn Trãi."
],
"ans": 0,
"explain": "“Bạn đến chơi nhà” của Nguyễn Khuyến."
},
{
"q": "[Văn] AI nói: ““Bài thơ về tiểu đội xe không kính” là của Chính Hữu.” Đúng hay sai?",
"options": [
"Sai, phải là Phạm Tiến Duật.",
"Đúng, không có lỗi.",
"Sai, phải là Tố Hữu."
],
"ans": 0,
"explain": "Tác giả là Phạm Tiến Duật."
},
{
"q": "[Văn] AI nói: “Bài thơ “Ánh trăng” là của Nguyễn Duy.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Thanh Hải.",
"Sai, phải là Viễn Phương."
],
"ans": 0,
"explain": "Chính xác! “Ánh trăng” của Nguyễn Duy. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Mùa xuân nho nhỏ” là của Viễn Phương.” Bạn thấy sao?",
"options": [
"Sai, phải là Thanh Hải.",
"Đúng, không có lỗi.",
"Sai, phải là Nguyễn Duy."
],
"ans": 0,
"explain": "“Mùa xuân nho nhỏ” của Thanh Hải."
},
{
"q": "[Văn] AI nói: “Bài thơ “Viếng lăng Bác” là của Thanh Hải.” Bạn chọn gì?",
"options": [
"Sai, phải là Viễn Phương.",
"Đúng, không có lỗi.",
"Sai, phải là Tố Hữu."
],
"ans": 0,
"explain": "“Viếng lăng Bác” của Viễn Phương."
},
{
"q": "[Văn] AI nói: “Bài thơ “Sang thu” là của Hữu Thỉnh.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Huy Cận.",
"Sai, phải là Nguyễn Duy."
],
"ans": 0,
"explain": "Chính xác! “Sang thu” của Hữu Thỉnh. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Bài thơ “Đoàn thuyền đánh cá” là của Hữu Thỉnh.” Có lỗi không?",
"options": [
"Sai, phải là Huy Cận.",
"Đúng, không có lỗi.",
"Sai, phải là Xuân Diệu."
],
"ans": 0,
"explain": "“Đoàn thuyền đánh cá” của Huy Cận."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Chiếc lược ngà” là của Nguyễn Thành Long.” Bạn thấy sao?",
"options": [
"Sai, phải là Nguyễn Quang Sáng.",
"Đúng, không có lỗi.",
"Sai, phải là Kim Lân."
],
"ans": 0,
"explain": "“Chiếc lược ngà” của Nguyễn Quang Sáng."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Lặng lẽ Sa Pa” là của Nguyễn Thành Long.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Nguyễn Quang Sáng.",
"Sai, phải là Nguyễn Tuân."
],
"ans": 0,
"explain": "Chính xác! “Lặng lẽ Sa Pa” của Nguyễn Thành Long. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Văn] AI nói: “Truyện ngắn “Làng” là của Nam Cao.” Đúng hay sai?",
"options": [
"Sai, phải là Kim Lân.",
"Đúng, không có lỗi.",
"Sai, phải là Tô Hoài."
],
"ans": 0,
"explain": "“Làng” của Kim Lân, nhân vật ông Hai."
},
{
"q": "[Tin] AI nói: “1 byte bằng 10 bit.” Có lỗi không?",
"options": [
"Sai, phải là 8 bit.",
"Đúng, không có lỗi.",
"Sai, phải là 16 bit."
],
"ans": 0,
"explain": "1 byte = 8 bit."
},
{
"q": "[Tin] AI nói: “Hệ nhị phân chỉ dùng hai chữ số 0 và 1.” Bạn thấy sao?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là 1 và 2.",
"Sai, phải là 0 và 9."
],
"ans": 0,
"explain": "Chính xác! Máy tính lưu dữ liệu bằng các số 0 và 1. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Tin] AI nói: “Bàn phím là thiết bị ra (xuất).” Bạn chọn gì?",
"options": [
"Sai, phải là vào (nhập).",
"Đúng, không có lỗi.",
"Sai, phải là lưu trữ."
],
"ans": 0,
"explain": "Bàn phím, chuột là thiết bị vào; màn hình, loa là thiết bị ra."
},
{
"q": "[Tin] AI nói: “Máy in là thiết bị vào (nhập).” Đúng hay sai?",
"options": [
"Sai, phải là ra (xuất).",
"Đúng, không có lỗi.",
"Sai, phải là xử lí."
],
"ans": 0,
"explain": "Máy in đưa thông tin ra giấy: thiết bị ra."
},
{
"q": "[Tin] AI nói: “Python là ngôn ngữ lập trình.” Có lỗi không?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là hệ điều hành.",
"Sai, phải là trình duyệt web."
],
"ans": 0,
"explain": "Chính xác! Python là ngôn ngữ lập trình phổ biến. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Tin] AI nói: “Windows là trình duyệt web.” Bạn thấy sao?",
"options": [
"Sai, phải là hệ điều hành.",
"Đúng, không có lỗi.",
"Sai, phải là phần mềm soạn thảo."
],
"ans": 0,
"explain": "Windows là hệ điều hành; Chrome là trình duyệt."
},
{
"q": "[Tin] AI nói: “Google Chrome là hệ điều hành.” Bạn chọn gì?",
"options": [
"Sai, phải là trình duyệt web.",
"Đúng, không có lỗi.",
"Sai, phải là ngôn ngữ lập trình."
],
"ans": 0,
"explain": "Chrome dùng để truy cập các trang web."
},
{
"q": "[Tin] AI nói: “Phím tắt sao chép (copy) là Ctrl + C.” Đúng hay sai?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là Ctrl + V.",
"Sai, phải là Ctrl + X."
],
"ans": 0,
"explain": "Chính xác! Ctrl + C sao chép, Ctrl + V dán, Ctrl + X cắt. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Tin] AI nói: “Phím tắt dán (paste) là Ctrl + C.” Có lỗi không?",
"options": [
"Sai, phải là Ctrl + V.",
"Đúng, không có lỗi.",
"Sai, phải là Ctrl + Z."
],
"ans": 0,
"explain": "Ctrl + V dùng để dán."
},
{
"q": "[Tin] AI nói: “Phím tắt hoàn tác (undo) là Ctrl + Y.” Bạn thấy sao?",
"options": [
"Sai, phải là Ctrl + Z.",
"Đúng, không có lỗi.",
"Sai, phải là Ctrl + A."
],
"ans": 0,
"explain": "Ctrl + Z hoàn tác thao tác vừa làm."
},
{
"q": "[Tin] AI nói: “CPU là bộ xử lí trung tâm.” Bạn chọn gì?",
"options": [
"Đúng, không có lỗi.",
"Sai, phải là bộ nhớ ngoài.",
"Sai, phải là thiết bị nhập."
],
"ans": 0,
"explain": "Chính xác! CPU (Central Processing Unit) là bộ xử lí trung tâm. Không phải câu nào AI nói cũng sai – quan trọng là biết kiểm chứng."
},
{
"q": "[Tình huống] AI đưa một đường link làm nguồn, bấm vào thì trang không tồn tại. Vì sao?",
"options": [
"AI có thể bịa ra nguồn.",
"Do mạng yếu, cứ tin AI.",
"Trang bị xóa, vẫn tin được."
],
"ans": 0,
"explain": "AI có thể “bịa” cả tên sách, bài báo, đường link. Hãy tự tìm lại nguồn thật."
},
{
"q": "[Tình huống] AI trả lời rất tự tin, giọng chắc chắn. Điều đó có nghĩa là gì?",
"options": [
"Tự tin chưa chắc đã đúng.",
"Câu trả lời chắc chắn đúng.",
"AI không bao giờ nhầm lẫn."
],
"ans": 0,
"explain": "AI có thể nói sai bằng giọng rất tự tin. Hãy kiểm chứng trước khi tin."
},
{
"q": "[Tình huống] Bạn thấy ảnh “cá voi bay trên trời” lan truyền trên mạng. Bạn nên làm gì?",
"options": [
"Nghi ảnh do AI tạo, tìm nguồn.",
"Chia sẻ ngay vì quá lạ.",
"Tin ngay vì ảnh rất thật."
],
"ans": 0,
"explain": "AI tạo ảnh giả rất giống thật. Tìm nguồn chính thống trước khi chia sẻ."
},
{
"q": "[Tình huống] Có video giọng thầy hiệu trưởng báo “mai được nghỉ học”. Bạn nên làm gì?",
"options": [
"Hỏi lại qua kênh của trường.",
"Báo cả lớp nghỉ học luôn.",
"Chia sẻ lên mạng cho nhanh."
],
"ans": 0,
"explain": "AI có thể giả giọng, giả mặt. Hãy kiểm tra qua thông báo chính thức."
},
{
"q": "[Tình huống] Tin nhắn báo: “Bạn trúng iPhone, gửi mã OTP để nhận quà.” Bạn sẽ…",
"options": [
"Không gửi, báo người lớn.",
"Gửi mã để nhận quà nhanh.",
"Gửi ảnh chụp mã cho họ."
],
"ans": 0,
"explain": "OTP, mật khẩu là “chìa khóa” tài khoản. Không bao giờ gửi cho người lạ."
},
{
"q": "[Tình huống] Bạn muốn nhờ AI điền hồ sơ. Có nên gửi ảnh CCCD cho AI không?",
"options": [
"Không, giữ kín thông tin.",
"Có, AI sẽ giữ bí mật.",
"Có, nếu AI hỏi lịch sự."
],
"ans": 0,
"explain": "Không đưa CCCD, địa chỉ, mật khẩu, ảnh riêng tư vào AI."
},
{
"q": "[Tình huống] Làm bài tập về nhà, cách dùng AI nào là đúng?",
"options": [
"Tự làm trước, bí mới hỏi gợi ý.",
"Chụp đề, chép lời giải AI.",
"Nhờ AI làm, rồi học thuộc."
],
"ans": 0,
"explain": "Luật 15 phút: tự nghĩ trước, chỉ xin gợi ý khi bí."
},
{
"q": "[Tình huống] Câu lệnh nào giúp bạn ôn bài tốt nhất?",
"options": [
"“Hỏi mình 5 câu, chờ mình trả lời.”",
"“Tóm tắt hết bài cho mình chép.”",
"“Cho mình đáp án đề kiểm tra.”"
],
"ans": 0,
"explain": "Tự trả lời rồi được chấm giúp nhớ lâu hơn đọc lời giải sẵn."
},
{
"q": "[Tình huống] Bạn nhờ AI sửa lỗi chính tả bài văn. Khi nộp bài, bạn nên…",
"options": [
"Ghi rõ AI giúp sửa chính tả.",
"Không nói gì với thầy cô.",
"Nói là tự làm toàn bộ."
],
"ans": 0,
"explain": "Khai báo phần AI hỗ trợ là trung thực và có trách nhiệm."
},
{
"q": "[Tình huống] Đọc lời giải AI thấy hiểu ngay. Vậy bạn đã tự làm được bài chưa?",
"options": [
"Chưa chắc, phải tự làm lại.",
"Rồi, đọc hiểu là đủ.",
"Rồi, vì AI giảng dễ hiểu."
],
"ans": 0,
"explain": "Gấp lời giải và tự làm lại. Làm lại được mới là hiểu thật."
},
{
"q": "[Tình huống] Bài nộp còn dòng chữ “chatgpt.com” ở cuối. Điều đó cho thấy gì?",
"options": [
"Bài có thể do AI làm hộ.",
"Bài được viết rất cẩn thận.",
"Bạn ấy giỏi tin học."
],
"ans": 0,
"explain": "Đây là “dấu vết” thường gặp khi chép nguyên văn từ AI."
},
{
"q": "[Tình huống] Thầy hỏi “em giải thích bước này đi” mà bạn không trả lời được. Vì sao?",
"options": [
"Bạn chưa thật sự hiểu bài.",
"Thầy hỏi quá khó.",
"Bạn bị mất tập trung."
],
"ans": 0,
"explain": "Nếu chép lời giải AI, ta không hiểu nên không giải thích được."
},
{
"q": "[Tình huống] Khi AI đưa ra con số thống kê, bạn nên làm gì?",
"options": [
"Tìm nguồn gốc của con số.",
"Dùng luôn vì rất cụ thể.",
"Làm tròn cho đẹp rồi dùng."
],
"ans": 0,
"explain": "Con số càng cụ thể càng dễ khiến ta tin, nhưng AI vẫn có thể bịa."
},
{
"q": "[Tình huống] ChatGPT bị lỗi cả buổi, bạn chưa làm xong bài. Bài học là gì?",
"options": [
"Không nên phụ thuộc vào AI.",
"Nên mua thêm nhiều app AI.",
"Chờ AI chạy lại mới học."
],
"ans": 0,
"explain": "Tự học là “gốc”, AI chỉ là công cụ phụ trợ."
},
{
"q": "[Tình huống] Có bạn rủ dùng AI làm bài kiểm tra trực tuyến. Bạn nên…",
"options": [
"Từ chối, tự làm trung thực.",
"Làm theo vì ai cũng dùng.",
"Dùng AI nhưng sửa vài chữ."
],
"ans": 0,
"explain": "Dùng AI khi kiểm tra là gian lận và làm mất công bằng."
},
{
"q": "[Tình huống] Mật khẩu nào an toàn nhất?",
"options": [
"Mam#2026!Hoc",
"12345678",
"ngaysinh2010"
],
"ans": 0,
"explain": "Mật khẩu mạnh có chữ hoa, chữ thường, số và kí tự đặc biệt."
},
{
"q": "[Tình huống] Một tài khoản lạ nhắn: “Gửi ảnh riêng tư thì tặng thẻ game.” Bạn sẽ…",
"options": [
"Chặn, báo người lớn ngay.",
"Gửi vì được tặng quà.",
"Gửi ảnh đã chỉnh sửa."
],
"ans": 0,
"explain": "Không bao giờ gửi ảnh riêng tư. Báo ngay bố mẹ, thầy cô."
},
{
"q": "[Tình huống] Bạn đọc tin “ăn món X chữa khỏi mọi bệnh” trên mạng. Bạn nên…",
"options": [
"Hỏi người có chuyên môn.",
"Chia sẻ để cứu mọi người.",
"Làm theo ngay lập tức."
],
"ans": 0,
"explain": "Tin sức khỏe “thần kì” thường là tin giả. Hỏi bác sĩ, nguồn chính thống."
},
{
"q": "[Tình huống] Cách nào giúp AI trả lời đúng ý bạn hơn?",
"options": [
"Nói rõ môn, đã làm gì, cần gì.",
"Viết thật ngắn: “giải đi”.",
"Gửi ảnh đề, không nói gì."
],
"ans": 0,
"explain": "Công thức: Vai + Đã làm + Cần gì + Đừng."
},
{
"q": "[Tình huống] Muốn luyện thêm dạng bài vừa học, bạn nhờ AI thế nào?",
"options": [
"“Ra 3 bài tương tự để mình làm.”",
"“Giải hết bài tập trong sách.”",
"“Chép giúp mình lời giải mẫu.”"
],
"ans": 0,
"explain": "Nhờ AI ra bài tương tự để tự luyện là cách học chủ động."
},
{
"q": "[Tình huống] Bạn làm xong bài toán. Nhờ AI thế nào là tốt nhất?",
"options": [
"“Kiểm tra giúp mình sai ở đâu.”",
"“Làm lại cả bài cho mình.”",
"“Viết lời giải đẹp hơn.”"
],
"ans": 0,
"explain": "Tự làm trước rồi nhờ AI tìm lỗi giúp bạn hiểu chỗ sai."
},
{
"q": "[Tình huống] AI viết bài văn rất hay nhưng không giống ý bạn. Bạn nên…",
"options": [
"Tự viết theo ý mình.",
"Nộp luôn vì hay hơn.",
"Chép rồi sửa vài từ."
],
"ans": 0,
"explain": "Bài văn cần cảm xúc và suy nghĩ thật của chính bạn."
},
{
"q": "[Tình huống] Thầy cô nhận ra bài AI viết vì điều gì?",
"options": [
"Lời văn chung chung, xa bài giảng.",
"Chữ viết đẹp, trình bày gọn gàng.",
"Bài làm được nộp rất đúng hạn."
],
"ans": 0,
"explain": "Bài AI thường trau chuốt nhưng chung chung, không sát bài học."
},
{
"q": "[Tình huống] Phát hiện bạn bè đăng tin giả trong nhóm lớp. Bạn nên…",
"options": [
"Nhắc nhẹ và gửi nguồn đúng.",
"Chia sẻ tiếp cho vui.",
"Chế giễu bạn trước lớp."
],
"ans": 0,
"explain": "Góp ý lịch sự và đưa nguồn tin chính thống là ứng xử văn minh."
},
{
"q": "[Tình huống] Khi nào nên hỏi thầy cô thay vì hỏi AI?",
"options": [
"Khi vẫn chưa hiểu sau khi hỏi AI.",
"Không bao giờ cần hỏi.",
"Chỉ khi AI bị lỗi mạng."
],
"ans": 0,
"explain": "Thầy cô hiểu bài học trên lớp và hiểu bạn hơn AI."
},
{
"q": "[Tình huống] Bạn nhờ AI dịch đoạn văn tiếng Anh. Sau đó nên làm gì?",
"options": [
"Đọc lại, tra từ chưa chắc.",
"Chép luôn bản dịch nộp.",
"Dịch thêm bằng app khác."
],
"ans": 0,
"explain": "AI dịch có thể sai nghĩa. Hãy tự đọc hiểu và kiểm tra lại."
},
{
"q": "[Tình huống] Ứng dụng lạ đòi quyền đọc tin nhắn, danh bạ. Bạn nên…",
"options": [
"Không cấp quyền, gỡ app.",
"Cho phép hết cho nhanh.",
"Cho phép rồi tính sau."
],
"ans": 0,
"explain": "Chỉ cấp quyền thật cần thiết; app lạ có thể đánh cắp dữ liệu."
},
{
"q": "[Tình huống] Wifi công cộng miễn phí ở quán. Bạn nên tránh làm gì?",
"options": [
"Đăng nhập tài khoản ngân hàng.",
"Đọc báo, xem tin tức.",
"Tra từ điển tiếng Anh."
],
"ans": 0,
"explain": "Wifi công cộng dễ bị đánh cắp dữ liệu; tránh đăng nhập tài khoản quan trọng."
},
{
"q": "[Tình huống] Học 1 tiếng, cách nào giúp nhớ lâu nhất?",
"options": [
"Tự kiểm tra lại cuối buổi.",
"Đọc đi đọc lại nhiều lần.",
"Chép lời giải vào vở."
],
"ans": 0,
"explain": "Tự kiểm tra (tự nhớ lại) giúp não nhớ lâu hơn đọc lại."
},
{
"q": "[Tình huống] AI gợi ý một mẹo “học thuộc trong 5 phút”. Bạn nên…",
"options": [
"Thử và tự đánh giá hiệu quả.",
"Tin ngay, bỏ cách cũ.",
"Chia sẻ cho cả trường."
],
"ans": 0,
"explain": "Hãy thử nghiệm và kiểm chứng xem mẹo có phù hợp với mình không."
},
{
"q": "[Tình huống] Bạn nhận email “tài khoản sắp bị khóa, bấm link xác minh”. Bạn sẽ…",
"options": [
"Không bấm, kiểm tra trên app chính.",
"Bấm ngay kẻo bị khóa.",
"Gửi mật khẩu để xác minh."
],
"ans": 0,
"explain": "Đây là thủ đoạn lừa đảo (phishing) phổ biến."
},
{
"q": "[Tình huống] Đâu là thông tin KHÔNG nên đưa vào AI?",
"options": [
"Số điện thoại và địa chỉ nhà.",
"Tên môn học bạn đang học.",
"Câu hỏi về một bài thơ."
],
"ans": 0,
"explain": "Thông tin cá nhân cần được giữ kín khi dùng AI."
},
{
"q": "[Tình huống] AI nói một sự kiện lịch sử khác với SGK. Bạn tin ai?",
"options": [
"Đối chiếu SGK và nguồn chính thống.",
"Tin AI vì AI biết nhiều.",
"Chọn đáp án nghe hay hơn."
],
"ans": 0,
"explain": "SGK và tài liệu chính thống là nguồn đáng tin để đối chiếu."
},
{
"q": "[Tình huống] Bạn thấy ảnh người nổi tiếng nói điều lạ trong video. Có thể là gì?",
"options": [
"Video giả mạo bằng AI (deepfake).",
"Chắc chắn là thật 100%.",
"Video quay bằng camera xịn."
],
"ans": 0,
"explain": "Deepfake có thể ghép mặt, giả giọng rất giống thật."
},
{
"q": "[Tình huống] “Nhờ người khác tập gym hộ thì cơ của ai to lên?” Câu này muốn nói gì?",
"options": [
"Phải tự học mới giỏi thật.",
"Nên thuê người học hộ.",
"Tập gym quan trọng hơn học."
],
"ans": 0,
"explain": "Tự suy nghĩ là cách duy nhất giúp não bạn “khỏe” hơn."
},
{
"q": "[Tình huống] Bạn dùng AI tạo ảnh minh họa cho bài thuyết trình. Bạn nên…",
"options": [
"Ghi chú “ảnh tạo bằng AI”.",
"Nói là tự vẽ.",
"Không cần ghi gì cả."
],
"ans": 0,
"explain": "Ghi rõ nội dung do AI tạo là trung thực."
},
{
"q": "[Tình huống] Ai là người “cầm lái” khi bạn học cùng AI?",
"options": [
"Chính bạn.",
"Chatbot AI.",
"Người viết ra AI."
],
"ans": 0,
"explain": "Bạn cầm lái – AI chỉ đường!"
},
{
"q": "[Tình huống] Bạn đang ôn thi. Dùng AI thế nào là hiệu quả?",
"options": [
"Nhờ AI chỉ ra phần còn yếu.",
"Nhờ AI đoán đề thi.",
"Nhờ AI làm hết đề cương."
],
"ans": 0,
"explain": "AI giúp phân tích lỗi sai để biết cần ôn thêm phần nào."
},
{
"q": "[Tình huống] Bạn bị một tài khoản lạ nhắn tin đe dọa. Việc đầu tiên nên làm là…",
"options": [
"Chụp màn hình, báo người lớn.",
"Nhắn lại đe dọa họ.",
"Xóa hết tin nhắn đi."
],
"ans": 0,
"explain": "Giữ bằng chứng và báo ngay bố mẹ, thầy cô. Tổng đài 111 luôn sẵn sàng."
}
],
"days": [
"Tự làm 15 phút trước khi hỏi AI.",
"Hỏi AI giải thích, không xin đáp án.",
"Giải thích lại bài cho một người nghe.",
"Kiểm chứng 1 câu trả lời của AI với SGK.",
"Nhờ AI ra 5 câu hỏi, tự làm, tự chấm.",
"Nhờ AI tóm tắt 1 bài, rồi tự so với SGK.",
"Tìm 1 lỗi sai của AI và ghi lại.",
"Nhờ AI giải thích 1 khái niệm khó bằng ví dụ đời thường.",
"Tự vẽ sơ đồ tư duy 1 bài, rồi nhờ AI nhận xét.",
"Viết 1 câu lệnh theo công thức Vai – Đã làm – Cần gì – Đừng.",
"Đổi mật khẩu mạnh cho 1 tài khoản của bạn.",
"Kiểm chứng 1 tin “giật gân” trước khi chia sẻ.",
"Ghi khai báo AI cho 1 bài tập có dùng AI.",
"Hướng dẫn 1 bạn cách hỏi AI đúng cách.",
"Viết 3 điều bạn đã tiến bộ sau 15 ngày."
],
"chat": {
"welcome": "Chào bạn! Mình là Mầm 🌱 Bạn có thể hỏi Mầm cách ôn bài, câu lệnh hỏi AI theo môn, an toàn mạng, hoặc tâm sự chuyện học, chuyện bạn bè. Mầm gợi ý để bạn tự làm, không làm hộ đâu nhé!",
"extra_instructions": ""
},
"prompts": [
{
"icon": "🔢",
"subject": "Toán",
"color": "#f07c12",
"items": [
"Bạn là gia sư Toán. Mình làm được nửa bài thì bí. Gợi ý bước tiếp theo, đừng giải hết.",
"Bạn là gia sư Toán. Mình đã giải xong. Kiểm tra mình sai ở đâu, đừng làm lại cả bài."
]
},
{
"icon": "📖",
"subject": "Ngữ văn",
"color": "#d6246e",
"items": [
"Bạn là giáo viên Văn. Mình đã lập dàn ý. Nhận xét dàn ý còn thiếu gì, đừng viết bài hộ.",
"Bạn là giáo viên Văn. Mình đọc rồi nhưng chưa hiểu ý tác giả. Đặt câu hỏi gợi ý để mình tự hiểu, đừng phân tích sẵn."
]
},
{
"icon": "🇬🇧",
"subject": "Tiếng Anh",
"color": "#1f86d9",
"items": [
"Bạn là giáo viên Tiếng Anh. Mình đã viết xong đoạn văn. Chỉ ra lỗi và giải thích, đừng viết lại cả đoạn.",
"Bạn là bạn luyện nói tiếng Anh. Mình muốn tập giao tiếp. Hỏi mình từng câu, chờ mình trả lời rồi mới sửa."
]
},
{
"icon": "⚡",
"subject": "Vật lí",
"color": "#5b3fb5",
"items": [
"Bạn là gia sư Vật lí. Mình đã viết công thức nhưng không biết thay số. Gợi ý cách làm, đừng tính ra kết quả.",
"Bạn là gia sư Vật lí. Mình chưa hiểu hiện tượng này. Giải thích bằng ví dụ đời thường, thật ngắn gọn."
]
},
{
"icon": "🧪",
"subject": "Hóa học",
"color": "#e03a3a",
"items": [
"Bạn là gia sư Hóa. Mình làm đến bước 2 thì sai. Giải thích vì sao sai, đừng cho đáp án.",
"Bạn là gia sư Hóa. Mình chưa cân bằng được phương trình. Gợi ý cách làm, để mình tự cân bằng."
]
},
{
"icon": "🌱",
"subject": "Sinh học",
"color": "#2a9d6f",
"items": [
"Bạn là gia sư Sinh. Mình hay nhầm hai khái niệm. Lập bảng so sánh ngắn, rồi hỏi mình 3 câu kiểm tra.",
"Bạn là gia sư Sinh. Mình vừa học xong bài. Ra 5 câu trắc nghiệm, chờ mình làm xong rồi mới chấm."
]
},
{
"icon": "🏛️",
"subject": "Lịch sử",
"color": "#b5651d",
"items": [
"Bạn là gia sư Lịch sử. Mình đã đọc bài trong SGK. Hỏi mình 5 câu từ dễ đến khó, đừng đưa đáp án trước.",
"Bạn là gia sư Lịch sử. Mình đã tự vẽ sơ đồ tư duy. Nhận xét sơ đồ còn thiếu ý chính nào, đừng vẽ lại hộ."
]
},
{
"icon": "🌏",
"subject": "Địa lí",
"color": "#0f9bb0",
"items": [
"Bạn là gia sư Địa lí. Mình đọc biểu đồ nhưng chưa biết nhận xét. Gợi ý các bước, để mình tự viết.",
"Bạn là gia sư Địa lí. Mình khó nhớ bài này. Gợi ý mẹo ghi nhớ, rồi hỏi lại mình 3 câu."
]
},
{
"icon": "⚖️",
"subject": "GDCD · Tin học",
"color": "#e0a800",
"items": [
"Bạn là gia sư GDCD. Mình đọc tình huống rồi nhưng chưa biết xử lí. Đặt câu hỏi gợi ý, đừng trả lời sẵn.",
"Bạn là gia sư Tin học. Code của mình bị lỗi. Chỉ ra lỗi ở đâu, đừng viết lại cả code."
]
},
{
"icon": "📅",
"subject": "Môn nào cũng dùng được",
"color": "#8e44ad",
"items": [
"Bạn là người hướng dẫn học tập. Mình sắp thi và mỗi tối rảnh 1 tiếng. Gợi ý lịch ôn, để mình tự chọn.",
"Bạn là người phản biện. Mình vừa làm xong bài. Chỉ ra 2 điểm tốt và 2 điểm cần sửa, đừng sửa hộ."
]
}
],
"quiz_per_round": 10,
"tree": {
"one_per_day": true,
"gifts": [
{
"at": 5,
"emoji": "🌱",
"title": "Huy hiệu Mầm chăm chỉ",
"desc": "Bạn đã kiên trì tưới cây 5 ngày! Giữ nhịp đều đặn nhé."
},
{
"at": 10,
"emoji": "🔍",
"title": "Huy hiệu Thợ săn lỗi AI",
"desc": "10 ngày rồi! Bạn đang tự học rất chủ động và biết kiểm chứng."
},
{
"at": 15,
"emoji": "🏆",
"title": "Giấy chứng nhận Người cầm lái AI",
"desc": "15 ngày kiên trì – cây Mầm đã ra hoa kết trái! Thêm ảnh của bạn vào giấy chứng nhận, lưu lại và đưa cô phụ trách CLB xem để nhận quà nhé."
}
]
},
"vote": {
"enabled": false,
"title": "Chọn logo cho CLB mình!",
"intro": "CLB AI Thăng Long cần một logo thật “chất”. Xem 4 mẫu dưới đây, bấm vào ảnh để phóng to, rồi tích chọn mẫu bạn thích nhất nhé!",
"deadline": "2026-11-21",
"url": "https://padlet.com/vuly0205/binh-chon-logo-clb-ai-thang-long-s025kyy559plnlyp38in",
"options": [
{
"label": "Logo 1",
"desc": "Robot vui vẻ giơ cuốn sách, dải băng “Học chủ động – Dùng AI thông minh”.",
"img": "assets/05a5d9d46e.jpg"
},
{
"label": "Logo 2",
"desc": "Huy hiệu nền hồng, robot bay trên trang sách mở.",
"img": "assets/93eddc263c.jpg"
},
{
"label": "Logo 3",
"desc": "Vòng tím “Học sinh thông minh – Tự nghĩ trước, hỏi AI sau”.",
"img": "assets/02e301fcc9.jpg"
},
{
"label": "Logo 4",
"desc": "Cây Mầm mọc từ trang sách, ngọn cây nối mạch AI – “Bạn cầm lái · AI chỉ đường”.",
"img": "assets/42cc77884f.jpg"
}
]
}
};
