window.CLB_ARTICLES=[
 {
  "title": "Ôn thi cùng AI: trợ thủ đắc lực hay “con dao hai lưỡi”? 🎬",
  "summary": "AI giúp tra từ vựng, lấp lỗ hổng kiến thức, đóng vai gia sư riêng… nhưng thiếu tư duy phản biện thì dễ bị dẫn dắt. Xem video VTV24 và bí quyết ôn thi cùng AI thông minh.",
  "body": "Mùa ôn thi cuối cấp đang đến gần. Bên cạnh sách vở và thầy cô, nhiều bạn học sinh THPT có thêm một “người bạn mới”: **trí tuệ nhân tạo (AI)**. Nhưng ôn thi cùng AI có thật sự hiệu quả? Bản tin của **VTV24** đã đi tìm câu trả lời. CLB AI Thăng Long tóm tắt lại cho các bạn nhé! 🎬\n\n**🤝 AI – trợ thủ đắc lực mùa thi**\nTheo bản tin, nhiều bạn đang dùng AI để:\n📖 Tra cứu từ vựng tiếng Anh ngay khi cần.\n✏️ Hỏi cách giải bài tập, **lấp lỗ hổng kiến thức** mà không phải chờ đến tiết học sau.\n👩‍🏫 Nhờ AI đóng vai **gia sư riêng** hoặc **người chấm bài**, đưa ra gợi ý phù hợp với từng bạn.\nCó phụ huynh còn sẵn sàng đầu tư mua bản quyền phần mềm AI để con luyện được nhiều đề hơn.\n\n**🎯 Học “may đo” cho từng người**\nCác chuyên gia đánh giá cao khả năng **cá nhân hóa** của AI: dựa trên bài tập hằng ngày, AI có thể phân tích bạn hay sai ở đâu, từ đó gợi ý phần kiến thức cần ôn thêm. Giống như có một người theo sát việc học của riêng bạn vậy!\n\n**⚠️ Nhưng AI là “con dao hai lưỡi”**\nChuyên gia cũng cảnh báo:\n❗ Thiếu **tư duy phản biện**, học sinh dễ bị AI dẫn dắt, trở nên thụ động và tiếp nhận cả thông tin chưa được kiểm chứng.\n❗ AI **thỉnh thoảng đưa ra dữ liệu không chính xác**, dù trả lời rất tự tin.\n❗ Cứ “thả” bài tập cho AI giải hộ thì não sẽ **lười tư duy**, đến phòng thi không có AI là… “đứng hình”.\n\n**🧭 Bí quyết ôn thi cùng AI thông minh**\n✅ **Nắm chắc kiến thức cơ bản trên lớp trước**: AI chỉ giúp bạn đi xa hơn khi “nền móng” đã vững.\n✅ **Tự làm đề trước**, rồi nhờ AI chấm và chỉ ra phần còn yếu.\n✅ **Hỏi “vì sao”**: nhờ AI giải thích cách làm thay vì chỉ xin đáp án.\n✅ **Đối chiếu** với SGK, đề cương của thầy cô khi thấy thông tin lạ.\n✅ **Kết hợp thực tế**: học nhóm, hỏi thầy cô, tự tóm tắt bằng sơ đồ tư duy.\n\nCâu lệnh mẫu cho mùa ôn thi: “Bạn là gia sư Lịch sử 12. Mình vừa làm xong đề ôn tập (dán bài làm). Chấm giúp mình, chỉ ra 3 phần kiến thức mình còn yếu, gợi ý cách ôn, đừng viết lại bài hộ.”\n\n**💙 Thông điệp của CLB AI Thăng Long**\nAI giúp bạn ôn **nhanh hơn**, nhưng chỉ có **chính bạn** mới làm bài thi được. Hãy để AI làm người dẫn đường, còn tay lái luôn là của bạn. **Bạn cầm lái – AI chỉ đường!** 🚗\n\n🎮 Luyện “con mắt phản biện” với trò chơi **Thợ săn lỗi AI** (hơn 200 câu hỏi) và lấy **20 câu lệnh mẫu** ở mục **Câu lệnh** trên trang này nhé!\n\n📺 Nguồn: VTV24, “Học sinh tận dụng AI để ôn thi liệu có hiệu quả?”.\n\n#CLBAITHANGLONG #OnThiCungAI #AIvaTuHoc #THCSTHPTThangLong",
  "category": "Góc kiến thức",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-18",
  "cover": "assets/37755a5dce.jpg",
  "images": [],
  "video": "https://www.youtube.com/watch?v=5dy_h5ZRTEI",
  "published": true,
  "pinned": false
 },
 {
  "title": "Đừng để AI “học hộ”: AI làm hộ được bài, nhưng không học hộ được tư duy 🎬",
  "summary": "ChatGPT “đứng hình” vài giờ, nhiều học sinh “lao đao”. Xem video VTV24 và cùng CLB tìm hiểu: thầy cô phát hiện AI làm hộ thế nào, và dùng AI sao cho đúng.",
  "body": "Một ngày tháng 11/2026, sự cố mạng toàn cầu của **Cloudflare** khiến ChatGPT “đứng hình” vài giờ. Và thế là… nhiều bạn học sinh, sinh viên **“lao đao”**: bài tập chưa xong, khóa luận đang dở, đề cương ôn thi bỗng “tắc đường”. Câu chuyện nhỏ ấy làm lộ ra một điều lớn: **chúng ta đang để AI học hộ mình nhiều đến mức nào?**\n\n**🎬 Bản tin “Tiêu điểm” của VTV24** đã kể lại thực trạng này. CLB AI Thăng Long tóm tắt lại để các bạn cùng suy ngẫm nhé!\n\n**📸 Chụp đề – gửi AI – chép đáp án**\nNhiều bạn chỉ cần chụp ảnh đề Toán, Anh, Văn… gửi cho AI, vài giây sau đã có lời giải hay cả bài văn hoàn chỉnh. Nhanh thật, nhưng kiến thức thì **không đi vào đầu**. Lâu dần tạo ra những “lỗ hổng” rất khó lấp, và gây mất công bằng với những bạn tự làm.\n\n**🌍 Không chỉ ở Việt Nam**\nTheo bản tin, hàng trăm sinh viên ở 3 trường đại học hàng đầu Hàn Quốc bị phát hiện dùng AI khi thi trực tuyến. Ở Anh, phần mềm quét gian lận vẫn **bỏ lọt tới 94%** số vụ dùng AI trái phép. Gian lận bằng AI đang là vấn đề toàn cầu.\n\n**🕵️ Thầy cô phát hiện bằng cách nào?**\nĐừng nghĩ thầy cô không biết nhé! Những “dấu vết” thường gặp:\n✅ Quên xóa dòng **“chatgpt.com”** hay câu “đây là nội dung do AI tạo ra”.\n✅ Giữ nguyên kiểu **in đậm, gạch đầu dòng** đặc trưng của ChatGPT.\n✅ Trích dẫn **nguồn tham khảo không có thật** do AI bịa ra.\n✅ Học sinh lớp 10 dùng kiến thức lớp 11–12, nhưng khi được hỏi **“em giải thích bước này đi”** thì… im lặng.\n✅ Lời văn trau chuốt mà chung chung, không giống cách thầy cô giảng trên lớp.\n\n**🧭 Vậy dùng AI thế nào cho đúng?**\nAI không có lỗi, quan trọng là **cách mình cầm lái**:\n💡 Nhờ AI **gợi ý hướng giải**, đừng xin đáp án.\n👩‍🏫 Bảo AI **đóng vai gia sư**, hỏi dẫn dắt để mình tự nghĩ.\n🔍 Tự làm trước, rồi nhờ AI **tìm lỗi sai** trong bài của mình.\n📝 Nhờ AI **ra bài tập tương tự** để tự luyện thêm.\n\nCâu lệnh mẫu: “Bạn là gia sư Toán. Mình làm đến bước 2 thì bí. Gợi ý bước tiếp theo, đừng giải hết.” Xem thêm **20 câu lệnh mẫu** ở mục **Câu lệnh** trên trang này nhé!\n\n**🏫 Thầy cô cũng đang đổi mới**\nThay vì cấm AI, nhiều thầy cô giao **bài tập mở**, phiếu “giải mã bài học”, yêu cầu học sinh **giải thích vì sao chọn đáp án** và tự chắt lọc thông tin từ AI. Như vậy, AI chỉ là công cụ, còn **tư duy vẫn là của em**.\n\n**💙 Thông điệp của CLB AI Thăng Long**\nAI có thể **làm hộ** rất nhiều thứ, nhưng **không thể học hộ** tư duy của bạn. Mỗi lần tự suy nghĩ, tự sửa sai là một lần bộ não “tập gym” và khỏe hơn. Hành trình tự học mới là thứ giúp bạn thật sự lớn lên!\n\n🎮 Thử ngay trò chơi **Thợ săn lỗi AI** và **thử thách tưới cây Mầm** trên trang để luyện thói quen “Tự nghĩ trước – Hỏi AI sau” nhé!\n\n📺 Nguồn: Bản tin Tiêu điểm – VTV24, “Đừng để A.I học hộ: Khi giáo viên phát hiện học sinh ‘lạm dụng’ A.I”.\n\n#CLBAITHANGLONG #DungDeAIHocHo #AIvaTuHoc #THCSTHPTThangLong",
  "category": "Góc kiến thức",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-18",
  "cover": "assets/93f69a9c41.jpg",
  "images": [],
  "video": "https://www.youtube.com/watch?v=ejaVedV3vQE",
  "published": true,
  "pinned": false
 },
 {
  "title": "Tuổi trẻ Thăng Long với chuyển đổi số và trí tuệ nhân tạo – Dùng AI để học giỏi hơn, không để học ít đi 💙",
  "summary": "Ngày 14/11/2026, thành viên CLB AI Thăng Long tham gia tập huấn “Chuyển đổi số và phát triển kinh tế số trong thanh niên” tại xã Nam Ban Lâm Hà.",
  "body": "Ngày 14/11/2026, các thành viên **CLB AI Thăng Long – Trường THCS&THPT Thăng Long** đã tham gia buổi tập huấn chuyên đề **“Chuyển đổi số và phát triển kinh tế số trong thanh niên”**.\n\nBuổi tập huấn do Trung tâm Dịch vụ tổng hợp xã Nam Ban Lâm Hà và CLB Sáng Tạo Xanh (kết hợp phó chủ nhiệm CLB AI Thăng Long) tổ chức. Không những thành viên của CLB mà các bạn học sinh của các trường trên địa bàn cũng tham gia nhiệt tình.\n\nGiảng viên **Đoàn Thị Cẩm Nhung** (Chủ tịch HĐQT kiêm Tổng Giám đốc HTX Nông nghiệp Công nghệ Nam Ban Lâm Hà – Chủ nhiệm CLB Sáng Tạo Xanh) đã chia sẻ nhiều kiến thức thực tế về công nghệ số và cách sử dụng AI cho thanh niên. Qua đó, các thành viên CLB thấy rõ hơn rằng AI đang có mặt ở khắp nơi: trong kinh doanh và đặc biệt là cả trong việc học tập hằng ngày của các bạn học sinh, sinh viên.\n\nAI giúp ta học tốt hơn nếu biết dùng đúng cách: giải thích bài khó, gợi ý ý tưởng, giúp ta tự ôn tập và tự kiểm tra kiến thức… Nhưng nếu chỉ chép đáp án, nhờ AI làm bài hộ thì ta sẽ dần mất khả năng tự suy nghĩ và tự học. Ngoài ra, thế giới số còn có tin giả, lừa đảo trực tuyến và nguy cơ lộ thông tin cá nhân.\n\nVì vậy, CLB AI Thăng Long ra đời để cùng các bạn:\n✅ Học cách đặt câu hỏi cho AI thông minh\n✅ Dùng AI để tự học, tự ôn tập hiệu quả\n✅ Biết kiểm tra thông tin, tránh phụ thuộc vào AI\n✅ Bảo vệ dữ liệu cá nhân, ứng xử văn minh trên mạng\n\n📢 CLB chào đón tất cả học sinh THCS và THPT Thăng Long cùng tham gia! Đăng ký tại mục **Tham gia CLB** trên trang này. Học sinh thông minh – Làm chủ AI – Làm chủ tri thức!\n\n**Hiểu biết để không bị dẫn dắt – Làm chủ để không bị phụ thuộc – Sáng tạo để cùng kiến tạo tương lai!**\n\n#CLBAITHANGLONG #THCSTHPTThangLong #AIvaTuHoc #ChuyenDoiSo #NamBanLamHa",
  "category": "Hoạt động",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-14",
  "cover": "assets/2e16b3447d.jpg",
  "images": [
   "assets/ee67139523.jpg",
   "assets/0852a9385d.jpg",
   "assets/42cc06e37c.jpg",
   "assets/41b7962eed.jpg",
   "assets/2e16b3447d.jpg",
   "assets/8e0514c8f5.jpg"
  ],
  "published": true,
  "pinned": true
 },
 {
  "title": "🏆 Kết quả bình chọn logo: Logo 1 và Logo 2 được yêu thích nhất!",
  "summary": "Cuộc bình chọn logo CLB AI Thăng Long đã khép lại. Hai mẫu nhận được nhiều tình cảm nhất là Logo 1 và Logo 2. Cảm ơn tất cả các bạn đã tham gia!",
  "body": "Cuộc bình chọn logo của **CLB AI Thăng Long** đã chính thức khép lại. Cảm ơn tất cả các bạn đã dành thời gian ngắm nghía, cân nhắc và tích chọn mẫu mình thích! 💜\n\n**🏆 Hai mẫu được yêu thích nhất**\n• **Logo 1** – Robot vui vẻ giơ cao cuốn sách, nổi bật dòng chữ “CLB AI Thăng Long” cùng dải băng “Học chủ động – Dùng AI thông minh”. Màu sắc rực rỡ, rất năng động.\n• **Logo 2** – Huy hiệu tròn nền hồng, robot bay trên trang sách mở, kèm phương châm “Tự nghĩ trước · Hỏi AI sau”. Gọn gàng, dễ in lên huy hiệu, áo CLB.\n\n**💡 Vì sao hai mẫu này “ghi điểm”?**\nCả hai đều có hình ảnh **robot AI đi cùng cuốn sách** – đúng tinh thần của CLB: AI là người bạn đồng hành, còn việc học vẫn do chính mình cầm lái.\n\n**📌 Tiếp theo là gì?**\nBan chủ nhiệm CLB sẽ dựa trên kết quả này để hoàn thiện logo chính thức. Logo sẽ được dùng trên website, fanpage, tài liệu và các hoạt động của CLB. Hãy cùng chờ xem nhé!\n\n🌱 Cảm ơn các bạn đã cùng CLB viết tiếp hành trình “Bạn cầm lái – AI chỉ đường”!",
  "category": "Tin CLB",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-22",
  "cover": "assets/68eff4e9df.jpg",
  "images": [
   "assets/05a5d9d46e.jpg",
   "assets/93eddc263c.jpg"
  ],
  "video": "",
  "published": true,
  "pinned": false
 },
 {
  "title": "Học AI chính thức vào trường: 12 tiết mỗi năm sẽ học gì? 🏫",
  "summary": "Từ năm học 2026–2027, học sinh cả nước được học về trí tuệ nhân tạo. Không phải học “bấm ChatGPT”, mà học cách hiểu, dùng an toàn và trung thực.",
  "body": "Năm học này có một điều mới: **giáo dục trí tuệ nhân tạo (AI)** chính thức được đưa vào trường phổ thông trên cả nước, sau một năm thí điểm.\n\n**📌 Vài con số cần nhớ**\n• Bộ GD&ĐT ban hành **Khung nội dung giáo dục AI** (Quyết định 2422/QĐ-BGDĐT, ngày 18/8/2026) và hướng dẫn triển khai (Công văn 5588/BGDĐT-GDPT).\n• Mỗi lớp, từ lớp 1 đến lớp 12, có phần cốt lõi khoảng **12 tiết/năm học**. Nhà trường có thể tổ chức thêm phần mở rộng.\n\n**🧩 Học AI là học những gì?**\nKhung nội dung gồm 4 mảng lớn:\n1. **Lấy con người làm trung tâm** – AI phục vụ con người, không thay con người suy nghĩ.\n2. **Đạo đức AI** – trung thực, tôn trọng, không dùng AI để hại người khác.\n3. **Kỹ thuật và ứng dụng AI** – hiểu AI hoạt động thế nào và dùng vào việc gì.\n4. **Thiết kế hệ thống AI** – dành cho các lớp lớn: thử tạo ra giải pháp thông minh của riêng mình.\n\n**✍️ Khai báo trung thực – kỹ năng bắt buộc**\nTheo khung nội dung, từ lớp 7 học sinh cần **khai báo trung thực** khi bài làm có dùng AI. Lên lớp 8, các em cần nói rõ: dùng AI ở phần nào, dùng công cụ gì. Đây đúng là điều CLB mình vẫn nhắc: dùng AI thì khai báo!\n\n**💡 Điều quan trọng nhất**\nHọc AI không có nghĩa là học cách bấm ChatGPT cho nhanh. Mục tiêu là giúp học sinh **hiểu thế giới công nghệ mình đang sống**, biết dùng AI an toàn, có trách nhiệm – và vẫn giữ được khả năng tự suy nghĩ.\n\n🌱 **Thử ngay:** Bạn đang dùng AI cho việc gì nhiều nhất? Hãy viết 1 câu khai báo theo mẫu: “Dùng AI: … · AI giúp: … · Em tự làm: …”",
  "category": "Tin giáo dục",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-22",
  "cover": "assets/3efca29fed.jpg",
  "images": [],
  "video": "",
  "published": true,
  "pinned": false,
  "auto": true,
  "sources": [
   {
    "name": "Báo Văn Hóa",
    "url": "https://baovanhoa.vn/doi-song/giao-duc-ai-dai-tra-tu-nam-hoc-20262027-257694.html"
   },
   {
    "name": "Báo Chính phủ (qua CafeF)",
    "url": "https://cafef.vn/dua-ai-vao-truong-hoc-khong-de-cong-nghe-lam-thay-viec-hoc-188261011132849995.chn"
   },
   {
    "name": "Báo điện tử Giáo dục Việt Nam",
    "url": "https://giaoduc.net.vn/ban-in/post262395.gd"
   }
  ]
 },
 {
  "title": "94% học sinh dùng AI: dùng sao để giỏi lên chứ không “mất gốc”? 🧠",
  "summary": "Khảo sát PISA cho thấy gần như học sinh nào cũng dùng chatbot AI để học. Nhưng dùng AI làm hộ bài lại đi kèm điểm số thấp hơn. Đâu là cách dùng đúng?",
  "body": "Bạn có dùng AI để học không? Nếu có, bạn không hề cô đơn đâu! 😄\n\n**📊 Học sinh Việt Nam dùng AI nhiều cỡ nào?**\nTheo kết quả đánh giá PISA được Bộ GD&ĐT công bố tháng 9/2026:\n• **94%** học sinh dùng chatbot AI để hỗ trợ học tập.\n• **86%** dùng AI để tóm tắt văn bản, **88%** dùng để soạn thảo bài tập.\n• Trung bình mỗi ngày, học sinh dành hơn **2 giờ** dùng thiết bị số cho việc học ở trường.\n\n**⚠️ Mặt trái: AI làm hộ thì não “nghỉ việc”**\nKhảo sát của OECD cho thấy nhóm học sinh **lạm dụng AI để làm hộ bài** thường có điểm Khoa học **thấp hơn** nhóm không dùng. Một nghiên cứu khác ghi nhận gần 1/3 học sinh dùng AI để lấy luôn lời giải hoàn chỉnh – đây chính là kiểu dùng dễ khiến mình “mất gốc” nhất.\n\nNhiều phụ huynh cũng lo khi thấy con ôm máy tính cả tối. Một số thầy cô đã đổi cách ra đề: hỏi những câu cần **suy nghĩ của riêng em**, AI không chép hộ được.\n\n**✅ 4 cách dùng AI để giỏi lên thật**\n1. **Tự làm trước 15 phút**, bí rồi mới hỏi.\n2. Nhờ AI **giải thích khái niệm** và cho ví dụ – không xin đáp án cuối.\n3. Làm xong, nhờ AI **chỉ ra chỗ sai** để tự sửa.\n4. Nhờ AI **ra câu hỏi kiểm tra** để luyện thêm.\n\n**💬 Nhớ nhé:** AI giống như một gia sư 24/7 – nhưng gia sư giỏi là người giúp bạn tự đi, chứ không cõng bạn đi.\n\n🌱 Muốn có sẵn câu lệnh đúng cách? Xem mục **💬 20 câu lệnh mẫu** trên web, hoặc bấm **Hỏi Mầm**!",
  "category": "Góc kỹ năng",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-22",
  "cover": "assets/3dc26cdb1f.jpg",
  "images": [],
  "video": "",
  "published": true,
  "pinned": false,
  "auto": true,
  "sources": [
   {
    "name": "Báo Tiền Phong",
    "url": "https://tienphong.vn/con-om-may-tinh-ca-toi-phu-huynh-lo-qua-le-thuoc-ai-post1890191.tpo"
   },
   {
    "name": "Báo Văn Hóa",
    "url": "https://baovanhoa.vn/doi-song/ai-lam-bai-ho-hoc-sinh-co-nguy-co-mat-ky-nang-that-278998.html"
   },
   {
    "name": "Báo Đại biểu Nhân dân",
    "url": "https://daibieunhandan.vn/print/10429449.html"
   }
  ]
 },
 {
  "title": "Học bổng giả, mất tiền thật: 5 dấu hiệu nhận diện bẫy lừa 🎓",
  "summary": "Thông báo “trúng học bổng” dù chưa nộp hồ sơ? Cùng CLB nhận diện 5 dấu hiệu lừa đảo học bổng và cách tự bảo vệ mình.",
  "body": "Bỗng một ngày bạn nhận email báo “trúng học bổng toàn phần”, dù chưa từng nộp hồ sơ? Khoan vui vội, rất có thể đó là một cái bẫy được dựng rất công phu!\n\n**📌 Kẻ gian giăng bẫy thế nào?**\nTheo Báo Văn Hóa, các đối tượng mạo danh trường đại học, dùng cả tên, logo, chữ ký, con dấu và làm website, fanpage giống hệt kênh chính thức. Thông báo giả được gửi qua email, tin nhắn, mạng xã hội, thậm chí có cả buổi họp trực tuyến cho thêm “uy tín”. Tháng 7/2026, Đại học Quốc gia Hà Nội đã phải lên tiếng cảnh báo việc bị mạo danh để gửi thông báo trúng tuyển giả.\n\n**📌 Mục đích thật: tiền và thông tin của bạn**\nSau lời chúc mừng là hàng loạt khoản thu: phí xét duyệt, phí hồ sơ, tiền cọc giữ suất… Nguy hiểm hơn, kẻ gian còn xin ảnh CCCD, thông tin ngân hàng, mật khẩu, mã OTP để chiếm đoạt tiếp. Báo Nhân Dân cũng lưu ý học sinh dễ gặp các tài khoản Facebook, Zalo giả danh trung tâm, giáo viên để đòi đặt cọc học phí.\n\n**📌 5 dấu hiệu “báo động đỏ”**\n• Hối thúc: “chỉ còn một suất”, phải xác nhận ngay trong ngày.\n• Hứa hẹn quá đẹp: toàn phần, thủ tục đơn giản, chắc chắn đậu.\n• Yêu cầu chuyển tiền vào tài khoản cá nhân, chia nhiều đợt.\n• Tên miền gần giống tên trường, chỉ khác một kí tự hay thêm dấu gạch.\n• Fanpage nhiều người theo dõi nhưng không nêu rõ đơn vị cấp và tiêu chí.\n\n**✅ Bạn có thể làm gì?**\n1. Tự nghĩ trước: tự hỏi “Mình đã nộp hồ sơ chưa? Vì sao lại cần nộp tiền?”.\n2. Tự tìm website, số điện thoại chính thức của trường để hỏi lại, không dùng liên hệ do người lạ đưa.\n3. Hỏi AI sau: dán nội dung tin nhắn (đã xóa thông tin cá nhân) và hỏi AI “Tin này có dấu hiệu lừa đảo nào?”. Nhưng AI chỉ gợi ý, quyết định cuối cùng là của bạn cùng bố mẹ, thầy cô.\n4. Tuyệt đối không gửi OTP, mật khẩu, ảnh CCCD. Lỡ lộ thông tin ngân hàng thì báo ngay cho ngân hàng để khóa tài khoản.\n5. Lưu lại bằng chứng và báo cho nhà trường, công an.\n\n🌱 Thử ngay: Tìm và lưu sẵn website chính thức của 3 trường đại học bạn mơ ước, để sau này đối chiếu khi nhận bất kì “thông báo học bổng” nào!",
  "category": "An toàn mạng",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-23",
  "cover": "assets/886ba106bf.jpg",
  "images": [],
  "video": "",
  "published": true,
  "pinned": false,
  "auto": true,
  "sources": [
   {
    "name": "Báo Văn Hóa",
    "url": "https://baovanhoa.vn/phap-luat/hoc-bong-gia-mat-tien-that-279818.html"
   },
   {
    "name": "Báo Nhân Dân",
    "url": "https://nhandan.vn/ocop/nhan-dien-cac-hinh-thuc-lua-dao-tren-khong-gian-mang-doi-voi-hoc-sinh-post939408.html"
   }
  ]
 },
 {
  "title": "Học sinh THPT được thi AI chuẩn quốc tế miễn phí: “AI or Behind” 🏅",
  "summary": "Cuộc thi AI chuẩn quốc tế đầu tiên cho học sinh THPT cả nước, miễn phí, vòng trường diễn ra từ 02/11 đến 30/12/2026.",
  "body": "Bạn có tin không: lần đầu tiên, học sinh THPT cả nước có thể thi AI theo chuẩn quốc tế mà không mất đồng nào! Cuộc thi “AI or Behind” vừa được phát động ngày 31/10/2026 và vòng đầu đang diễn ra ngay lúc này.\n\n**📌 Cuộc thi gì, ai tổ chức?**\n• Viettel và Tổ chức Giáo dục IIG Việt Nam phối hợp tổ chức, bài thi do Pearson – Certiport (Mỹ) cung cấp.\n• Thông điệp: “Không AI bị bỏ lại phía sau” – để học sinh vùng nông thôn, vùng xa như chúng mình cũng được tiếp cận AI.\n• Miễn phí bài thi, có tài liệu ôn luyện và đề tham khảo cho cả học sinh lẫn thầy cô.\n\n**📌 Ba vòng thi đáng chú ý**\n1. Vòng cơ sở (02/11 – 30/12/2026): thi cá nhân trên máy tính tại trường, bằng tiếng Việt hoặc tiếng Anh. Đạt từ 700/1.000 điểm được nhận chứng nhận điện tử.\n2. Vòng loại quốc gia (dự kiến 14/3/2027): thi theo nhóm 3–5 bạn, mỗi trường tối đa 15 nhóm. Đạt 700 điểm trở lên được cấp chứng chỉ quốc tế Generative AI Foundations.\n3. Chung kết (dự kiến 11/4/2027) tại Hà Nội, Đà Nẵng và TP.HCM: 10 nhóm xuất sắc nhất làm dự án AI để tranh giải.\n\n**📌 Thi những gì?**\nKhông phải lập trình phức tạp đâu! Nội dung xoay quanh AI tạo sinh, cách viết câu lệnh, đạo đức – pháp lý khi dùng AI và ứng dụng thực tế. Vòng sau còn kiểm tra khả năng tinh chỉnh câu lệnh và kiểm chứng kết quả AI đưa ra. Tổng giải thưởng 280 triệu đồng, giải nhất 100 triệu đồng.\n\n**✅ Bạn có thể làm gì?**\n• Hỏi thầy cô xem trường mình có đăng ký tham gia vòng cơ sở không.\n• Luyện viết câu lệnh rõ ràng: nói rõ vai trò, nhiệm vụ, yêu cầu đầu ra.\n• Tập thói quen kiểm chứng: so câu trả lời của AI với sách giáo khoa và nguồn báo chính thống.\n• Giữ phương châm “Tự nghĩ trước – Hỏi AI sau” và “Dùng AI thì khai báo” – đó cũng chính là tinh thần dùng AI có trách nhiệm mà cuộc thi đề cao.\n\n🌱 Thử ngay: Chọn một bài Lịch sử vừa học, tự viết 3 ý chính, rồi nhờ AI góp ý và tìm xem AI có chỗ nào sai không!",
  "category": "Tin giáo dục",
  "author": "CLB AI Thăng Long",
  "date": "2026-11-23",
  "cover": "assets/6fbc513e0a.jpg",
  "images": [],
  "video": "",
  "published": true,
  "pinned": false,
  "auto": true,
  "sources": [
   {
    "name": "VietnamPlus",
    "url": "https://www.vietnamplus.vn/lan-dau-tien-hoc-sinh-thpt-ca-nuoc-duoc-thi-ai-chuan-quoc-te-hoan-toan-mien-phi-post1145351.vnp"
   },
   {
    "name": "Tiền Phong",
    "url": "https://tienphong.vn/phat-dong-thi-ai-cho-hoc-sinh-cap-3-ca-nuoc-giai-nhat-100-trieu-dong-post1890244.tpo"
   }
  ]
 }
];
