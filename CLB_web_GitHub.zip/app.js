(() => {
'use strict';
/* ===== Khởi động: dựng trang từ khuôn mẫu + dữ liệu ===== */
const TPL = document.getElementById('clb-body');
const SRC = { style: (document.getElementById('clb-style') || {}).textContent || '', body: TPL.innerHTML, app: (document.getElementById('clb-app') || {}).textContent || '' };
let DATA = JSON.parse(document.getElementById('clb-data').textContent);
/* Ảnh bìa dự phòng: nếu ảnh bài viết không tải được, vẽ bìa màu có tiêu đề */
function makeCover(title) {
  try { const c = document.createElement('canvas'); c.width = 1200; c.height = 675; const g = c.getContext('2d'); const cols = [['#5b3fd6', '#e2508a'], ['#1f86d9', '#22c39a'], ['#f07c12', '#e2508a'], ['#12a884', '#5b3fd6']][String(title).length % 4];
    const gr = g.createLinearGradient(0, 0, 1200, 675); gr.addColorStop(0, cols[0]); gr.addColorStop(1, cols[1]); g.fillStyle = gr; g.fillRect(0, 0, 1200, 675);
    g.fillStyle = '#ffffff22'; for (let i = 0; i < 14; i++) { g.beginPath(); g.arc(700 + (i * 137) % 480, (i * 89) % 640, 20 + (i * 13) % 60, 0, 7); g.fill(); }
    g.fillStyle = '#fff'; g.font = '800 64px "Baloo 2","Quicksand",sans-serif'; const words = String(title).replace(/[\u{1F300}-\u{1FAFF}☀-➿]/gu, '').trim().split(/\s+/); let line = '', y = 200; const lines = [];
    words.forEach((w) => { const t = line ? line + ' ' + w : w; if (g.measureText(t).width > 760) { lines.push(line); line = w; } else line = t; }); lines.push(line);
    lines.slice(0, 4).forEach((l) => { g.fillText(l, 70, y); y += 80; }); g.font = '700 30px "Quicksand",sans-serif'; g.fillText('🌱 CLB AI Thăng Long · Bạn cầm lái – AI chỉ đường', 70, 610); return c.toDataURL('image/jpeg', .86);
  } catch (_) { return ''; }
}
document.addEventListener('error', (e) => { const im = e.target; if (!im || im.tagName !== 'IMG' || im.dataset.fb) return; const card = im.closest('.article-card, .reader-box, .news-card'); if (!card) return; im.dataset.fb = '1'; const t = (card.querySelector('h3, h2, b') || {}).textContent || 'CLB AI Thăng Long'; const u = makeCover(t); if (u) im.src = u; }, true);

document.body.prepend(TPL.content.cloneNode(true));

const $ = (id) => document.getElementById(id);
const clone = (o) => JSON.parse(JSON.stringify(o));
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rich = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
const MEM = {}; let LS_OK = false; try { localStorage.setItem('clbmam__t', '1'); LS_OK = localStorage.getItem('clbmam__t') === '1'; localStorage.removeItem('clbmam__t'); } catch (_) { LS_OK = false; }
const store = {
  get(k, d) { if (k in MEM) return JSON.parse(JSON.stringify(MEM[k])); if (LS_OK) { try { const v = localStorage.getItem('clbmam_' + k); if (v !== null) { MEM[k] = JSON.parse(v); return JSON.parse(v); } } catch (_) {} } return d; },
  set(k, v) { MEM[k] = JSON.parse(JSON.stringify(v)); if (LS_OK) { try { localStorage.setItem('clbmam_' + k, JSON.stringify(v)); } catch (_) {} } },
};
let toastTimer;
function toast(m) { const t = $('toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3400); }
async function copyText(text) { try { await navigator.clipboard.writeText(text); return true; } catch (_) { const tmp = el('textarea'); tmp.value = text; tmp.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(tmp); tmp.select(); let ok = false; try { ok = document.execCommand('copy'); } catch (_) {} tmp.remove(); return ok; } }
const LOGO_FALLBACK = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="#e7f8ef" stroke="#3aa57e" stroke-width="3"/><text x="32" y="42" font-size="30" text-anchor="middle">🌱</text></svg>');

/* ===== Menu ===== */
function closeNav() { $('mainNav').classList.remove('open'); $('menuBtn').setAttribute('aria-expanded', 'false'); $('menuBtn').textContent = '☰'; }
$('menuBtn').addEventListener('click', () => { const open = $('mainNav').classList.toggle('open'); $('menuBtn').setAttribute('aria-expanded', String(open)); $('menuBtn').textContent = open ? '×' : '☰'; });
document.querySelectorAll('#mainNav a').forEach((a) => a.addEventListener('click', closeNav));
document.querySelectorAll('a[href^="#"]').forEach((a) => a.addEventListener('click', (e) => { const id = a.getAttribute('href').slice(1); const t = id && document.getElementById(id); if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); } }));

/* ===== Thông tin, ảnh ===== */
const setText = (id, v) => { if (v) $(id).textContent = v; };
let heroArtOriginal = null;
function renderProfile() {
  const P = DATA.profile || {};
  const logo = P.logo || LOGO_FALLBACK;
  document.querySelectorAll('.club-logo').forEach((im) => { im.src = logo; im.onerror = () => { im.onerror = null; im.src = LOGO_FALLBACK; }; });
  setText('brandName', P.club_name); setText('brandSub', P.club_sub); setText('footName', P.club_name);
  setText('footSchool', [P.school, P.address].filter(Boolean).join(' · '));
  if (P.footer_slogan) $('footSlogan').innerHTML = rich(P.footer_slogan);
  setText('heroKicker', P.hero_kicker); setText('heroL1', P.hero_line1); setText('heroPink', P.hero_pink); setText('heroL2', P.hero_line2); setText('heroPurple', P.hero_purple);
  const art = $('heroArt'); if (heroArtOriginal === null) heroArtOriginal = art.innerHTML;
  if (P.hero_image) { art.classList.add('has-photo'); art.innerHTML = `<img class="hero-photo" src="${esc(P.hero_image)}" alt="Ảnh hoạt động của CLB">`; }
  else if (art.classList.contains('has-photo')) { art.classList.remove('has-photo'); art.innerHTML = heroArtOriginal; }
  const members = (P.members || []).filter((m) => m && m.name);
  $('membersBlock').hidden = !members.length; setText('membersTitle', P.members_title);
  const grid = $('membersGrid'); grid.innerHTML = '';
  members.forEach((m) => {
    const card = el('article', 'member-card');
    if (m.photo) { const im = el('img', 'member-photo'); im.src = m.photo; im.alt = m.name; im.loading = 'lazy'; card.appendChild(im); }
    else card.appendChild(el('div', 'member-photo member-initial', (m.name.trim().split(/\s+/).pop() || '?')[0].toUpperCase()));
    card.append(el('b', '', m.name), el('span', 'member-role', m.role || ''));
    if (m.note) card.appendChild(el('small', '', m.note));
    grid.appendChild(card);
  });
}
function renderGeneral() {
  const g = DATA.general || {};
  setText('announceText', g.announcement);
  if (g.hero_lead) $('heroLead').innerHTML = rich(g.hero_lead);
  if (g.intro_text) $('introText').innerHTML = rich(g.intro_text);
  setText('mottoTitle', g.motto_title);
  if (g.motto_text) $('mottoText').innerHTML = rich(g.motto_text);
  if (g.join_text) $('joinText').innerHTML = rich(g.join_text);
  $('joinHow').innerHTML = rich(g.join_how || '');
  const info = $('joinInfo'); info.innerHTML = '';
  if (g.schedule) info.innerHTML += `<div><span>🗓️</span><div><b>Lịch sinh hoạt</b><p>${rich(g.schedule)}</p></div></div>`;
  if (g.contact) info.innerHTML += `<div><span>📮</span><div><b>Liên hệ</b><p>${rich(g.contact)}</p></div></div>`;
  info.hidden = !info.innerHTML;
  const links = $('joinLinks'); links.innerHTML = '';
  (g.links || []).filter((l) => l && l.url && l.label).forEach((l, i) => { const a = el('a', 'btn ' + (i ? 'btn-outline' : 'btn-primary') + ' full', l.label + ' ↗'); a.href = l.url; a.target = '_blank'; a.rel = 'noopener'; links.appendChild(a); });
  if (!links.children.length) links.appendChild(el('p', 'join-note', 'Hãy hỏi cô phụ trách hoặc ban chủ nhiệm CLB nhé! 🌱'));
  const qr = $('qrRow'); qr.innerHTML = ''; const qrs = (g.qrs || []).filter((q) => q && q.img);
  qr.hidden = !qrs.length;
  qrs.forEach((q) => { const c = el(q.url ? 'a' : 'div', 'qr-card'); if (q.url) { c.href = q.url; c.target = '_blank'; c.rel = 'noopener'; } const im = el('img'); im.src = q.img; im.alt = 'Mã QR ' + (q.label || ''); im.loading = 'lazy'; c.append(im, el('b', '', q.label || '')); qr.appendChild(c); });
}
function renderNews() {
  const list = (DATA.news || []).filter((n) => n && (n.title || n.body));
  $('bang-tin').hidden = !list.length;
  const grid = $('newsGrid'); grid.innerHTML = '';
  list.forEach((n, i) => {
    const card = el('article', 'news-card' + (i === 0 ? ' news-new' : ''));
    if (n.date) card.appendChild(el('time', '', n.date));
    card.appendChild(el('h3', '', n.title || 'Thông báo'));
    if (n.body) { const p = el('p'); p.innerHTML = rich(n.body); card.appendChild(p); }
    if (n.link) { const inner = n.link.startsWith('#'); const a = el('a', 'link-arrow', inner ? 'Xem ngay ↓' : 'Xem chi tiết ↗'); a.href = n.link; if (!inner) { a.target = '_blank'; a.rel = 'noopener'; } card.appendChild(a); }
    grid.appendChild(card);
  });
}

/* ===== Cẩm nang ===== */
const STAGE_COLORS = ['stage-coral', 'stage-purple', 'stage-mint', 'stage-yellow', 'stage-blue'];
let stageIndex = 0;
function renderStages() {
  const box = document.querySelector('.journey-list'); box.innerHTML = '';
  (DATA.stages || []).forEach((s, i) => {
    const b = el('button', 'journey-tab'); b.type = 'button'; b.setAttribute('role', 'tab');
    b.innerHTML = `<span class="journey-n ${STAGE_COLORS[i % 5]}">${i + 1}</span><span><b>${esc(s.name || s.title)}</b><small>${esc(s.short || '')}</small></span><span class="journey-arrow">↗</span>`;
    b.addEventListener('click', () => renderStage(i)); box.appendChild(b);
  });
  renderStage(Math.min(stageIndex, Math.max((DATA.stages || []).length - 1, 0)));
}
function renderStage(i) {
  stageIndex = i; const S = DATA.stages || []; const s = S[i]; const d = $('journeyDetail'); d.innerHTML = ''; if (!s) return;
  d.append(el('div', 'journey-detail-tag', `CHẶNG ${i + 1} / ${S.length}`), el('div', 'journey-detail-icon', s.icon || '✦'), el('h3', '', s.title || ''));
  const p = el('p'); p.innerHTML = rich(s.desc || ''); d.appendChild(p);
  const ul = el('ul'); (s.items || []).forEach((t) => ul.appendChild(el('li', '', t))); d.appendChild(ul);
  const a = el('a', 'link-arrow', 'Xem kho tài liệu của CLB ↓'); a.href = '#tai-lieu'; a.addEventListener('click', (e) => { e.preventDefault(); $('tai-lieu').scrollIntoView({ behavior: 'smooth' }); }); d.appendChild(a);
  document.querySelectorAll('.journey-tab').forEach((b, j) => { b.classList.toggle('active', j === i); b.setAttribute('aria-selected', String(j === i)); });
}

/* ===== Kho tài liệu ===== */
let docFilter = 'Tất cả';
const isImg = (d) => d.kind === 'image' || /\.(png|jpe?g|webp|gif)(\?|$)/i.test(d.url || '');
function docIcon(d) { const u = (d.url || '').toLowerCase(); if (d.kind === 'pdf' || /\.pdf/.test(u)) return '📕'; if (/youtu/.test(u)) return '🎬'; if (/docs\.google|drive\.google/.test(u)) return '📁'; return '📄'; }
function renderDocs() {
  const docs = (DATA.docs || []).filter((d) => !/cẩm nang|infographic|tuyên truyền/i.test(d.category || '')); const q = ($('docSearch').value || '').toLowerCase().trim();
  const hasDocs = docs.length > 0; $('tai-lieu').hidden = !hasDocs; document.querySelectorAll('a[href="#tai-lieu"]').forEach((l) => { l.hidden = !hasDocs; });
  const cats = ['Tất cả', ...new Set(docs.map((d) => d.category || 'Tài liệu'))]; if (!cats.includes(docFilter)) docFilter = 'Tất cả';
  const f = $('docFilters'); f.innerHTML = '';
  cats.forEach((c) => { const b = el('button', 'doc-filter' + (c === docFilter ? ' active' : ''), c); b.type = 'button'; b.addEventListener('click', () => { docFilter = c; renderDocs(); }); f.appendChild(b); });
  const list = docs.filter((d) => (docFilter === 'Tất cả' || (d.category || 'Tài liệu') === docFilter) && (!q || `${d.title} ${d.description} ${d.category}`.toLowerCase().includes(q)));
  const grid = $('docGrid'); grid.innerHTML = '';
  if (!list.length) { grid.appendChild(el('div', 'post-empty', docs.length ? 'Không tìm thấy tài liệu phù hợp.' : 'Chưa có tài liệu nào. Thầy cô sẽ cập nhật sớm! 🌱')); return; }
  list.forEach((d) => {
    const card = el('article', 'doc-card');
    if (isImg(d) || d.thumb) { const im = el('img', 'doc-thumb'); im.loading = 'lazy'; im.alt = d.title; im.src = d.thumb || d.url; card.appendChild(im); }
    else card.appendChild(el('div', 'doc-icon', docIcon(d)));
    const b = el('div', 'doc-body'); b.append(el('span', 'doc-cat', d.category || 'Tài liệu'), el('h3', '', d.title));
    if (d.description) b.appendChild(el('p', '', d.description));
    const act = el('div', 'doc-actions');
    if (isImg(d)) { const v = el('button', 'btn btn-small btn-outline', '🔍 Xem lớn'); v.type = 'button'; v.addEventListener('click', () => showLightbox(d.url)); act.appendChild(v); }
    if (/^\/_blob\//.test(d.url || '')) {
      if (!isImg(d)) { const o = el('a', 'btn btn-small btn-outline', '📖 Xem'); o.href = d.url; o.target = '_blank'; o.rel = 'noopener'; act.appendChild(o); }
      act.appendChild(dlButton(d, 'btn btn-small btn-primary', '⬇ Tải về'));
    } else { const open = el('a', 'btn btn-small btn-primary', 'Mở liên kết ↗'); open.href = d.url; open.target = '_blank'; open.rel = 'noopener'; act.appendChild(open); } b.appendChild(act); card.appendChild(b); grid.appendChild(card);
  });
}
$('docSearch').addEventListener('input', renderDocs);

/* ===== Bình chọn logo ===== */
function renderVote() {
  const V = DATA.vote || {}; const opts = (V.options || []).filter((o) => o && o.img);
  const sec = $('binh-chon'); sec.hidden = !(V.enabled !== false && opts.length); if (sec.hidden) return;
  if (V.title) $('voteTitle').innerHTML = esc(V.title).replace(/^(.*?)(\s\S+\s\S+)$/, '$1<span class="text-purple">$2</span>');
  $('voteIntro').textContent = V.intro || '';
  const end = V.deadline ? new Date(V.deadline + 'T23:59:59+07:00') : null; const now = new Date();
  const over = end && now > end; const days = end ? Math.floor((end - now) / 864e5) : null;
  const dl = $('voteDeadline');
  dl.innerHTML = end ? (over ? '⏰ Bình chọn đã kết thúc. Cảm ơn các bạn đã tham gia! 💜' : `⏳ Hạn bình chọn: <b>hết ngày ${end.toLocaleDateString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })}</b> · ${days > 0 ? `còn <b>${days} ngày</b>` : '<b>hôm nay là ngày cuối!</b>'}`) : '';
  dl.classList.toggle('over', Boolean(over));
  let mine = store.get('vote', null); if (mine !== null) mine = String(mine);
  const g = $('voteGrid'); g.innerHTML = '';
  opts.forEach((o, i) => {
    const c = el('article', 'vote-card vote-c' + (i % 4) + (String(i) === mine ? ' chosen' : ''));
    c.appendChild(el('span', 'vote-num', String(i + 1)));
    const im = el('img'); im.src = o.img; im.alt = o.label || 'Logo ' + (i + 1); im.loading = 'lazy'; im.addEventListener('click', () => showLightbox(o.img)); c.appendChild(im);
    c.appendChild(el('h3', '', o.label || 'Logo ' + (i + 1)));
    if (o.desc) c.appendChild(el('p', '', o.desc));
    const btn = el('button', 'btn ' + (String(i) === mine ? 'btn-chosen' : 'btn-primary'), String(i) === mine ? '✅ Đã chọn' : '☑️ Tích chọn'); btn.type = 'button'; btn.disabled = Boolean(over);
    btn.addEventListener('click', () => {
      store.set('vote', String(i));
      renderVote();
      if (V.url) { window.open(V.url, '_blank', 'noopener'); toast(`Phiếu đã mở! Bấm chọn “Logo ${i + 1}” rồi quay lại web nhé 💜`); }
      else toast('Đã ghi nhận lựa chọn của bạn trên máy này 💜');
    });
    c.appendChild(btn); g.appendChild(c);
  });
}
/* ===== Tải file về máy ===== */
const noAccent = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D');
function fileNameFor(d, blobType) {
  const base = noAccent(d.title || 'tai_lieu').replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 80) || 'tai_lieu';
  let ext = 'pdf'; const t = (blobType || '').toLowerCase();
  if (/png/.test(t)) ext = 'png'; else if (/jpe?g/.test(t)) ext = 'jpg'; else if (/webp/.test(t)) ext = 'webp'; else if (/gif/.test(t)) ext = 'gif'; else if (/pdf/.test(t) || d.kind === 'pdf') ext = 'pdf'; else if (isImg(d)) ext = 'jpg';
  return base + '.' + ext;
}
let DL = null;
function extLink(d) { if (d.ext) return d.ext; if (/cẩm nang/i.test(d.category || '')) { const l = ((DATA.general || {}).links || []).find((x) => /cẩm nang/i.test(x.label || '')); if (l) return l.url; } return ''; }
/* Nút tải: người đã đăng nhập Claude → lưu thẳng; người khác → link mở ngoài (Drive/Canva…) hoặc xem ảnh lớn */
function dlButton(d, cls, label) {
  if (window.CLB_STANDALONE && d.url) { const a = el('a', cls, label); a.href = d.url; a.setAttribute('download', fileNameFor(d, isImg(d) ? 'image/jpeg' : 'application/pdf')); return a; }
  const blob = /^\/_blob\//.test(d.url || '');
  if (blob && DL) { const s = el('button', cls, label); s.type = 'button'; s.addEventListener('click', () => saveDoc(d, s)); return s; }
  const ext = extLink(d) || (blob ? '' : d.url);
  if (ext) { const a = el('a', cls, label.replace('⬇', '⬇') + ' ↗'); a.href = ext; a.target = '_blank'; a.rel = 'noopener'; return a; }
  if (isImg(d)) { const s = el('button', cls, '⬇ Lưu ảnh'); s.type = 'button'; s.addEventListener('click', () => { showLightbox(d.url); toast('📱 Nhấn giữ ảnh (điện thoại) hoặc chuột phải → “Lưu hình ảnh” nhé!'); }); return s; }
  const s = el('button', cls, label); s.type = 'button'; s.addEventListener('click', () => toast('Tài liệu này chưa có link tải ngoài. Nhờ thầy cô gửi qua Zalo nhóm nhé!')); return s;
}
async function saveDoc(d, btn) {
  const url = d.url || ''; if (!url) return;
  const old = btn ? btn.textContent : ''; if (btn) { btn.disabled = true; btn.textContent = '⏳ Đang chuẩn bị…'; }
  try {
    const dl = DL;
    const r = await fetch(url); if (!r.ok) throw new Error('fetch'); const blob = await r.blob();
    if (dl) { await dl.save({ filename: fileNameFor(d, blob.type), data: blob }); toast('✅ Đã tải về máy! Xem trong thư mục Tải xuống nhé.'); }
    else { const o = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = o; a.download = fileNameFor(d, blob.type); document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(o), 60000); }
  } catch (e) {
    if (e && e.code === 'declined') { /* người xem bấm Hủy */ }
    else { const ext = extLink(d); if (ext && btn) { const a = el('a', btn.className, '👉 Bấm lần nữa để mở ↗'); a.href = ext; a.target = '_blank'; a.rel = 'noopener'; btn.replaceWith(a); btn = null; toast('Chưa tải thẳng được – bấm nút một lần nữa để mở bản online nhé.'); } else toast('Chưa tải được (' + ((e && e.code) || 'lỗi') + '). Nhờ thầy cô gửi file qua Zalo nhóm nhé!'); }
  } finally { if (btn) { btn.disabled = false; btn.textContent = old; } }
}
function renderHandbook() {
  const box = $('hbCard'); const d = (DATA.docs || []).find((x) => /cẩm nang/i.test(x.category || '') && x.url);
  box.hidden = !d; box.innerHTML = ''; if (!d) return;
  const cov = el('div', 'hb-cover'); if (d.thumb) { const im = el('img'); im.src = d.thumb; im.alt = 'Bìa ' + d.title; cov.appendChild(im); } else cov.textContent = '📕'; box.appendChild(cov);
  const b = el('div', 'hb-body'); b.append(el('span', 'hb-tag', '📘 CẨM NANG ĐIỆN TỬ · PDF'), el('h3', '', d.title));
  if (d.description) b.appendChild(el('p', '', d.description));
  const act = el('div', 'hb-actions');
  const dlb = dlButton(d, 'btn btn-primary', '⬇ Tải cẩm nang về máy');
  const rd = el('a', 'btn btn-outline', '📖 Đọc online ↗'); rd.href = window.CLB_STANDALONE ? d.url : (extLink(d) || d.url); rd.target = '_blank'; rd.rel = 'noopener';
  act.append(dlb, rd); b.appendChild(act); box.appendChild(b);
}
function renderPosters() {
  const P = (DATA.docs || []).filter((d) => /infographic|tuyên truyền/i.test(d.category || '') && isImg(d));
  $('tuyen-truyen').hidden = !P.length; const g = $('posterGrid'); g.innerHTML = '';
  P.forEach((d, i) => {
    const c = el('article', 'poster-card poster-c' + (i % 3)); const im = el('img'); im.loading = 'lazy'; im.src = d.url; im.alt = d.title; im.addEventListener('click', () => showLightbox(d.url)); c.appendChild(im);
    const s = el('div', 'poster-info'); s.appendChild(el('b', '', d.title)); if (d.description) s.appendChild(el('p', '', d.description));
    const act = el('div', 'doc-actions'); const v = el('button', 'btn btn-small btn-outline', '🔍 Xem lớn'); v.type = 'button'; v.addEventListener('click', () => showLightbox(d.url));
    const s2 = dlButton(d, 'btn btn-small btn-primary', '⬇ Tải ảnh'); act.append(v, s2); s.appendChild(act);
    c.appendChild(s); g.appendChild(c);
  });
}

function showLightbox(src) { $('lightboxImg').src = src; $('lightbox').hidden = false; }
$('lightbox').addEventListener('click', () => { $('lightbox').hidden = true; });

/* ===== Bài viết ===== */
let showCount = 6;
const fmtDate = (d) => { if (!d) return ''; const x = new Date(String(d).length === 10 ? d + 'T00:00:00' : d); return isNaN(x) ? String(d) : x.toLocaleDateString('vi-VN'); };
const sortedArticles = () => (DATA.articles || []).filter((a) => a && a.title && a.published !== false).slice().sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || String(b.date || '').localeCompare(String(a.date || '')));
function renderArticles() {
  const A = sortedArticles(); $('bai-viet').hidden = !A.length;
  const grid = $('articleGrid'); grid.innerHTML = '';
  A.slice(0, showCount).forEach((a, i) => {
    const card = el('article', 'article-card' + (i === 0 && a.pinned ? ' pinned' : '')); card.tabIndex = 0; card.setAttribute('role', 'button'); card.setAttribute('aria-label', 'Đọc bài: ' + a.title);
    if (a.cover) { const im = el('img', 'article-cover'); im.loading = 'lazy'; im.alt = ''; im.src = a.cover; card.appendChild(im); }
    else card.appendChild(el('div', 'article-cover article-cover-empty', '🌱'));
    const b = el('div', 'article-body'); b.append(el('span', 'doc-cat', (a.pinned ? '📌 ' : '') + (a.video ? '▶ ' : '') + (a.category || 'Bài viết')), el('h3', '', a.title));
    if (a.summary) b.appendChild(el('p', '', a.summary));
    b.appendChild(el('div', 'doc-meta', [fmtDate(a.date), a.author].filter(Boolean).join(' · ')));
    card.appendChild(b);
    const open = () => openReader(a); card.addEventListener('click', open); card.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    grid.appendChild(card);
  });
  $('moreArticles').hidden = A.length <= showCount;
}
$('moreArticles').addEventListener('click', () => { showCount += 6; renderArticles(); });
function openReader(a) {
  const box = $('readerBody'); box.innerHTML = '';
  if (a.cover) { const im = el('img', 'reader-cover'); im.src = a.cover; im.alt = ''; if (a.video) { const l = el('a', 'reader-cover-link'); l.href = a.video; l.target = '_blank'; l.rel = 'noopener'; l.appendChild(im); box.appendChild(l); } else box.appendChild(im); }
  box.appendChild(el('span', 'doc-cat', a.category || 'Bài viết'));
  const h = el('h2', '', a.title); h.id = 'readerTitle'; box.appendChild(h);
  box.appendChild(el('div', 'doc-meta', [fmtDate(a.date), a.author ? '✍️ ' + a.author : ''].filter(Boolean).join(' · ')));
  if (a.summary) box.appendChild(el('p', 'reader-lead', a.summary));
  if (a.video) { const v = el('a', 'video-btn'); v.href = a.video; v.target = '_blank'; v.rel = 'noopener'; v.innerHTML = '<span class="vb-play">▶</span><span><b>Xem video</b><small>Mở trên YouTube</small></span>'; box.appendChild(v); }
  String(a.body || '').split(/\n\s*\n/).filter((t) => t.trim()).forEach((para) => { const p = el('p'); p.innerHTML = rich(para.trim()); box.appendChild(p); });
  if ((a.images || []).length) { const g = el('div', 'reader-gallery'); a.images.forEach((src) => { const im = el('img'); im.src = src; im.alt = 'Ảnh trong bài'; im.loading = 'lazy'; im.addEventListener('click', () => showLightbox(src)); g.appendChild(im); }); box.appendChild(g); }
  const src = (a.sources || []).filter((s) => s && /^https?:/.test(s.url || ''));
  if (src.length) { const sb = el('div', 'reader-sources'); sb.appendChild(el('b', '', '📰 Nguồn tham khảo: ')); src.forEach((s, k) => { const l = el('a', '', s.name || s.url); l.href = s.url; l.target = '_blank'; l.rel = 'noopener'; if (k) sb.appendChild(document.createTextNode(' · ')); sb.appendChild(l); }); box.appendChild(sb); }
  $('reader').hidden = false; document.body.style.overflow = 'hidden'; $('readerClose').focus();
}
function closeReader() { $('reader').hidden = true; document.body.style.overflow = ''; }
$('readerClose').addEventListener('click', closeReader);
$('reader').addEventListener('click', (e) => { if (e.target === $('reader')) closeReader(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (!$('lightbox').hidden) $('lightbox').hidden = true; else if (!$('reader').hidden) closeReader(); } });



/* ===== Trò chơi: bốc ngẫu nhiên mỗi lượt ===== */
let qIndex = 0, score = 0, selected = false, ROUND = [];
const shuffle = (arr) => { const x = arr.slice(); for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; } return x; };
const quizPool = () => (DATA.quiz || []).filter((q) => q && q.q && (q.options || []).length >= 2);
const quiz = () => ROUND;
function newRound() {
  const per = Math.max(1, Number(DATA.quiz_per_round) || 8);
  ROUND = shuffle(quizPool()).slice(0, per).map((q) => {
    const order = shuffle(q.options.map((_, i) => i));
    return { q: q.q, explain: q.explain, options: order.map((i) => q.options[i]), ans: order.indexOf(Number(q.ans) || 0) };
  });
}
function resetQuiz() { newRound(); qIndex = 0; score = 0; $('quizCount').textContent = ROUND.length; const qp = $('quizPool'); if (qp) qp.textContent = quizPool().length; $('bestScore').textContent = `${Math.min(store.get('best', 0), ROUND.length)}/${ROUND.length}`; renderQuiz(); }
function renderQuiz() {
  const Q = quiz(); const q = Q[qIndex]; if (!q) return;
  $('quizLevel').textContent = `CÂU ${qIndex + 1} / ${Q.length}`; $('quizScore').textContent = `ĐIỂM: ${score}`; $('quizBar').style.width = `${qIndex / Q.length * 100}%`;
  $('quizQuestion').textContent = q.q; $('quizOptions').innerHTML = ''; $('quizFeedback').hidden = true; $('quizNext').hidden = true; selected = false;
  q.options.forEach((o, i) => { const b = el('button', '', `${String.fromCharCode(65 + i)}.  ${o}`); b.type = 'button'; b.addEventListener('click', () => pick(i)); $('quizOptions').appendChild(b); });
}
function pick(i) {
  if (selected) return; selected = true; const Q = quiz(); const q = Q[qIndex]; const ok = i === q.ans; if (ok) { score++; bumpDay('quizOk', 1); gainXP(10, 'quiz'); }
  $('quizScore').textContent = `ĐIỂM: ${score}`;
  [...$('quizOptions').children].forEach((b, j) => { b.disabled = true; if (j === q.ans) b.classList.add('correct'); else if (j === i) b.classList.add('wrong'); });
  const f = $('quizFeedback'); f.hidden = false; f.className = 'quiz-feedback' + (ok ? '' : ' error'); f.textContent = (ok ? '✓ Chính xác! ' : '✕ Chưa đúng. ') + (q.explain || '');
  $('quizNext').hidden = false; $('quizNext').textContent = qIndex === Q.length - 1 ? 'Xem kết quả →' : 'Câu tiếp theo →'; $('quizBar').style.width = `${(qIndex + 1) / Q.length * 100}%`;
}
$('quizNext').addEventListener('click', () => {
  const Q = quiz(); if (qIndex >= Q.length) { resetQuiz(); return; }
  qIndex++; if (qIndex < Q.length) { renderQuiz(); return; }
  const best = Math.max(score, Number(store.get('best', 0))); store.set('best', best); $('bestScore').textContent = `${Math.min(best, Q.length)}/${Q.length}`;
  const pct = score / Q.length;
  { const P = player(); P.games++; if (pct === 1) P.perfect++; savePlayer(P); bumpDay('quizRounds', 1); const bonus = pct === 1 ? 50 : pct >= .7 ? 20 : 0; if (bonus) { gainXP(bonus, 'quiz'); confetti(pct === 1 ? 200 : 110); } }
  $('quizLevel').textContent = 'HOÀN THÀNH';
  $('quizQuestion').textContent = pct === 1 ? 'Xuất sắc! Bạn là Thợ săn lỗi AI chính hiệu! 🏆' : pct >= 0.7 ? 'Giỏi lắm! Bạn đã có “con mắt” kiểm chứng tốt. 🔍' : 'Cố lên! Mỗi lỗi phát hiện được giúp bạn tỉnh táo hơn. 🌱';
  $('quizOptions').innerHTML = ''; $('quizOptions').appendChild(el('p', '', `Bạn trả lời đúng ${score}/${Q.length} câu. Chơi lượt mới để gặp tình huống khác nhé!`)); $('quizFeedback').hidden = true; $('quizNext').textContent = '↻ Chơi lượt mới';
  qIndex = Q.length;
});

/* ===== Thử thách + cây Mầm ===== */
function plantSVG(stage) {
  // stage 0..7
  const st = Math.max(0, Math.min(7, stage));
  const h = [0, 26, 44, 66, 86, 104, 116, 124][st];
  const leaf = (x, y, r, flip, c = '#4cc38a') => { const cx = flip ? x - r * 0.55 : x + r * 0.55; return `<ellipse cx="${cx}" cy="${y}" rx="${r * 0.62}" ry="${r * 0.3}" transform="rotate(${flip ? 25 : -25} ${cx} ${y})" fill="${c}" stroke="#2a9d6f" stroke-width="2"/>`; };
  let p = '';
  if (st === 0) p = `<ellipse cx="100" cy="146" rx="9" ry="6" fill="#a0673a"/><path d="M100 140 q3 -6 0 -9" stroke="#4cc38a" stroke-width="3" fill="none" stroke-linecap="round"/>`;
  else {
    p += `<path d="M100 150 C ${100 - st} ${150 - h * 0.5}, ${100 + st} ${150 - h * 0.8}, 100 ${150 - h}" stroke="#2a9d6f" stroke-width="${3 + st * 0.7}" fill="none" stroke-linecap="round"/>`;
    const pairs = Math.min(st, 5);
    for (let i = 0; i < pairs; i++) { const y = 150 - h * (0.35 + i * 0.14); const r = 14 + i * 2 + st; p += leaf(100, y, r, i % 2 === 0) + leaf(100, y - 6, r * 0.85, i % 2 === 1); }
    if (st >= 4) p += `<circle cx="100" cy="${150 - h - 4}" r="${10 + st * 3}" fill="#5fd39a" stroke="#2a9d6f" stroke-width="2.5"/>`;
    if (st >= 5) p += `<circle cx="${86 - st}" cy="${150 - h + 8}" r="${12 + st}" fill="#4cc38a" stroke="#2a9d6f" stroke-width="2.5"/><circle cx="${114 + st}" cy="${150 - h + 8}" r="${12 + st}" fill="#4cc38a" stroke="#2a9d6f" stroke-width="2.5"/>`;
    if (st >= 6) [[-14, -10], [12, -14], [0, 6], [-22, 14], [24, 12]].forEach(([dx, dy]) => { p += `<g transform="translate(${100 + dx} ${150 - h + dy})"><circle r="5" fill="#ffb3cf"/><circle r="2.2" fill="#f5c518"/></g>`; });
    if (st >= 7) [[-20, -2], [18, 0], [-4, 18], [26, 22]].forEach(([dx, dy]) => { p += `<circle cx="${100 + dx}" cy="${150 - h + dy}" r="6.5" fill="#ff6b6b" stroke="#c94a4a" stroke-width="1.5"/>`; });
  }
  const sparkle = st >= 7 ? `<text x="38" y="40" font-size="20">✨</text><text x="150" y="58" font-size="18">✨</text>` : '';
  return `<svg viewBox="0 0 200 200" role="img" aria-label="Cây Mầm giai đoạn ${st}/7">${sparkle}<g class="plant">${p}</g>
    <path d="M60 150 h80 l-10 42 h-60z" fill="#f28c5a" stroke="#c9653a" stroke-width="3" stroke-linejoin="round"/><rect x="55" y="144" width="90" height="12" rx="6" fill="#f6a477" stroke="#c9653a" stroke-width="3"/>
    <ellipse cx="100" cy="148" rx="38" ry="4" fill="#8a5a3b"/>
    <g class="can" id="wateringCan"><path d="M150 70 h26 v22 h-26z" fill="#6aa9f2" stroke="#2f6fd6" stroke-width="2.5"/><path d="M150 76 l-20 -10" stroke="#2f6fd6" stroke-width="5" stroke-linecap="round"/><path d="M176 74 q12 0 10 14" stroke="#2f6fd6" stroke-width="3" fill="none"/></g>
    <g class="drops-anim"><circle cx="126" cy="74" r="3" fill="#6aa9f2"/><circle cx="120" cy="86" r="3" fill="#6aa9f2"/><circle cx="114" cy="98" r="3" fill="#6aa9f2"/></g></svg>`;
}
const GIFT_DEFAULT = [{ at: 3, emoji: '🌱', title: 'Huy hiệu Mầm chăm chỉ', desc: '' }, { at: 5, emoji: '🔍', title: 'Huy hiệu Thợ săn lỗi AI', desc: '' }, { at: 7, emoji: '🏆', title: 'Giấy chứng nhận Người cầm lái AI', desc: '' }];
const gifts = () => ((DATA.tree && DATA.tree.gifts) || GIFT_DEFAULT).filter((g) => g && g.title).map((g) => ({ ...g, at: Math.max(1, Number(g.at) || 1) })).sort((a, b) => a.at - b.at);
let lastWater = null;
function renderChallenge(justWatered) {
  const days = DATA.days || []; let ck = store.get('challenge', []); if (!Array.isArray(ck)) ck = [];
  const list = $('dayList'), dots = $('challengeDots'); list.innerHTML = ''; dots.innerHTML = '';
  days.forEach((d, i) => {
    const label = el('label', 'day-item' + (ck[i] ? ' completed' : '')); const inp = el('input'); inp.type = 'checkbox'; inp.checked = Boolean(ck[i]); inp.setAttribute('aria-label', `Nhiệm vụ ${i + 1}: ${d}`);
    inp.addEventListener('change', () => {
      const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
      const dates = store.get('cdates', {});
      if (inp.checked && (DATA.tree || {}).one_per_day !== false && Object.values(dates).includes(today)) { inp.checked = false; toast('💧 Hôm nay bạn đã tưới cây rồi! Mai quay lại làm nhiệm vụ tiếp nhé 🌱'); return; }
      if (inp.checked && i > 0 && !ck[i - 1]) { inp.checked = false; toast('Làm lần lượt nhé: hoàn thành nhiệm vụ ' + i + ' trước đã!'); return; }
      ck[i] = inp.checked; if (inp.checked) dates[i] = today; else delete dates[i];
      store.set('challenge', ck); store.set('cdates', dates); renderChallenge(inp.checked);
    });
    label.append(el('span', 'day-number', `NGÀY ${i + 1}`), el('span', 'day-text', d), inp); list.appendChild(label); dots.appendChild(el('span', ck[i] ? 'on' : ''));
  });
  const total = days.length || 1; const sum = days.filter((_, k) => ck[k]).length;
  const stage = Math.round(sum / total * 7);
  $('garden').innerHTML = plantSVG(stage);
  $('doneCount').textContent = sum; $('doneCount').nextElementSibling.textContent = `/ ${days.length} lần tưới`;
  $('waterDrops').textContent = '💧'.repeat(Math.min(sum, 10));
  const G = gifts(); const maxAt = G.length ? Math.max(...G.map((g) => g.at)) : total;
  const scale = (at) => Math.round(at / maxAt * total) || 1; // co giãn khi số nhiệm vụ khác 7
  const opened = store.get('gifts', {});
  const next = G.find((g) => sum < scale(g.at));
  $('challengeMessage').textContent = sum === 0 ? 'Hoàn thành 1 nhiệm vụ = tưới cây 1 lần 💧' : next ? `Tưới thêm ${scale(next.at) - sum} lần nữa để nhận ${next.emoji} ${next.title}!` : 'Cây Mầm đã ra hoa kết trái! Bạn thật tuyệt vời! 🍎';
  const row = $('giftRow'); row.innerHTML = '';
  G.forEach((g) => {
    const ready = sum >= scale(g.at); const b = el('button', 'gift' + (ready ? (opened[g.title] ? ' opened' : ' ready') : ''));
    b.type = 'button'; b.innerHTML = `<span class="gi">${ready ? (opened[g.title] ? esc(g.emoji) : '🎁') : '🔒'}</span><small>${scale(g.at)} lần</small>`;
    b.title = g.title; b.disabled = !ready; b.addEventListener('click', () => openGift(g)); row.appendChild(b);
  });
  renderSaveCode();
  if (justWatered) {
    const svg = $('garden').querySelector('svg'); svg.classList.add('watering'); setTimeout(() => svg.classList.remove('watering'), 1600);
    gainXP(10, 'tree'); const hit = G.find((g) => sum === scale(g.at) && !opened[g.title]);
    toast(hit ? `🎁 Bạn nhận được quà: ${hit.title}! Bấm vào hộp quà để mở.` : '💧 Đã tưới cây! Cây Mầm lớn thêm rồi.');
  }
}

/* ===== Mã lưu cây (dùng khi máy không tự lưu được) ===== */
const B36 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'; /* 32 kí tự, bỏ I L O U cho khỏi nhầm */
const enc32 = (n) => { let s = ''; do { s = B36[n % 32] + s; n = Math.floor(n / 32); } while (n > 0); return s; };
const dec32 = (s) => { let n = 0; for (const ch of s) { const v = B36.indexOf(ch); if (v < 0) return NaN; n = n * 32 + v; } return n; };
function ckSum(s) { let h = 7; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) % 1024; return B36[Math.floor(h / 32)] + B36[h % 32]; }
function makeCode() {
  const ck = store.get('challenge', []); const n = (DATA.days || []).filter((_, k) => ck[k]).length;
  const P = Object.assign({ xp: 0, streak: 0, lastPlay: '' }, store.get('player', {}));
  if (!n && !P.xp) return '';
  const dates = Object.values(store.get('cdates', {})).filter(Boolean).sort(); const last = dates[dates.length - 1] || '2026-01-01';
  const op = store.get('gifts', {}); let bits = 0; gifts().forEach((g, i) => { if (op[g.title]) bits |= 1 << i; });
  const ymd = (s) => (s || '2026-01-01').slice(2).replace(/-/g, '');
  const digits = '9' + String(n).padStart(2, '0') + String(Math.min(9, bits)) + ymd(last) + String(Math.min(99999, P.xp)).padStart(5, '0') + String(Math.min(999, P.streak)).padStart(3, '0') + ymd(P.lastPlay);
  let v = BigInt(digits); let body = ''; while (v > 0n) { body = B36[Number(v % 32n)] + body; v /= 32n; }
  return 'MAM-' + body + ckSum(body);
}
function loadCode(raw) {
  const s = String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/^MAM/, '').replace(/O/g, '0').replace(/[IL]/g, '1'); if (s.length < 4) return false;
  const body = s.slice(0, -2); if (ckSum(body) !== s.slice(-2)) return false;
  if (body.length > 11) { // mã kiểu mới: có cả XP
    let v = 0n; for (const ch of body) { const k = B36.indexOf(ch); if (k < 0) return false; v = v * 32n + BigInt(k); }
    const d = v.toString(); if (d.length !== 24 || d[0] !== '9') return false;
    const n2 = Number(d.slice(1, 3)), bits2 = Number(d[3]), ty = d.slice(4, 10), xp = Number(d.slice(10, 15)), stk = Number(d.slice(15, 18)), py = d.slice(18, 24);
    const tot = (DATA.days || []).length; if (n2 > tot) return false;
    const toD = (s) => '20' + s.slice(0, 2) + '-' + s.slice(2, 4) + '-' + s.slice(4, 6);
    const ck2 = []; const dt2 = {}; for (let i = 0; i < n2; i++) { ck2[i] = true; dt2[i] = i === n2 - 1 ? toD(ty) : '2000-01-01'; }
    const op2 = {}; gifts().forEach((g, i) => { if (bits2 & (1 << i)) op2[g.title] = true; });
    store.set('challenge', ck2); store.set('cdates', dt2); store.set('gifts', op2);
    const P = Object.assign({}, store.get('player', {})); if (xp >= (P.xp || 0)) { P.xp = xp; P.streak = stk; P.lastPlay = xp ? toD(py) : ''; P.days = P.days || {}; store.set('player', P); }
    if (typeof renderPlayer === 'function') renderPlayer();
    return { n: n2, xp };
  }
  const num = dec32(body); if (!isFinite(num)) return false;
  const ymd = String(num % 1000000).padStart(6, '0'); const rest = Math.floor(num / 1000000); const n = rest % 100; const bits = Math.floor(rest / 100);
  const total = (DATA.days || []).length; if (n < 1 || n > total) return false;
  const last = '20' + ymd.slice(0, 2) + '-' + ymd.slice(2, 4) + '-' + ymd.slice(4, 6);
  const ck = []; const dates = {}; for (let i = 0; i < n; i++) { ck[i] = true; dates[i] = i === n - 1 ? last : '2000-01-01'; }
  const op = {}; gifts().forEach((g, i) => { if (bits & (1 << i)) op[g.title] = true; });
  store.set('challenge', ck); store.set('cdates', dates); store.set('gifts', op); return { n, xp: 0 };
}
function renderSaveCode() {
  const c = makeCode(); $('saveCode').textContent = c || 'Tưới cây lần đầu để nhận mã'; if ($('pcCode')) $('pcCode').textContent = c || 'chơi để nhận mã';
  $('copyCode').hidden = !c;
  $('saveHint').innerHTML = LS_OK ? 'Máy này tự nhớ tiến độ. Nhưng nếu đổi máy, xóa lịch sử hay mở bằng trình duyệt khác thì cây sẽ về 0 – hãy <b>ghi lại mã</b> để mở lại nhé.' : '⚠️ Trình duyệt này <b>không tự lưu được</b> – tắt web là cây về 0. Sau mỗi lần tưới, hãy <b>chép mã vào vở</b> hoặc chụp màn hình, lần sau nhập mã để cây lớn tiếp.';
}
function openGift(g) {
  const opened = store.get('gifts', {}); opened[g.title] = true; store.set('gifts', opened);
  const final = g.at === Math.max(...gifts().map((x) => x.at));
  const card = $('giftCard'); card.innerHTML = '';
  const x = el('button', 'reader-close', '×'); x.type = 'button'; x.setAttribute('aria-label', 'Đóng'); x.addEventListener('click', closeGift); card.appendChild(x);
  confetti(170); card.append(el('div', 'gift-emoji', g.emoji || '🎁'), el('h3', '', g.title));
  if (g.desc) card.appendChild(el('p', '', g.desc));
  if (final) {
    const f = el('div', 'fld'); const lb = el('label', '', 'Tên của bạn (để in lên giấy chứng nhận)'); const inp = el('input'); inp.maxLength = 40; inp.placeholder = 'VD: Nguyễn Văn An – 10A1'; inp.value = store.get('certName', ''); f.append(lb, inp); card.appendChild(f);
    const ph = el('label', 'cert-photo-btn'); const fi = el('input'); fi.type = 'file'; fi.accept = 'image/*'; fi.hidden = true; ph.append(fi, document.createTextNode('📷 Ghép ảnh của bạn vào giấy chứng nhận')); card.appendChild(ph);
    card.appendChild(el('small', 'hint', 'Ảnh chỉ dùng để vẽ giấy chứng nhận ngay trên máy bạn, không gửi đi đâu cả.'));
    const cv = el('canvas', 'cert-canvas'); cv.width = 1200; cv.height = 850; card.appendChild(cv);
    const draw = () => { store.set('certName', inp.value.trim()); drawCert(cv, inp.value.trim() || 'Người cầm lái AI'); };
    fi.addEventListener('change', () => { const f2 = fi.files && fi.files[0]; if (!f2) return; const im = new Image(); im.onload = () => { certPhoto = im; draw(); }; im.src = URL.createObjectURL(f2); });
    if (!certLogo && DATA.profile && DATA.profile.logo) { const lg = new Image(); lg.onload = () => { certLogo = lg; draw(); }; lg.src = DATA.profile.logo; }
    inp.addEventListener('input', draw); draw();
    const act = el('div', 'doc-actions'); const sv = el('button', 'btn btn-small btn-primary', '⬇ Lưu giấy chứng nhận'); sv.type = 'button';
    sv.addEventListener('click', async () => {
      const dl = window.claude && window.claude.use ? await window.claude.use('downloads').catch(() => null) : null;
      if (dl) { cv.toBlob(async (blob) => { try { await dl.save({ filename: 'Giay_chung_nhan_Nguoi_cam_lai_AI.png', data: blob }); } catch (e) { if (!e || e.code !== 'declined') toast('Chưa lưu được – hãy chụp màn hình nhé!'); } }, 'image/png'); }
      else { try { const a = document.createElement('a'); a.href = cv.toDataURL('image/png'); a.download = 'Giay_chung_nhan_Nguoi_cam_lai_AI.png'; a.click(); } catch (_) { toast('Hãy chụp màn hình giấy chứng nhận nhé!'); } }
    });
    act.append(sv, el('small', 'hint', 'Không lưu được thì chụp màn hình nhé!')); card.appendChild(act);
  }
  $('giftModal').hidden = false; renderChallenge(false);
}
function closeGift() { $('giftModal').hidden = true; }
$('giftModal').addEventListener('click', (e) => { if (e.target === $('giftModal')) closeGift(); });
let certPhoto = null, certLogo = null;
function drawCert(cv, name) {
  const c = cv.getContext('2d'), W = cv.width, H = cv.height; const F = '"Baloo 2","Quicksand",system-ui,sans-serif';
  const rr = (x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
  const star = (x, y, r, col) => { c.save(); c.translate(x, y); c.fillStyle = col; c.beginPath(); for (let i = 0; i < 10; i++) { const rad = i % 2 ? r * .45 : r; const ang = Math.PI / 5 * i - Math.PI / 2; c.lineTo(Math.cos(ang) * rad, Math.sin(ang) * rad); } c.closePath(); c.fill(); c.restore(); };
  // nền pastel + chấm bi
  const g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#fff3fb'); g.addColorStop(.5, '#f3efff'); g.addColorStop(1, '#e9fbff'); c.fillStyle = g; c.fillRect(0, 0, W, H);
  for (let i = 0; i < 70; i++) { c.fillStyle = ['#ffd45c55', '#ff8fb155', '#9a7bff44', '#5fd0e855'][i % 4]; c.beginPath(); c.arc((i * 173) % W, (i * 97) % H, 4 + (i % 5) * 2, 0, 7); c.fill(); }
  // khung bo tròn 2 lớp
  rr(30, 30, W - 60, H - 60, 46); c.lineWidth = 16; c.strokeStyle = '#ffd45c'; c.stroke();
  rr(56, 56, W - 112, H - 112, 34); c.lineWidth = 5; c.setLineDash([16, 12]); c.strokeStyle = '#9a7bff'; c.stroke(); c.setLineDash([]);
  // ruy băng tiêu đề
  c.fillStyle = '#ff6b9a'; c.beginPath(); c.moveTo(250, 92); c.lineTo(W - 250, 92); c.lineTo(W - 220, 140); c.lineTo(W - 250, 188); c.lineTo(250, 188); c.lineTo(220, 140); c.closePath(); c.fill();
  c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = `800 56px ${F}`; c.fillText('GIẤY CHỨNG NHẬN', W / 2, 142);
  c.fillStyle = '#5b3fd6'; c.font = `800 26px ${F}`; c.fillText(((DATA.profile && DATA.profile.club_name) || 'CLB AI THĂNG LONG').toUpperCase() + ' · THỬ THÁCH 15 NGÀY', W / 2, 222);
  // khung ảnh tròn
  const px = 270, py = 470, pr = 160;
  c.save(); c.beginPath(); c.arc(px, py, pr + 18, 0, 7); c.fillStyle = '#fff'; c.shadowColor = '#5b3fd655'; c.shadowBlur = 24; c.fill(); c.restore();
  const rg = c.createLinearGradient(px - pr, py - pr, px + pr, py + pr); rg.addColorStop(0, '#7b5cff'); rg.addColorStop(1, '#ff6b9a'); c.beginPath(); c.arc(px, py, pr + 12, 0, 7); c.lineWidth = 12; c.strokeStyle = rg; c.stroke();
  c.save(); c.beginPath(); c.arc(px, py, pr, 0, 7); c.clip();
  if (certPhoto) { const s = Math.max(pr * 2 / certPhoto.width, pr * 2 / certPhoto.height); const w = certPhoto.width * s, h = certPhoto.height * s; c.drawImage(certPhoto, px - w / 2, py - h / 2, w, h); }
  else { c.fillStyle = '#f1edff'; c.fillRect(px - pr, py - pr, pr * 2, pr * 2); c.font = `120px ${F}`; c.fillText('🧑‍🎓', px, py - 10); c.fillStyle = '#7b5cff'; c.font = `700 22px ${F}`; c.fillText('Thêm ảnh của bạn', px, py + 100); }
  c.restore();
  ['#ffd45c', '#ff6b9a', '#5fd0e8', '#22c39a'].forEach((col, i) => star(px + Math.cos(i * 1.6 + .6) * (pr + 40), py + Math.sin(i * 1.6 + .6) * (pr + 40), 16 + i * 2, col));
  // chữ bên phải
  const tx = 760; c.fillStyle = '#4a4f73'; c.font = `700 30px ${F}`; c.fillText('Chúc mừng bạn', tx, 330);
  let fs = 66; c.font = `800 ${fs}px ${F}`; while (c.measureText(name).width > 640 && fs > 30) { fs -= 3; c.font = `800 ${fs}px ${F}`; }
  const ng = c.createLinearGradient(tx - 300, 0, tx + 300, 0); ng.addColorStop(0, '#5b3fd6'); ng.addColorStop(1, '#e2508a'); c.fillStyle = ng; c.fillText(name, tx, 400);
  c.strokeStyle = '#ffd45c'; c.lineWidth = 6; c.lineCap = 'round'; c.beginPath(); c.moveTo(tx - 230, 448); c.quadraticCurveTo(tx, 468, tx + 230, 448); c.stroke();
  c.fillStyle = '#4a4f73'; c.font = `600 27px ${F}`; c.fillText('đã kiên trì 15 ngày tự học thông minh', tx, 505); c.fillText('và chính thức trở thành', tx, 545);
  c.fillStyle = '#12a884'; c.font = `800 52px ${F}`; c.fillText('🌳 NGƯỜI CẦM LÁI AI 🌳', tx, 615);
  c.fillStyle = '#7b5cff'; c.font = `italic 700 25px ${F}`; c.fillText('“Tự nghĩ trước – Hỏi AI sau”', tx, 672);
  // con dấu tròn
  const sx = W - 170, sy = H - 165; c.save(); c.translate(sx, sy); c.rotate(-.18); c.beginPath(); c.arc(0, 0, 72, 0, 7); c.fillStyle = '#ffd45c'; c.fill(); c.lineWidth = 5; c.strokeStyle = '#e09b00'; c.setLineDash([6, 5]); c.beginPath(); c.arc(0, 0, 60, 0, 7); c.stroke(); c.setLineDash([]);
  c.fillStyle = '#7a4a00'; c.font = `800 22px ${F}`; c.fillText('15 NGÀY', 0, -14); c.font = `800 34px ${F}`; c.fillText('🌱✓', 0, 22); c.restore();
  // logo CLB + chân
  if (certLogo) { c.save(); c.beginPath(); c.arc(140, H - 150, 54, 0, 7); c.clip(); c.drawImage(certLogo, 86, H - 204, 108, 108); c.restore(); c.beginPath(); c.arc(140, H - 150, 54, 0, 7); c.lineWidth = 4; c.strokeStyle = '#9a7bff'; c.stroke(); }
  c.fillStyle = '#6b6894'; c.font = `600 23px ${F}`; c.fillText(`${(DATA.profile && DATA.profile.school) || 'Trường THCS&THPT Thăng Long'} · ${new Date().toLocaleDateString('vi-VN')}`, W / 2, H - 92);
}
let resetArmed = false;
$('resetChallenge').addEventListener('click', () => { if (!resetArmed) { resetArmed = true; $('resetChallenge').textContent = 'Bấm lần nữa để trồng lại'; setTimeout(() => { resetArmed = false; $('resetChallenge').textContent = '↻ Trồng lại từ đầu'; }, 3000); return; } resetArmed = false; $('resetChallenge').textContent = '↻ Trồng lại từ đầu'; store.set('challenge', []); store.set('gifts', {}); store.set('cdates', {}); renderChallenge(false); toast('🌱 Đã gieo hạt mới!'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('giftModal').hidden) closeGift(); });

/* ===== Mầm AI ===== */
let sample = null; const chatHistory = []; let chatBusy = false;
function toggleChat(next) { $('chatPanel').hidden = !next; $('chatToggle').setAttribute('aria-expanded', String(next)); if (next) $('chatInput').focus(); }
$('chatToggle').addEventListener('click', () => toggleChat($('chatPanel').hidden));
$('chatClose').addEventListener('click', () => toggleChat(false));
function appendChat(type, msg) { const d = el('div', `chat-line ${type}`); if (type.startsWith('bot')) d.innerHTML = rich(msg); else d.textContent = msg; $('chatMessages').appendChild(d); $('chatMessages').scrollTop = $('chatMessages').scrollHeight; return d; }
/* ===== Bộ não Mầm (không cần đăng nhập) ===== */
const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
const HELP_LINE = '📞 **Tổng đài 111** (bảo vệ trẻ em, miễn phí, 24/7). Nếu đang nguy hiểm ngay lúc này: gọi **113** (công an) hoặc **115** (cấp cứu).';
const CRISIS = [
  { keys: ['muon chet', 'tu tu', 'tu sat', 'khong muon song', 'chan song', 'ket thuc cuoc doi', 'bien mat khoi', 'tu lam dau', 'tu hai', 'cat tay', 'rach tay', 'nhay cau', 'uong thuoc ngu'],
    reply: 'Mầm rất lo cho bạn và cảm ơn bạn đã nói ra. 💚 Những cảm xúc này rất nặng nề, và bạn **không phải chịu một mình**.\n\nHãy nói **ngay bây giờ** với một người lớn bạn tin: bố mẹ, thầy cô chủ nhiệm, cô phụ trách CLB, hoặc người thân.\n' + HELP_LINE + '\n\nBạn có thể kể với Mầm: hôm nay có chuyện gì làm bạn buồn vậy?' },
  { keys: ['bi danh', 'bi dap', 'bi xam hai', 'bi so mo', 'bi ep', 'bi de doa', 'bi tong tien', 'bi bat coc', 'bi bao luc', 'bi quay roi', 'gui anh nong', 'doi gui anh', 'bi lo anh'],
    reply: 'Mầm rất tiếc vì bạn gặp chuyện này. **Đó không phải lỗi của bạn.** 💚\n\n• Hãy kể ngay với người lớn bạn tin: bố mẹ, thầy cô, cô phụ trách CLB.\n• Không gửi thêm ảnh, tiền hay thông tin gì cho người đang ép buộc bạn. Giữ lại tin nhắn làm bằng chứng.\n' + HELP_LINE }
];
const INTENTS = [
  // ---- Góc tâm sự ----
  { keys: ['buon', 'chan qua', 'met moi', 'co don', 'khoc', 'tam trang', 'khong vui', 'stress', 'tram cam', 'that vong'],
    reply: 'Mầm nghe bạn nè. 🫂 Ai cũng có lúc buồn và mệt, điều đó rất bình thường.\n\n• Thử hít thở chậm: hít vào 4 giây, giữ 4 giây, thở ra 6 giây, lặp lại 5 lần.\n• Viết ra giấy điều làm bạn buồn, rồi đi dạo, nghe một bài nhạc nhẹ.\n• Kể cho một người bạn tin: bạn thân, bố mẹ, thầy cô. Nói ra sẽ nhẹ lòng hơn nhiều.\n\nNếu nỗi buồn kéo dài nhiều ngày, hãy nói với thầy cô chủ nhiệm nhé. Bạn muốn kể Mầm nghe chuyện gì không?' },
  { keys: ['ap luc', 'so thi', 'lo thi', 'thi truot', 'diem kem', 'diem thap', 'bi diem', 'hoc khong vao', 'qua tai', 'nhieu bai qua', 'so bi mang'],
    reply: 'Áp lực học tập ai cũng từng gặp, bạn không đơn độc đâu. 💪\n\n• Chia nhỏ: mỗi buổi chỉ chọn **1–2 việc** quan trọng nhất.\n• Học 25 phút, nghỉ 5 phút (cách Pomodoro).\n• Một bài kiểm tra thấp điểm không nói lên bạn là ai. Hãy xem sai ở đâu để lần sau tốt hơn.\n• Ngủ đủ 7–8 tiếng: não nhớ bài khi ngủ đó!\n\nNếu bố mẹ kỳ vọng nhiều quá, bạn thử nói thật cảm xúc của mình, hoặc nhờ thầy cô chủ nhiệm nói giúp nhé.' },
  { keys: ['ban be', 'gian nhau', 'cai nhau', 'bi co lap', 'khong ai choi', 'bi noi xau', 'ban than', 'nghi choi', 'bi ghet', 'bi tay chay'],
    reply: 'Chuyện bạn bè đôi khi làm mình buồn lắm. 💛\n\n• Bình tĩnh trước, đừng nhắn tin lúc đang giận.\n• Nói chuyện riêng, bắt đầu bằng “Mình cảm thấy…” thay vì trách móc.\n• Nếu bị nói xấu, cô lập hay bắt nạt (kể cả trên mạng), hãy giữ bằng chứng và **báo thầy cô** ngay.\n• Tìm thêm bạn mới ở CLB, nhóm học tập: ở CLB AI Thăng Long luôn chào đón bạn! 🌱' },
  { keys: ['bat nat', 'bi treu', 'bi che', 'body shaming', 'bi chui', 'bi chi trich tren mang', 'cyberbully'],
    reply: 'Bị bắt nạt là điều không ai đáng phải chịu. **Không phải lỗi của bạn.** 💚\n\n• Đừng đáp trả bằng lời lẽ xấu. Chụp màn hình, giữ bằng chứng.\n• Chặn và báo cáo tài khoản bắt nạt trên mạng xã hội.\n• Kể ngay với thầy cô chủ nhiệm hoặc bố mẹ, họ có thể giúp bạn.\n' + HELP_LINE },
  { keys: ['bo me', 'gia dinh', 'bi mang', 'cai nhau voi bo', 'cai nhau voi me', 'bo me khong hieu', 'ba me', 'bi so sanh'],
    reply: 'Gia đình đôi khi chưa hiểu nhau, nhưng ai cũng thương bạn theo cách của họ. 🏡\n\n• Chọn lúc mọi người vui vẻ để nói chuyện.\n• Nói cảm xúc: “Con cảm thấy… khi…”, và nói điều con mong muốn.\n• Lắng nghe lý do của bố mẹ nữa nhé.\n• Nếu khó nói trực tiếp, bạn có thể viết thư, hoặc nhờ thầy cô chủ nhiệm giúp.\n\nNếu ở nhà có bạo lực làm bạn sợ hãi: ' + HELP_LINE },
  { keys: ['thich mot ban', 'crush', 'tinh cam', 'nguoi yeu', 'that tinh', 'to tinh', 'yeu som'],
    reply: 'Rung động với một bạn là cảm xúc rất tự nhiên ở tuổi của bạn. 🌸\n\n• Hãy là bạn tốt trước: tôn trọng, lịch sự, cùng nhau tiến bộ.\n• Đừng để cảm xúc làm bạn bỏ bê việc học hay giấc ngủ.\n• Không gửi ảnh riêng tư hay thông tin cá nhân cho ai qua mạng, dù tin tưởng đến đâu.\n• Buồn vì bị từ chối là bình thường, nó sẽ qua. Tâm sự với bạn thân hoặc người lớn bạn tin nhé.' },
  { keys: ['nghien dien thoai', 'nghien game', 'choi game nhieu', 'luot tiktok', 'luot mang', 'thuc khuya', 'mat ngu', 'khong ngu duoc', 'buon ngu'],
    reply: 'Dùng điện thoại nhiều quá dễ làm mình mệt và mất tập trung. 📵\n\n• Đặt giờ: tắt điện thoại trước khi ngủ 30 phút.\n• Để điện thoại xa bàn học, bật chế độ không làm phiền.\n• Đặt mục tiêu nhỏ: hôm nay giảm 30 phút lướt mạng.\n• Ngủ đủ 7–8 tiếng giúp bạn học tốt và vui vẻ hơn.\n\nThử thách cây Mầm ở mục **Thử thách** cũng giúp bạn tạo thói quen tốt đó! 🌱' },
  { keys: ['tu ti', 'khong tu tin', 'xau', 'beo', 'gay qua', 'kem coi', 'vo dung', 'thua kem', 'nhut nhat', 'ngai noi'],
    reply: 'Bạn quý giá hơn bạn nghĩ nhiều đó! 🌟\n\n• Mỗi người có điểm mạnh riêng. Thử viết ra 3 điều bạn làm tốt.\n• Đừng so sánh mình với “phiên bản đẹp nhất” trên mạng xã hội của người khác.\n• Bắt đầu từ việc nhỏ: hôm nay giơ tay phát biểu 1 lần.\n• Tham gia hoạt động CLB để có thêm bạn và tự tin hơn nhé!' },
  { keys: ['dinh huong', 'chon nganh', 'nghe nghiep', 'thi dai hoc', 'chon khoi', 'lam gi sau nay', 'tuong lai'],
    reply: 'Băn khoăn về tương lai là dấu hiệu bạn đang trưởng thành đó! 🎯\n\n• Viết ra: mình thích gì, giỏi gì, điều gì làm mình thấy ý nghĩa.\n• Hỏi người đang làm nghề đó: một ngày làm việc của họ ra sao.\n• Nói chuyện với thầy cô, bố mẹ để có thêm góc nhìn.\n• Bạn có thể nhờ AI gợi ý nghề hợp sở thích, nhưng quyết định cuối cùng là của bạn.' },
  { keys: ['cam on', 'thank', 'hay qua', 'tuyet voi', 'yeu mam', 'mam de thuong'],
    reply: 'Mầm cảm ơn bạn nhiều! 🥰 Chúc bạn học vui, học giỏi. Cần gì cứ hỏi Mầm nhé!' },
  { keys: ['xin chao', 'chao mam', 'hello', 'hi mam', 'alo'],
    reply: 'Chào bạn! 🌱 Mầm có thể giúp bạn: cách ôn bài, câu lệnh hỏi AI theo môn, kiểm chứng thông tin, an toàn mạng, hoặc… nghe bạn tâm sự. Bạn cần gì nè?' },
  { keys: ['mam la ai', 'ban la ai', 'ban la gi'],
    reply: 'Mình là **Mầm** 🌱, trợ lý của CLB AI Thăng Long. Mầm giúp bạn học cùng AI đúng cách: gợi ý để bạn tự làm, không làm hộ. Mầm cũng sẵn sàng nghe bạn tâm sự nữa!' },
  // ---- Học tập ----
  { keys: ['on bai', 'on tap', 'on thi', 'hoc thuoc', 'cach hoc', 'hoc nhanh nho', 'mau quen', 'hay quen', 'ghi nho'],
    reply: 'Cách ôn bài nhớ lâu nè 📚:\n1. **Tự nhớ lại:** gấp sách, viết ra những gì nhớ được trong 5 phút.\n2. **Mở sách đối chiếu**, đánh dấu chỗ quên.\n3. **Vẽ sơ đồ tư duy** cho cả bài.\n4. **Tự hỏi – tự đáp:** đặt 5 câu hỏi và trả lời.\n5. **Ôn lại** sau 1 ngày, 3 ngày, 1 tuần.\n\nBạn đang ôn môn gì? Mầm gợi ý câu lệnh cho môn đó nhé!' },
  { keys: ['ke hoach', 'lich hoc', 'thoi gian bieu', 'quan ly thoi gian', 'lap lich'],
    reply: 'Lập lịch học đơn giản 🗓️:\n• Ghi ra các môn và ngày kiểm tra sắp tới.\n• Mỗi tối chọn 2 môn, mỗi môn 30–45 phút.\n• Môn khó học lúc tỉnh táo nhất.\n• Chừa 1 buổi/tuần để ôn lại.\n\nCâu lệnh mẫu:', copy: 'Bạn là người hướng dẫn học tập. Mình lớp ..., mỗi tối rảnh ... tiếng, sắp kiểm tra môn ... Gợi ý lịch ôn trong tuần, để mình tự chọn.' },
  { keys: ['tap trung', 'xao nhang', 'luoi hoc', 'khong muon hoc', 'chan hoc', 'dong luc'],
    reply: 'Mất động lực là chuyện thường gặp, mình cùng “khởi động nhỏ” nhé! ⚡\n• Bắt đầu chỉ **5 phút** thôi: thường bắt đầu rồi sẽ học tiếp được.\n• Cất điện thoại ra xa.\n• Đặt phần thưởng nhỏ sau mỗi buổi học.\n• Học cùng bạn hoặc tham gia thử thách cây Mầm 🌱 để có thêm động lực!' },
  { keys: ['cau lenh', 'prompt', 'hoi ai the nao', 'cach hoi ai', 'hoi ai sao cho'],
    reply: 'Công thức hỏi AI: **Vai + Đã làm + Cần gì + Đừng** 🧭\nVí dụ dưới đây. Bạn xem thêm 20 câu lệnh mẫu ở mục **Câu lệnh** trên trang nhé!', copy: 'Bạn là gia sư Hóa. Mình làm đến bước 2 thì sai. Giải thích vì sao sai, đừng cho đáp án.' },
  { keys: ['kiem chung', 'tin gia', 'nguon', 'ai noi sai', 'ai bia', 'co dung khong', 'that hay gia'],
    reply: '3 câu kiểm chứng 🔍:\n1. Thông tin này **lấy từ đâu**?\n2. Có **khác SGK** hoặc nguồn chính thống không?\n3. Mình có **tự giải thích lại** được không?\n\nNhớ: AI có thể nói sai rất tự tin. Thử trò chơi **Thợ săn lỗi AI** trên trang nhé!' },
  { keys: ['anh gia', 'video gia', 'deepfake', 'gia giong', 'ai tao anh', 'ghep mat'],
    reply: 'Nhận biết ảnh, video do AI tạo 🕵️:\n• Nhìn kỹ tay, ngón tay, chữ viết, tai, nền ảnh: hay bị méo.\n• Tin quá giật gân? Tìm xem báo chính thống có đưa tin không.\n• Video giả giọng người quen xin tiền: **gọi lại trực tiếp** để kiểm tra.\n• Không chắc thì **không chia sẻ**.' },
  { keys: ['lua dao', 'otp', 'mat khau', 'trung thuong', 'hack', 'bi lua', 'link la', 'tai khoan bi'],
    reply: 'An toàn mạng 🛡️:\n• **Không bao giờ** gửi OTP, mật khẩu, ảnh CCCD cho ai.\n• Không bấm link lạ “trúng thưởng”, “nhận quà”.\n• Bật xác thực 2 bước cho tài khoản.\n• Lỡ bị lừa: báo ngay bố mẹ, thầy cô và đổi mật khẩu.' },
  { keys: ['thong tin ca nhan', 'cccd', 'dia chi nha', 'so dien thoai', 'quyen rieng tu', 'lo thong tin'],
    reply: 'Thông tin **không bao giờ** đưa vào AI hay gửi người lạ 🔒: mật khẩu, OTP, số CCCD, địa chỉ nhà, số điện thoại, ảnh riêng tư. Khi nhờ AI giúp, hãy che hoặc bỏ các thông tin đó đi nhé.' },
  { keys: ['gian lan', 'lam ho', 'viet ho', 'nop bai ai', 'dung ai lam bai', 'chep ai', 'dao van'],
    reply: 'Nhờ AI làm hộ rồi nộp là không trung thực, và bạn sẽ không học được gì 😟. Nghiên cứu cho thấy học sinh để AI làm hộ thì **lúc thi điểm thấp hơn**.\n\nThay vào đó: tự làm trước, nhờ AI **gợi ý** chỗ bí, rồi **khai báo** phần AI giúp khi nộp. Mẫu khai báo:', copy: 'Dùng AI: ... | AI giúp: ... | Tự làm: ...' },
  { keys: ['khai bao', 'ghi nguon ai', 'trung thuc'],
    reply: 'Khi dùng AI hỗ trợ bài làm, hãy ghi rõ ✍️:', copy: 'Dùng AI: Gemini | AI giúp: gợi ý dàn ý | Tự làm: viết cả bài' },
  { keys: ['ai la gi', 'tri tue nhan tao', 'chatgpt la gi', 'gemini la gi', 'ai hoat dong'],
    reply: 'AI (trí tuệ nhân tạo) là chương trình máy tính học từ rất nhiều dữ liệu để trả lời, viết, vẽ… 🤖 AI rất giỏi gợi ý và giải thích, nhưng **có thể sai** và không thật sự “hiểu” như con người. Vì vậy: **Bạn cầm lái – AI chỉ đường!**' },
  // ---- CLB ----
  { keys: ['tai lieu', 'cam nang', 'tai ve', 'file'], reply: 'Bạn xem mục **Kho tài liệu** để mở **Cẩm nang Tự học thông minh cùng AI** (22 trang) nhé! 📖' },
  { keys: ['dang ky', 'tham gia', 'vao clb', 'gia nhap'], reply: 'Bạn kéo xuống mục **Tham gia CLB** để xem cách đăng ký, vào nhóm Zalo và Fanpage của CLB nhé! 🎉' },
  { keys: ['lich sinh hoat', 'khi nao hop', 'sinh hoat luc nao', 'o dau'], reply: () => { const g = DATA.general || {}; return g.schedule ? '🗓️ Lịch sinh hoạt: ' + g.schedule : 'Lịch sinh hoạt sẽ được cập nhật ở mục **Bảng tin** và nhóm Zalo CLB nhé!'; } },
  { keys: ['loi nhan', 'gop y', 'gui thu', 'hop thu', 'padlet'], reply: 'Bạn bấm nút **💌 Gửi lời nhắn cho CLB** ở mục Tham gia CLB nhé. Lời nhắn hiện sau khi thầy cô duyệt. Nhớ không ghi số điện thoại hay địa chỉ nha!' },
  { keys: ['cay mam', 'tuoi cay', 'thu thach', 'nhan qua', 'phan qua', 'giay chung nhan', 'huy hieu'], reply: 'Ở mục **Thử thách**, mỗi nhiệm vụ hoàn thành = tưới cây Mầm 1 lần 💧. Tưới đủ lần sẽ nhận huy hiệu và **Giấy chứng nhận Người cầm lái AI** 🏆 để đưa cô phụ trách nhận quà!' },
  { keys: ['tro choi', 'tho san', 'quiz'], reply: 'Thử trò chơi **Thợ săn lỗi AI** nhé! Mỗi lượt 8 câu bốc ngẫu nhiên, xem bạn phát hiện được bao nhiêu lỗi của AI 🔍' },
  { keys: ['luat 15 phut', '15 phut'], reply: '**Luật 15 phút** ⏱️: gặp bài khó, tự nghĩ 15 phút rồi mới hỏi AI, và chỉ xin **gợi ý**. Nhờ người khác tập gym hộ thì cơ của ai to lên? 😉' }
];
const SUBJECTS = [['toan', 'Toán'], ['van', 'Ngữ văn'], ['tieng anh', 'Tiếng Anh'], ['anh van', 'Tiếng Anh'], ['vat li', 'Vật lí'], ['vat ly', 'Vật lí'], ['hoa', 'Hóa học'], ['sinh', 'Sinh học'], ['lich su', 'Lịch sử'], ['su ', 'Lịch sử'], ['dia', 'Địa lí'], ['gdcd', 'GDCD'], ['tin hoc', 'Tin học'], ['code', 'Tin học'], ['lap trinh', 'Tin học']];
function subjectPrompts(t) {
  const hit = SUBJECTS.find(([k]) => t.includes(' ' + k.trim() + ' ')); if (!hit) return null;
  const card = (DATA.prompts || []).find((p) => norm(p.subject).includes(norm(hit[1]).split(' ')[0]));
  return card ? { name: hit[1], items: card.items || [] } : null;
}
/* ===== Mầm "gia sư có sẵn": trả lời khi học sinh dán câu lệnh mẫu ===== */
const TUTOR = [
  { k: ['code', 'loi o dau'], t: '**Tự tìm lỗi code:**\n1. Đọc thông báo lỗi – nó chỉ **dòng số mấy**?\n2. Soát thiếu dấu : ( ) " hoặc thụt lề sai.\n3. Tên biến gõ có khớp nhau không?\n4. In giá trị biến ra để xem chạy tới đâu.\n5. Thử với dữ liệu nhỏ, dễ tính tay.' },
  { k: ['goi y buoc tiep', 'nua bai'], t: '**Bí giữa bài Toán? Thử 5 bước tự gỡ:**\n1. Viết lại: đề **cho gì**, đề **hỏi gì**.\n2. Bước cuối bạn làm ra kết quả gì? Nó đã gần với điều đề hỏi chưa?\n3. Tìm công thức/định lí nối “cái đã có” với “cái cần tìm”.\n4. Vẫn bí: thử với số nhỏ, hoặc vẽ hình/sơ đồ.\n5. Khoanh chỗ bí, mang hỏi thầy cô hoặc hỏi AI **kèm phần đã làm**.' },
  { k: ['kiem tra minh sai', 'giai xong'], t: '**Tự soát lỗi bài Toán:**\n1. Chép đề đúng số, đúng dấu chưa?\n2. Chuyển vế có đổi dấu chưa?\n3. Điều kiện: mẫu khác 0, biểu thức trong căn ≥ 0…\n4. Đơn vị và làm tròn đúng yêu cầu chưa?\n5. **Thay ngược đáp số vào đề** – đúng thì yên tâm!' },
  { k: ['lap dan y', 'dan y'], t: '**Tự nhận xét dàn ý Văn:**\n1. Mở bài đã giới thiệu đủ tác giả – tác phẩm – vấn đề chưa?\n2. Mỗi luận điểm có câu chủ đề + dẫn chứng + phân tích chưa?\n3. Các luận điểm có trùng ý nhau không?\n4. Có phần mở rộng, liên hệ bản thân chưa?\n5. Kết bài có khẳng định lại vấn đề và nêu cảm nghĩ chưa?' },
  { k: ['y tac gia', 'chua hieu y'], t: '**Mầm hỏi bạn 5 câu để tự hiểu tác phẩm:**\n1. Nhan đề gợi cho bạn điều gì?\n2. Hình ảnh hay từ ngữ nào được lặp lại nhiều lần?\n3. Cảm xúc nhân vật (hoặc nhà thơ) thay đổi thế nào từ đầu đến cuối?\n4. Tác phẩm ra đời trong hoàn cảnh nào?\n5. Nếu là tác giả, bạn muốn người đọc nhớ điều gì nhất?\nTrả lời vào vở – ý tác giả sẽ dần hiện ra đó!' },
  { k: ['doan van', 'chi ra loi'], t: '**Tự soát lỗi đoạn văn tiếng Anh:**\n1. Thì của động từ có đúng và thống nhất không?\n2. Chủ ngữ số ít → động từ thêm -s/-es chưa?\n3. a / an / the dùng đúng chưa?\n4. Giới từ (in, on, at…) và chính tả, dấu câu.\n5. **Đọc to từng câu** – câu nào vấp thường là câu có lỗi.' },
  { k: ['luyen noi', 'giao tiep'], t: '**Let\'s practice! 🎤** Trả lời từng câu bằng 1–2 câu tiếng Anh, **nói to trước rồi mới gõ**:\n1. What is your name and which class are you in?\n2. What do you usually do after school?\n3. What is your favourite subject? Why?\n4. Describe your hometown in two sentences.\n5. What are you going to do this weekend?\nMẹo: trả lời đủ câu, có thêm 1 lí do “because…”.' },
  { k: ['thay so', 'cong thuc'], t: '**Thay số bài Vật lí đúng cách:**\n1. Đổi tất cả về đơn vị chuẩn (m, kg, s…).\n2. Viết công thức gốc ra giấy.\n3. **Biến đổi công thức** để tìm đại lượng chưa biết, rồi mới thay số.\n4. Thay số kèm đơn vị.\n5. Kết quả có hợp lí không? (VD: vận tốc xe đạp không thể 300 m/s 😄)' },
  { k: ['hien tuong'], t: '**Hiểu một hiện tượng Vật lí:**\n1. Chuyện gì xảy ra? Tả bằng lời của bạn.\n2. Đại lượng nào thay đổi (nhiệt độ, lực, vận tốc, ánh sáng…)?\n3. Vì sao nó thay đổi?\n4. Tìm 1 ví dụ quen thuộc ở nhà giống vậy.\n5. Đối chiếu với phần kết luận trong SGK.' },
  { k: ['buoc 2', 'vi sao sai'], t: '**Soát lỗi bài Hóa:**\n1. Công thức hóa học viết đúng hóa trị chưa?\n2. Phương trình đã cân bằng chưa?\n3. Đổi ra số mol đúng chưa? (n = m : M)\n4. Tỉ lệ mol lấy theo **hệ số** phương trình chưa?\n5. Có chất dư, chất hết không?' },
  { k: ['can bang'], t: '**Cân bằng phương trình Hóa:**\n1. Đếm số nguyên tử từng nguyên tố ở hai vế.\n2. Cân bằng nguyên tố xuất hiện **ít lần** trước, O và H để sau.\n3. Nhóm nguyên tử (SO₄, NO₃…) coi như 1 khối.\n4. Ra hệ số phân số thì nhân cả phương trình lên.\n5. Đếm lại lần cuối cho chắc!' },
  { k: ['hay nham', 'so sanh'], t: '**Lập bảng so sánh 2 khái niệm:**\n| Tiêu chí | Khái niệm A | Khái niệm B |\n– Định nghĩa\n– Xảy ra ở đâu\n– Cần gì / tạo ra gì\n– Ví dụ\n– Điểm giống\n**Tự kiểm tra:** ① Điểm khác lớn nhất là gì? ② Cho 1 ví dụ của mỗi cái. ③ Gấp vở lại, nói lại bảng trong 1 phút.' },
  { k: ['trac nghiem'], t: '**Tự ra đề trắc nghiệm:**\n1. Chọn 5 ý quan trọng nhất trong bài.\n2. Mỗi ý viết 1 câu hỏi có 4 phương án, độ dài **ngang nhau**.\n3. Đổi đề với bạn cùng lớp, làm rồi chấm cho nhau.\nMuốn luyện ngay? Chơi **🔍 Thợ săn lỗi AI** trên web – kho hơn 200 câu nhiều môn!' },
  { k: ['hoi minh 5 cau', 'tu de den kho'], t: '**Mầm hỏi bạn 5 câu, từ dễ đến khó** (trả lời vào vở, rồi đối chiếu SGK):\n1. Sự kiện chính diễn ra **khi nào, ở đâu**?\n2. Những ai, lực lượng nào tham gia?\n3. Vì sao sự kiện xảy ra?\n4. Diễn biến chính gồm mấy giai đoạn?\n5. Kết quả, ý nghĩa – và bài học cho hôm nay là gì?' },
  { k: ['so do tu duy'], t: '**Soát sơ đồ tư duy môn Sử:**\n1. Ở giữa là tên bài/sự kiện chưa?\n2. Đủ 4 nhánh chính: **bối cảnh – diễn biến – kết quả – ý nghĩa**?\n3. Mỗi nhánh có mốc thời gian chưa?\n4. Dùng từ khóa ngắn, không chép cả câu.\n5. So với mục lục bài trong SGK xem sót ý nào.' },
  { k: ['bieu do'], t: '**4 bước nhận xét biểu đồ Địa lí:**\n1. **Tổng quát:** xu hướng chung tăng hay giảm?\n2. **Chi tiết:** số liệu đầu – cuối, tăng/giảm bao nhiêu (lần hoặc %).\n3. **So sánh:** đối tượng nào cao nhất, thấp nhất?\n4. **Điểm đặc biệt:** giai đoạn nào khác thường?\nCâu mẫu: “Từ năm … đến năm …, … tăng từ … lên …, gấp … lần.”' },
  { k: ['meo ghi nho', 'kho nho'], t: '**Mẹo nhớ bài:**\n1. Lấy chữ cái đầu ghép thành từ dễ nhớ.\n2. Gắn kiến thức với bản đồ, hình ảnh, nơi quen thuộc.\n3. Vẽ sơ đồ thay vì chép chữ.\n4. Tự kiểm tra lại sau **1 – 3 – 7 ngày**.\n5. Giảng lại cho bạn hoặc người nhà nghe.\n**Mầm hỏi lại bạn:** ① Bài có mấy ý chính? ② Ý nào khó nhớ nhất? ③ Bạn dùng mẹo nào cho ý đó?' },
  { k: ['tinh huong'], t: '**5 câu hỏi để tự xử lí tình huống:**\n1. Ai đã làm gì?\n2. Việc đó đúng hay sai? Theo quy định, chuẩn mực nào?\n3. Hậu quả cho bản thân và người khác?\n4. Nếu là bạn, bạn sẽ nói gì, làm gì?\n5. Cần nhờ ai giúp đỡ?' },
  { k: ['lich on', 'sap thi'], t: '**Gợi ý 1 tiếng ôn mỗi tối:**\n• 10 phút: xem lại lỗi sai hôm trước\n• 35 phút: ôn **1 chủ đề** (đọc – tự tóm tắt – làm bài)\n• 10 phút: gấp sách, tự kiểm tra\n• 5 phút: ghi việc cho tối mai\nLuân phiên môn mỗi tối, Chủ nhật làm 1 đề. **Bạn tự chọn môn cho từng tối nhé!**' },
  { k: ['phan bien', 'diem tot'], t: '**Tự phản biện bài của mình:**\n1. Đánh dấu 2 chỗ bạn thấy **ổn nhất** – vì sao?\n2. Đánh dấu 2 chỗ còn **chưa chắc**.\n3. Bài đã làm đủ yêu cầu của đề chưa?\n4. Đọc to một lượt để bắt lỗi diễn đạt.\n5. Nhờ một bạn đọc và góp ý thêm.' },
];
function tutorReply(raw) {
  const t = ' ' + norm(raw) + ' ';
  if (!/ ban la (gia su|giao vien|nguoi huong dan|nguoi phan bien|ban luyen)/.test(t)) return null;
  const hit = TUTOR.find((x) => x.k.some((k) => t.includes(k)));
  const body = hit ? hit.t : '**Cách dùng câu lệnh này:** chép câu lệnh, thêm **đề bài + phần bạn đã làm**, rồi dán vào công cụ AI được phép.';
  return { text: body + '\n\n🌱 Mầm có sẵn chưa đọc được bài riêng của bạn. Muốn AI xem trực tiếp: bấm **📋 Chép**, dán vào ChatGPT hoặc Gemini, **thêm đề bài và phần bạn đã làm** nhé!', copies: [String(raw).trim()], links: true };
}

function brain(txt) {
  const t = ' ' + norm(txt) + ' ';
  const has = (k) => k.length <= 4 ? t.includes(' ' + k + ' ') : t.includes(' ' + k);
  for (const c of CRISIS) if (c.keys.some(has)) return { text: c.reply, urgent: true };
  const tu = tutorReply(txt); if (tu) return tu;
  const sp = subjectPrompts(t);
  let best = null, bestScore = 0;
  for (const it of INTENTS) { const sc = it.keys.reduce((n, k) => n + (has(k) ? k.length : 0), 0); if (sc > bestScore) { bestScore = sc; best = it; } }
  const homework = ['giai', 'bai tap', 'lam giup', 'dap an', 'bai nay', 'cau nay', 'de bai', 'tinh toan', 'phan tich', 'viet doan', 'dich cau', 'dich doan'].some(has);
  const promptIntent = best && best.keys.includes('cau lenh');
  if (sp && (promptIntent || homework || !best)) {
    return { text: homework ? `Mầm không làm hộ bài đâu nha 😉, nhưng Mầm chỉ bạn cách hỏi AI để **tự hiểu bài** môn **${sp.name}**:\n1. Tự làm trước ít nhất 15 phút.\n2. Chép câu lệnh bên dưới, điền thêm chỗ bạn bí.\n3. Dán vào công cụ AI mà thầy cô, bố mẹ cho phép.` : `Câu lệnh mẫu môn **${sp.name}** để bạn hỏi AI đúng cách nè 👇`, copies: sp.items.slice(0, 2) };
  }
  if (best) { const text = typeof best.reply === 'function' ? best.reply() : best.reply; return { text, copies: best.copy ? [best.copy] : [] }; }
  if (homework) return { text: 'Mầm không làm hộ bài đâu nha 😉, nhưng đây là cách hỏi AI để **tự hiểu bài**:\n1. Tự làm trước ít nhất 15 phút.\n2. Chép câu lệnh bên dưới, điền chỗ bạn bí.\n3. Dán vào công cụ AI mà thầy cô, bố mẹ cho phép.\n\nCho Mầm biết môn gì để Mầm gợi ý câu lệnh đúng môn nhé!', copies: ['Bạn là gia sư. Mình làm được nửa bài thì bí. Gợi ý bước tiếp theo, đừng giải hết.'] };
  return { text: 'Mầm chưa hiểu ý bạn lắm 🌱. Bạn có thể hỏi Mầm về:\n• **Học tập:** cách ôn bài, lập lịch học, câu lệnh hỏi AI theo môn (VD: “câu lệnh môn Toán”)\n• **An toàn mạng:** lừa đảo, tin giả, ảnh giả AI\n• **Tâm sự:** áp lực học, buồn, bạn bè, gia đình…\n• **CLB:** tài liệu, cây Mầm, đăng ký, hộp thư' };
}

function offlineReply(txt) { return brain(txt).text; }
function botReply(r) {
  const line = appendChat('bot', r.text);
  if (r.links && (r.copies || [])[0]) {
    const q = r.copies[0]; const box = el('div', 'chat-ai-links');
    const g = el('a', 'mini', '✨ Mở ChatGPT ↗'); g.href = 'https://chatgpt.com/?q=' + encodeURIComponent(q); g.target = '_blank'; g.rel = 'noopener';
    const m = el('a', 'mini', '💎 Mở Gemini ↗'); m.href = 'https://gemini.google.com/app'; m.target = '_blank'; m.rel = 'noopener'; m.addEventListener('click', () => { copyText(q); toast('Đã chép câu lệnh – dán vào Gemini rồi thêm bài của bạn nhé!'); });
    box.append(g, m); setTimeout(() => line.appendChild(box), 0);
  }
  (r.copies || []).forEach((c) => { const box = el('div', 'chat-copy'); box.appendChild(el('span', '', c)); const b = el('button', 'mini', '📋 Chép'); b.type = 'button'; b.addEventListener('click', async () => { b.textContent = (await copyText(c)) ? '✓ Đã chép' : 'Chép thủ công'; }); box.appendChild(b); line.appendChild(box); });
  $('chatMessages').scrollTop = $('chatMessages').scrollHeight; return line;
}
function systemText() {
  const g = DATA.general || {}, P = DATA.profile || {};
  const news = (DATA.news || []).slice(0, 5).map((n) => `- ${n.date || ''} ${n.title || ''}: ${n.body || ''}`).join('\n');
  const docs = (DATA.docs || []).map((d) => `- [${d.category}] ${d.title}`).join('\n');
  return `Bạn là "Mầm" 🌱 – trợ lý học tập AI của ${P.club_name || 'CLB Tự học cùng AI'}, ${P.school || 'Trường THCS&THPT Thăng Long'} (${P.address || 'Nam Ban, Lâm Hà, Lâm Đồng'}). Người hỏi là học sinh THCS, THPT.
Phương châm: "Bạn cầm lái – AI chỉ đường", "Tự nghĩ trước – Hỏi AI sau".
Cách trả lời: tiếng Việt thân thiện, xưng "Mầm", gọi "bạn"; ngắn gọn (thường dưới 150 chữ). Với bài tập: KHÔNG giải hộ, không đưa đáp án cuối ngay; hỏi bạn đã làm đến đâu, gợi ý từng bước, đặt câu hỏi dẫn dắt. Với câu hỏi kiến thức: giải thích dễ hiểu, có ví dụ, rồi gợi 1 câu hỏi tự kiểm tra. Nhắc đối chiếu SGK khi nêu năm tháng, số liệu; không chắc thì nói không chắc. Không viết hộ cả bài để nộp. Nhắc không chia sẻ thông tin cá nhân. Nếu bạn buồn, bị bắt nạt hay gặp nguy hiểm: động viên và khuyên nói ngay với thầy cô, cha mẹ (tổng đài 111). Chỉ trả lời về CLB dựa trên thông tin dưới đây.
${g.schedule ? 'Lịch sinh hoạt: ' + g.schedule + '\n' : ''}${g.contact ? 'Liên hệ: ' + g.contact + '\n' : ''}${g.join_how ? 'Cách tham gia: ' + g.join_how + '\n' : ''}${news ? 'Bảng tin:\n' + news + '\n' : ''}${docs ? 'Tài liệu trong mục Kho tài liệu:\n' + docs + '\n' : ''}${(DATA.chat || {}).extra_instructions ? 'Lời dặn thêm của cô phụ trách (ưu tiên):\n' + DATA.chat.extra_instructions : ''}`;
}
async function sendChat(msg) {
  const m = String(msg || '').trim(); if (!m || chatBusy) return;
  appendChat('user', m); chatHistory.push({ role: 'user', content: m.slice(0, 1500) });
  const local = brain(m);
  if (!sample || local.urgent) { botReply(local); chatHistory.push({ role: 'assistant', content: local.text }); return; }
  chatBusy = true; const line = appendChat('bot typing', 'Mầm đang suy nghĩ…');
  const hist = chatHistory.slice(-12); while (hist.length && hist[0].role !== 'user') hist.shift();
  const msgs = hist.map((x, i) => i === 0 ? { role: 'user', content: systemText() + '\n\n--- Học sinh hỏi ---\n' + x.content } : x);
  try {
    const res = await sample(msgs, { cache: false, onText: ({ text }) => { line.classList.remove('typing'); line.innerHTML = rich(text); $('chatMessages').scrollTop = $('chatMessages').scrollHeight; } });
    const text = (res && res.text) || offlineReply(m); line.classList.remove('typing'); line.innerHTML = rich(text); chatHistory.push({ role: 'assistant', content: text.slice(0, 1500) });
  } catch (e) {
    const r = offlineReply(m); line.classList.remove('typing'); line.innerHTML = rich(r); chatHistory.push({ role: 'assistant', content: r });
    if (e && (e.code === 'not_granted' || e.code === 'capability_disabled')) { sample = null; setChatStatus(); }
  } finally { chatBusy = false; }
}
function setChatStatus() { $('chatStatus').textContent = sample ? 'Trợ lý AI · gợi ý để bạn tự làm' : 'Gợi ý có sẵn của CLB'; }
$('chatForm').addEventListener('submit', (e) => { e.preventDefault(); const i = $('chatInput'); sendChat(i.value); i.value = ''; i.focus(); });
document.querySelectorAll('[data-quick]').forEach((b) => b.addEventListener('click', () => sendChat(b.dataset.quick)));
function renderChatWelcome() { const first = $('chatMessages').firstElementChild; if (first && !chatHistory.length && DATA.chat && DATA.chat.welcome) first.textContent = DATA.chat.welcome; }


/* ===== 20 câu lệnh mẫu ===== */
function splitPrompt(t) {
  const sents = String(t).match(/[^.!?]+[.!?]?/g) || [t]; const role = (sents[0] || '').trim(); const ctx = (sents[1] || '').trim(); let rest = sents.slice(2).join(' ').trim();
  let lim = ''; const m = rest.match(/(,?\s*)((?:đừng|không|để mình|rồi hỏi)[^]*)$/i); if (m && m.index > 0) { lim = m[2].trim(); rest = rest.slice(0, m.index).trim(); }
  return [['VAI', role, '#5b3fb5'], ['ĐÃ LÀM', ctx, '#1f86d9'], ['CẦN GÌ', rest, '#e0a800'], ['ĐỪNG', lim, '#e03a3a']].filter((x) => x[1]);
}
let promptFilter = 'all';
function renderPrompts() {
  const grid = $('promptGrid'); if (!grid) return; grid.innerHTML = ''; grid.className = 'prompt-grid pv2';
  const bar = el('div', 'pf-bar'); const subs = (DATA.prompts || []);
  [['all', '✨ Tất cả', '#7b5cff'], ...subs.map((s, i) => [String(i), `${s.icon || '💬'} ${s.subject}`, s.color])].forEach(([k, t, c]) => { const b = el('button', 'pf-chip' + (promptFilter === k ? ' on' : ''), t); b.type = 'button'; b.style.setProperty('--c', c || '#7b5cff'); b.addEventListener('click', () => { promptFilter = k; renderPrompts(); }); bar.appendChild(b); });
  grid.appendChild(bar);
  const wrap = el('div', 'pv2-grid'); let n = 0;
  subs.forEach((s, si) => (s.items || []).filter(Boolean).forEach((t) => {
    n++; if (promptFilter !== 'all' && promptFilter !== String(si)) return;
    const card = el('article', 'pv2-card'); card.style.setProperty('--c', s.color || '#5b3fb5');
    const hd = el('div', 'pv2-hd'); hd.append(el('span', 'pv2-no', String(n).padStart(2, '0')), el('span', 'pv2-ic', s.icon || '💬'), el('b', '', s.subject || '')); card.appendChild(hd);
    const body = el('div', 'pv2-body'); splitPrompt(t).forEach(([lab, txt, col]) => { const row = el('div', 'pv2-seg'); row.style.setProperty('--sc', col); row.append(el('small', '', lab), el('span', '', txt)); body.appendChild(row); }); card.appendChild(body);
    const act = el('div', 'pv2-act');
    const cp = el('button', 'pv2-btn', '📋 Chép'); cp.type = 'button'; cp.addEventListener('click', async () => { const ok = await copyText(t); cp.textContent = ok ? '✓ Đã chép' : 'Chép thủ công'; snd && snd('pick'); setTimeout(() => { cp.textContent = '📋 Chép'; }, 1600); });
    const ask = el('button', 'pv2-btn ok', '🌱 Hỏi Mầm'); ask.type = 'button'; ask.addEventListener('click', () => { toggleChat(true); $('chatInput').value = t + ' '; $('chatInput').focus(); });
    act.append(cp, ask); card.appendChild(act); wrap.appendChild(card);
  }));
  grid.appendChild(wrap);
}
function bindSaveCode() {
  $('copyCode').addEventListener('click', async () => { const ok = await copyText($('saveCode').textContent); $('copyCode').textContent = ok ? '✓ Đã chép' : 'Chép thủ công'; setTimeout(() => { $('copyCode').textContent = '📋 Chép'; }, 1800); });
  $('codeForm').addEventListener('submit', (e) => { e.preventDefault(); const res = loadCode($('codeInput').value); const n = res && res.n; if (!res) { toast('Mã chưa đúng rồi 🤔 Kiểm tra lại từng chữ nhé (VD: MAM-1ABC2D).'); return; } $('codeInput').value = ''; renderChallenge(); toast(`🌱 Đã mở lại: cây ${n} lần tưới${res.xp ? ` · ${res.xp} XP` : ''}! Chơi tiếp thôi!`); });
}
function renderAll() { renderProfile(); renderGeneral(); renderNews(); renderStages(); renderVote(); renderDocs(); renderHandbook(); renderPosters(); renderArticles(); renderPrompts(); resetQuiz(); renderChallenge(); renderChatWelcome(); document.title = 'CLB AI Thăng Long – Tự học cùng AI'; }
renderAll(); setChatStatus(); bindSaveCode();
function goHash() { const id = (location.hash || '').slice(1); const t = id && /^[a-z0-9-]+$/i.test(id) && document.getElementById(id); if (t) setTimeout(() => t.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300); }
goHash(); window.addEventListener('hashchange', goHash);

/* ===================================================================
   CHẾ ĐỘ SỬA TRANG (chỉ chủ trang / người có quyền sửa mới thấy)
   =================================================================== */
let ART = null, ASSETS = null, dirty = false;
function buildHtml() {
  const json = JSON.stringify(DATA).replace(/</g, '\\u003c');
  const S = '<' + 'script', E = '<' + '/script>';
  const title = 'CLB AI Thăng Long – Tự học cùng AI';
  return `<!DOCTYPE html>\n<html lang="vi">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>${title}</title>\n<style id="clb-style">${SRC.style}</style>\n</head>\n<body>\n<template id="clb-body">${SRC.body}</template>\n${S} type="application/json" id="clb-data">${json}${E}\n${S} id="clb-app">${SRC.app}${E}\n</body>\n</html>\n`;
}
function markDirty() { dirty = true; $('edSave').disabled = false; $('edState').textContent = '● Có thay đổi chưa lưu'; renderAll(); }
async function publishNow() {
  if (!ART) return; const btn = $('edSave'); btn.disabled = true; $('edState').textContent = 'Đang lưu…';
  try { sessionStorage.setItem('clb_open_editor', '1'); } catch (_) {}
  try { await ART.publish(buildHtml()); dirty = false; $('edState').textContent = '✓ Đã lưu – trang đang tải lại'; }
  catch (e) {
    btn.disabled = false;
    const msg = { conflict: 'Trang vừa được lưu ở nơi khác; trang sẽ tải lại, cô sửa lại giúp nhé.', not_writer: 'Tài khoản này không có quyền sửa trang.', not_granted: 'Tài khoản này không có quyền sửa trang.', too_large: 'Trang quá lớn. Hãy dùng ảnh nhỏ hơn.', rate_limited: 'Lưu nhanh quá, đợi vài giây rồi bấm lại.' }[e && e.code] || ('Chưa lưu được: ' + ((e && e.message) || e));
    $('edState').textContent = '⚠ ' + msg; toast('⚠ ' + msg);
  }
}
window.addEventListener('beforeunload', (e) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

async function shrink(file, maxSide) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 350 * 1024) return file;
  const bmp = await createImageBitmap(file).catch(() => null); if (!bmp) return file;
  const k = Math.min(1, maxSide / Math.max(bmp.width, bmp.height)); const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const png = file.type === 'image/png' && file.size < 1.5 * 1048576;
  const blob = await new Promise((r) => c.toBlob(r, png ? 'image/png' : 'image/jpeg', 0.84)); return blob || file;
}
async function uploadFile(file, maxSide = 1800) {
  if (!ASSETS) throw new Error('Không tải lên được ở chế độ xem này.');
  const isImage = file.type.startsWith('image/');
  const blob = isImage ? await shrink(file, maxSide) : file;
  const type = blob.type || (/\.pdf$/i.test(file.name) ? 'application/pdf' : '');
  if (!/^(image\/(png|jpeg|gif|webp|svg\+xml)|application\/pdf|video\/(mp4|webm))$/.test(type)) throw new Error('Chỉ tải lên được ảnh, PDF hoặc video MP4. File Word/PowerPoint: cô lưu thành PDF hoặc dán link Google Drive.');
  try { const r = await ASSETS.upload(blob, { type }); return r.url; }
  catch (e) { throw new Error({ too_large: 'File quá lớn (tối đa 20 MB).', quota_or_state: 'Hết dung lượng lưu trữ.', unsupported_type: 'Loại file không hỗ trợ.' }[e && e.code] || ((e && e.message) || 'Tải lên lỗi')); }
}

/* --- khung giao diện sửa --- */
const ED_TABS = [['profile', '🖼️ Ảnh & thông tin'], ['articles', '📰 Bài viết'], ['news', '📢 Bảng tin'], ['vote', '🗳️ Bình chọn'], ['docs', '📁 Tài liệu'], ['general', '🏠 Nội dung & liên hệ'], ['stages', '🧭 Cẩm nang'], ['quiz', '🔍 Trò chơi'], ['prompts', '💬 Câu lệnh'], ['days', '✅ Thử thách'], ['chat', '🌱 Mầm AI']];
let edTab = 'profile';
function openEditor() { $('editor').hidden = false; document.body.classList.add('editing'); drawTab(); }
function closeEditor() { $('editor').hidden = true; document.body.classList.remove('editing'); }
function buildEditorShell() {
  const fab = el('button', 'edit-fab', '✏️ Sửa trang'); fab.type = 'button'; fab.id = 'editFab'; fab.addEventListener('click', openEditor); document.body.appendChild(fab);
  const ed = el('aside', 'editor'); ed.id = 'editor'; ed.hidden = true;
  ed.innerHTML = `<div class="ed-head"><b>✏️ Sửa trang</b><span id="edState" class="ed-state">Sửa xong bấm Lưu để mọi người thấy</span><button class="ed-x" id="edClose" type="button" aria-label="Đóng">×</button></div>
    <div class="ed-tabs" id="edTabs"></div><div class="ed-body" id="edBody"></div>
    <div class="ed-foot"><button class="btn btn-primary full" id="edSave" type="button" disabled>💾 Lưu & đăng lên web</button></div>`;
  document.body.appendChild(ed);
  ED_TABS.forEach(([k, l]) => { const b = el('button', 'ed-tab', l); b.type = 'button'; b.dataset.k = k; b.addEventListener('click', () => { edTab = k; drawTab(); }); $('edTabs').appendChild(b); });
  $('edClose').addEventListener('click', closeEditor); $('edSave').addEventListener('click', publishNow);
  try { if (sessionStorage.getItem('clb_open_editor')) { sessionStorage.removeItem('clb_open_editor'); openEditor(); toast('✅ Đã lưu! Mọi người đã thấy nội dung mới.'); } } catch (_) {}
}
/* --- ô nhập --- */
function inp(label, value, onChange, opts = {}) {
  const w = el('div', 'fld'); const lb = el('label', '', label); w.appendChild(lb);
  const i = opts.area ? el('textarea') : el('input'); if (opts.area) i.rows = opts.rows || 3; else i.type = opts.type || 'text';
  i.value = value ?? ''; if (opts.ph) i.placeholder = opts.ph;
  i.addEventListener(opts.area || i.type === 'text' || i.type === 'url' ? 'input' : 'change', () => onChange(i.value));
  w.appendChild(i); if (opts.hint) w.appendChild(el('small', '', opts.hint)); return w;
}
function imgField(label, value, onChange, opts = {}) {
  const w = el('div', 'fld'); w.appendChild(el('label', '', label));
  const row = el('div', 'pick'); const prev = el('div', 'pick-prev' + (opts.round ? ' round' : '')); const btns = el('div', 'pick-btns');
  const up = el('label', 'mini pick-up', '📷 Chọn ảnh'); const f = el('input'); f.type = 'file'; f.accept = 'image/*'; f.hidden = true; up.appendChild(f);
  const del = el('button', 'mini danger', 'Bỏ ảnh'); del.type = 'button'; const msg = el('small', 'pick-msg');
  let v = value || '';
  const draw = () => { prev.innerHTML = v ? `<img src="${esc(v)}" alt="">` : `<span>${esc(opts.empty || 'Chưa có ảnh')}</span>`; del.hidden = !v; };
  f.addEventListener('change', async () => { const file = f.files[0]; if (!file) return; msg.textContent = 'Đang tải ảnh lên…'; try { v = await uploadFile(file, opts.maxSide || 1800); onChange(v); draw(); msg.textContent = '✓ Xong'; } catch (e) { msg.textContent = '⚠ ' + e.message; } f.value = ''; });
  del.addEventListener('click', () => { v = ''; onChange(''); draw(); });
  btns.append(up, del); if (opts.hint) btns.appendChild(el('small', '', opts.hint)); btns.appendChild(msg); row.append(prev, btns); w.appendChild(row); draw(); return w;
}
function listEditor(box, arr, title, blank, drawItem, opts = {}) {
  const head = el('div', 'ed-listhead'); head.appendChild(el('b', '', title));
  const add = el('button', 'mini ok', '＋ Thêm'); add.type = 'button'; head.appendChild(add); box.appendChild(head);
  const wrap = el('div'); box.appendChild(wrap);
  const draw = () => {
    wrap.innerHTML = ''; if (!arr.length) wrap.appendChild(el('p', 'hint', opts.empty || 'Chưa có mục nào.'));
    arr.forEach((it, i) => {
      const card = el('div', 'item'); const h = el('div', 'item-head'); h.appendChild(el('b', '', (opts.label || 'MỤC') + ' ' + (i + 1)));
      const ctr = el('span'); [['↑', -1], ['↓', 1]].forEach(([t, d]) => { const b = el('button', 'mini', t); b.type = 'button'; b.addEventListener('click', () => { const j = i + d; if (j < 0 || j >= arr.length) return; [arr[i], arr[j]] = [arr[j], arr[i]]; markDirty(); draw(); }); ctr.appendChild(b); });
      const x = el('button', 'mini danger', 'Xóa'); x.type = 'button'; x.addEventListener('click', () => { if (x.dataset.arm) { arr.splice(i, 1); markDirty(); draw(); } else { x.dataset.arm = '1'; x.textContent = 'Chắc chưa?'; setTimeout(() => { delete x.dataset.arm; x.textContent = 'Xóa'; }, 2500); } }); ctr.appendChild(x);
      h.appendChild(ctr); card.appendChild(h); drawItem(card, it, i); wrap.appendChild(card);
    });
  };
  add.addEventListener('click', () => { opts.top ? arr.unshift(blank()) : arr.push(blank()); markDirty(); draw(); });
  draw();
}
function drawTab() {
  document.querySelectorAll('.ed-tab').forEach((b) => b.classList.toggle('active', b.dataset.k === edTab));
  const box = $('edBody'); box.innerHTML = ''; box.scrollTop = 0;
  const P = DATA.profile, G = DATA.general;
  const set = (o, k) => (v) => { o[k] = v; markDirty(); };
  if (edTab === 'profile') {
    box.appendChild(imgField('Ảnh đại diện / logo CLB', P.logo, set(P, 'logo'), { round: true, maxSide: 600, empty: 'Logo mặc định', hint: 'Ảnh vuông, nền trong càng đẹp.' }));
    [['club_name', 'Tên CLB'], ['club_sub', 'Dòng nhỏ dưới tên'], ['school', 'Trường'], ['address', 'Địa chỉ']].forEach(([k, l]) => box.appendChild(inp(l, P[k], set(P, k))));
    box.appendChild(inp('Khẩu hiệu chân trang', P.footer_slogan, set(P, 'footer_slogan'), { area: true, rows: 2 }));
    box.appendChild(el('h4', 'ed-sub', 'Phần đầu trang'));
    [['hero_kicker', 'Dòng nhỏ trên tiêu đề'], ['hero_line1', 'Tiêu đề – chữ xanh'], ['hero_pink', 'Tiêu đề – chữ hồng'], ['hero_line2', 'Tiêu đề dòng 2 – chữ xanh'], ['hero_purple', 'Tiêu đề dòng 2 – chữ tím']].forEach(([k, l]) => box.appendChild(inp(l, P[k], set(P, k))));
    box.appendChild(imgField('Ảnh lớn đầu trang (không bắt buộc)', P.hero_image, set(P, 'hero_image'), { empty: 'Đang dùng hình robot Mầm', hint: 'VD: ảnh tập thể CLB. Bỏ ảnh = dùng lại robot.' }));
    box.appendChild(el('h4', 'ed-sub', 'Ban chủ nhiệm / thành viên'));
    box.appendChild(inp('Tiêu đề mục', P.members_title, set(P, 'members_title')));
    P.members = P.members || [];
    listEditor(box, P.members, 'Danh sách', () => ({ name: '', role: '', note: '', photo: '' }), (c, m) => {
      c.append(inp('Họ tên', m.name, set(m, 'name')), inp('Vai trò', m.role, set(m, 'role'), { ph: 'Chủ nhiệm, Phó chủ nhiệm…' }), inp('Ghi chú', m.note, set(m, 'note'), { ph: 'Lớp 11A1' }), imgField('Ảnh chân dung', m.photo, set(m, 'photo'), { round: true, maxSide: 500, empty: 'Chữ cái đầu' }));
    }, { label: 'NGƯỜI', empty: 'Chưa có ai – mục này đang ẩn.' });
  }
  if (edTab === 'articles') {
    DATA.articles = DATA.articles || [];
    box.appendChild(el('p', 'hint', 'Bài mới thêm ở trên cùng. Bỏ tích “Hiện” để lưu nháp.'));
    listEditor(box, DATA.articles, 'Bài viết', () => ({ title: '', summary: '', body: '', category: 'Hoạt động', author: '', date: new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' }), cover: '', images: [], published: true, pinned: false }), (c, a) => {
      c.append(inp('Tiêu đề', a.title, set(a, 'title')), inp('Chuyên mục', a.category, set(a, 'category'), { ph: 'Hoạt động, Kinh nghiệm học tập…' }), inp('Ngày đăng', a.date, set(a, 'date'), { type: 'date' }), inp('Người viết', a.author, set(a, 'author')), inp('Link video YouTube (không bắt buộc)', a.video, set(a, 'video'), { type: 'url', ph: 'https://www.youtube.com/watch?v=…' }),
        inp('Tóm tắt', a.summary, set(a, 'summary'), { area: true, rows: 2 }), inp('Nội dung', a.body, set(a, 'body'), { area: true, rows: 8, hint: 'Để 1 dòng trống giữa các đoạn. **chữ đậm**' }),
        imgField('Ảnh bìa', a.cover, set(a, 'cover')));
      const g = el('div', 'fld'); g.appendChild(el('label', '', 'Album ảnh trong bài')); const gal = el('div', 'gal'); g.appendChild(gal);
      const up = el('label', 'mini pick-up', '📷 Thêm ảnh (chọn nhiều)'); const fi = el('input'); fi.type = 'file'; fi.accept = 'image/*'; fi.multiple = true; fi.hidden = true; up.appendChild(fi); const gm = el('small'); g.append(up, gm);
      a.images = a.images || [];
      const dg = () => { gal.innerHTML = ''; a.images.forEach((src, i) => { const d = el('div'); d.innerHTML = `<img src="${esc(src)}" alt="">`; const x = el('button', 'mini danger', '×'); x.type = 'button'; x.addEventListener('click', () => { a.images.splice(i, 1); markDirty(); dg(); }); d.appendChild(x); gal.appendChild(d); }); };
      fi.addEventListener('change', async () => { const fs = [...fi.files]; let n = 0; for (const f of fs) { gm.textContent = `Đang tải ${++n}/${fs.length}…`; try { a.images.push(await uploadFile(f)); markDirty(); dg(); } catch (e) { toast('⚠ ' + e.message); } } gm.textContent = ''; fi.value = ''; });
      dg(); c.appendChild(g);
      const ck = (lbl, k) => { const l = el('label', 'check-line'); const i = el('input'); i.type = 'checkbox'; i.checked = a[k] !== false && (k !== 'pinned' || a.pinned); i.addEventListener('change', () => { a[k] = i.checked; markDirty(); }); l.append(i, el('span', '', lbl)); return l; };
      c.append(ck('Hiện bài trên trang', 'published'), ck('📌 Ghim lên đầu', 'pinned'));
      const v = el('button', 'mini', '👀 Xem thử bài'); v.type = 'button'; v.addEventListener('click', () => openReader(a)); c.appendChild(v);
    }, { label: 'BÀI', top: true, empty: 'Chưa có bài viết – bấm ＋ Thêm.' });
  }
  if (edTab === 'news') {
    DATA.news = DATA.news || [];
    listEditor(box, DATA.news, 'Thông báo (tin đầu có nhãn MỚI)', () => ({ date: new Date().toLocaleDateString('vi-VN'), title: '', body: '', link: '' }), (c, n) => {
      c.append(inp('Ngày', n.date, set(n, 'date')), inp('Tiêu đề', n.title, set(n, 'title')), inp('Nội dung', n.body, set(n, 'body'), { area: true }), inp('Liên kết (không bắt buộc)', n.link, set(n, 'link'), { type: 'url' }));
    }, { label: 'TIN', top: true, empty: 'Chưa có thông báo – bảng tin đang ẩn.' });
  }
  if (edTab === 'vote') {
    const V = DATA.vote = DATA.vote || { enabled: true, options: [] }; V.options = V.options || [];
    const l = el('label', 'check-line'); const ck = el('input'); ck.type = 'checkbox'; ck.checked = V.enabled !== false; ck.addEventListener('change', () => { V.enabled = ck.checked; markDirty(); }); l.append(ck, document.createTextNode(' Hiện mục bình chọn trên trang')); box.appendChild(l);
    box.append(inp('Tiêu đề', V.title, set(V, 'title')), inp('Lời giới thiệu', V.intro, set(V, 'intro'), { area: true }), inp('Hạn bình chọn (năm-tháng-ngày, VD 2026-11-21)', V.deadline, set(V, 'deadline'), { ph: '2026-11-21' }), inp('Link phiếu đếm phiếu (Padlet / Google Form)', V.url, set(V, 'url'), { type: 'url' }));
    box.appendChild(el('p', 'hint', 'Xem kết quả: mở link phiếu ở trên (đăng nhập Padlet của cô) – số phiếu từng logo hiện ngay trên ô bình chọn.'));
    listEditor(box, V.options, 'Các mẫu để chọn', () => ({ label: '', desc: '', img: '' }), (c, o) => { c.append(inp('Tên', o.label, set(o, 'label'), { ph: 'Logo 1' }), inp('Mô tả ngắn', o.desc, set(o, 'desc')), imgField('Ảnh', o.img, set(o, 'img'), { maxSide: 1000 })); }, { label: 'MẪU', empty: 'Chưa có mẫu nào.' });
  }
  if (edTab === 'docs') {
    DATA.docs = DATA.docs || [];
    box.appendChild(el('p', 'hint', 'Mẹo: Loại = “Cẩm nang” → hiện thẻ tải to ở mục Cẩm nang. Loại = “Infographic” (file ảnh) → hiện ở Góc tuyên truyền.'));
    box.appendChild(el('p', 'hint', 'Tải lên ảnh hoặc PDF (≤ 20 MB). File Word/PowerPoint: lưu thành PDF, hoặc dán link Google Drive (nhớ bật “Bất kỳ ai có đường liên kết”).'));
    listEditor(box, DATA.docs, 'Tài liệu', () => ({ id: 'd' + Date.now(), title: '', description: '', category: 'Phiếu học tập', url: '', kind: 'link' }), (c, d) => {
      c.append(inp('Tên tài liệu', d.title, set(d, 'title')), inp('Loại', d.category, set(d, 'category'), { ph: 'Cẩm nang, Phiếu học tập, Đề ôn…' }), inp('Mô tả ngắn', d.description, set(d, 'description')));
      const urlF = inp('Liên kết (Google Drive, YouTube…)', /^\/_blob\//.test(d.url || '') ? '' : d.url, (v) => { d.url = v; d.kind = 'link'; markDirty(); }, { type: 'url', ph: 'https://…' });
      const f = el('div', 'fld'); f.appendChild(el('label', '', '…hoặc tải file lên')); const up = el('label', 'mini pick-up', '⬆ Chọn file PDF/ảnh'); const fi = el('input'); fi.type = 'file'; fi.accept = 'application/pdf,image/*'; fi.hidden = true; up.appendChild(fi);
      const st = el('small', '', /^\/_blob\//.test(d.url || '') ? '✓ Đã có file tải lên' : ''); f.append(up, st);
      fi.addEventListener('change', async () => { const file = fi.files[0]; if (!file) return; st.textContent = 'Đang tải lên…'; try { d.url = await uploadFile(file, 2400); d.kind = file.type.startsWith('image/') ? 'image' : 'pdf'; if (!d.title) d.title = file.name.replace(/\.[^.]+$/, ''); urlF.querySelector('input').value = ''; st.textContent = '✓ Đã tải lên: ' + file.name; markDirty(); } catch (e) { st.textContent = '⚠ ' + e.message; } fi.value = ''; });
      c.append(urlF, f, inp('Link tải dự phòng cho người chưa đăng nhập (Google Drive, Canva…)', d.ext, set(d, 'ext'), { type: 'url' }), imgField('Ảnh bìa (không bắt buộc)', d.thumb, set(d, 'thumb'), { maxSide: 1000 }));
    }, { label: 'TÀI LIỆU', top: true });
  }
  if (edTab === 'general') {
    [['announcement', 'Dòng thông báo trên cùng'], ['hero_lead', 'Câu giới thiệu đầu trang', 1], ['intro_text', 'Đoạn “Về chúng mình”', 1], ['motto_title', 'Phương châm'], ['motto_text', 'Giải thích phương châm', 1], ['join_text', 'Đoạn mời tham gia', 1], ['join_how', 'Cách đăng ký tham gia', 1], ['schedule', 'Lịch sinh hoạt (trống = ẩn)', 1], ['contact', 'Liên hệ: phòng, Zalo nhóm… (trống = ẩn)', 1]]
      .forEach(([k, l, a]) => box.appendChild(inp(l, G[k], set(G, k), { area: Boolean(a), rows: 2 })));
    G.links = G.links || [];
    G.qrs = G.qrs || [];
    listEditor(box, G.qrs, 'Mã QR ở mục Tham gia', () => ({ label: '', url: '', img: '' }), (c, q) => { c.append(inp('Tên', q.label, set(q, 'label'), { ph: 'Fanpage, Zalo…' }), inp('Link khi bấm vào', q.url, set(q, 'url'), { type: 'url' }), imgField('Ảnh mã QR', q.img, set(q, 'img'), { maxSide: 900 })); }, { label: 'MÃ', empty: 'Chưa có mã QR.' });
    listEditor(box, G.links, 'Nút liên kết ở mục Tham gia', () => ({ label: 'Đăng ký tham gia', url: '' }), (c, l) => { c.append(inp('Chữ trên nút', l.label, set(l, 'label')), inp('Đường link (Google Form, Zalo, Facebook…)', l.url, set(l, 'url'), { type: 'url', ph: 'https://forms.gle/…' })); }, { label: 'NÚT', empty: 'Chưa có nút. VD: thêm link Google Form để học sinh đăng ký.' });
  }
  if (edTab === 'stages') {
    listEditor(box, DATA.stages, 'Các chặng', () => ({ icon: '✨', name: '', short: '', title: '', desc: '', items: [] }), (c, s) => {
      c.append(inp('Biểu tượng (emoji)', s.icon, set(s, 'icon')), inp('Tên chặng', s.name, set(s, 'name')), inp('Mô tả ngắn', s.short, set(s, 'short')), inp('Tiêu đề chi tiết', s.title, set(s, 'title')), inp('Giải thích', s.desc, set(s, 'desc'), { area: true }),
        inp('Ý chính (mỗi dòng 1 ý)', (s.items || []).join('\n'), (v) => { s.items = v.split('\n').map((x) => x.trim()).filter(Boolean); markDirty(); }, { area: true }));
    }, { label: 'CHẶNG' });
  }
  if (edTab === 'quiz') {
    box.appendChild(inp('Số câu mỗi lượt chơi (bốc ngẫu nhiên từ kho)', DATA.quiz_per_round || 8, (v) => { DATA.quiz_per_round = Math.max(1, parseInt(v, 10) || 8); markDirty(); }, { type: 'number' }));
    listEditor(box, DATA.quiz, 'Câu hỏi', () => ({ q: '', options: ['', '', ''], ans: 0, explain: '' }), (c, q) => {
      c.append(inp('Câu hỏi', q.q, set(q, 'q'), { area: true, rows: 2 }), inp('Phương án (mỗi dòng 1 phương án)', (q.options || []).join('\n'), (v) => { q.options = v.split('\n').map((x) => x.trim()).filter(Boolean); markDirty(); }, { area: true }),
        inp('Đáp án đúng là phương án số', (Number(q.ans) || 0) + 1, (v) => { q.ans = Math.max(0, (parseInt(v, 10) || 1) - 1); markDirty(); }, { type: 'number' }), inp('Giải thích', q.explain, set(q, 'explain'), { area: true, rows: 2 }));
    }, { label: 'CÂU' });
  }
  if (edTab === 'prompts') {
    DATA.prompts = DATA.prompts || [];
    box.appendChild(el('p', 'hint', 'Mỗi môn 1 thẻ; mỗi dòng là 1 câu lệnh. Số thứ tự tự đánh.'));
    listEditor(box, DATA.prompts, 'Các môn', () => ({ icon: '💬', subject: '', color: '#5b3fb5', items: [] }), (c, s) => {
      c.append(inp('Biểu tượng (emoji)', s.icon, set(s, 'icon')), inp('Tên môn', s.subject, set(s, 'subject')),
        inp('Câu lệnh (mỗi dòng 1 câu)', (s.items || []).join('\n'), (v) => { s.items = v.split('\n').map((x) => x.trim()).filter(Boolean); markDirty(); }, { area: true, rows: 5 }));
    }, { label: 'MÔN' });
  }
  if (edTab === 'days') {
    box.appendChild(inp('Mỗi dòng là nhiệm vụ của 1 ngày', (DATA.days || []).join('\n'), (v) => { DATA.days = v.split('\n').map((x) => x.trim()).filter(Boolean); markDirty(); }, { area: true, rows: 10 }));
    DATA.tree = DATA.tree || { gifts: [] }; DATA.tree.gifts = DATA.tree.gifts || [];
    { const l = el('label', 'check-line'); const c = el('input'); c.type = 'checkbox'; c.checked = DATA.tree.one_per_day !== false; c.addEventListener('change', () => { DATA.tree.one_per_day = c.checked; markDirty(); }); l.append(c, el('span', '', 'Mỗi ngày chỉ được tưới (hoàn thành) 1 nhiệm vụ')); box.appendChild(l); }
    box.appendChild(el('h4', 'ed-sub', '🎁 Quà khi tưới cây'));
    box.appendChild(el('p', 'hint', 'Quà cuối cùng (số lần lớn nhất) sẽ là giấy chứng nhận có tên học sinh.'));
    listEditor(box, DATA.tree.gifts, 'Các mốc quà', () => ({ at: 3, emoji: '🎁', title: '', desc: '' }), (c, g) => {
      c.append(inp('Tưới đủ bao nhiêu lần', g.at, (v) => { g.at = Math.max(1, parseInt(v, 10) || 1); markDirty(); }, { type: 'number' }), inp('Biểu tượng', g.emoji, set(g, 'emoji')), inp('Tên quà', g.title, set(g, 'title')), inp('Lời nhắn khi mở quà', g.desc, set(g, 'desc'), { area: true, rows: 2 }));
    }, { label: 'QUÀ' });
  }
  if (edTab === 'chat') {
    const C = DATA.chat;
    box.append(inp('Lời chào khi mở chat', C.welcome, set(C, 'welcome'), { area: true }), inp('Lời dặn thêm cho Mầm AI', C.extra_instructions, set(C, 'extra_instructions'), { area: true, rows: 6, hint: 'VD: “Tuần này CLB ôn Bài 8 Lịch sử 12, nhắc các bạn xem phiếu học tập Bài 8 trong Kho tài liệu.”' }));
    box.appendChild(el('p', 'hint', 'Mầm trả lời bằng AI khi người xem đã đăng nhập Claude; nếu không, Mầm dùng câu trả lời có sẵn.'));
  }
}

let adminReady = false;
/* ===== Bật các khả năng của nền tảng (nếu có) ===== */
(async () => {
  const c = window.claude; if (!c || !c.use) return;
  c.use('sample').then((s) => { if (s) { sample = s; setChatStatus(); } }).catch(() => {});
  c.use('downloads').then((x) => { if (x) { DL = x; renderDocs(); renderHandbook(); renderPosters(); } }).catch(() => {});
  try {
    const [user, art] = await Promise.all([c.use('user'), c.use('artifact')]);
    let can = false; try { can = Boolean(user && (await user.canEdit())); } catch (_) {}
    if (!can || !art) return;
    ART = art; ASSETS = await c.use('assets').catch(() => null);
    buildEditorShell();
    if (location.hash === '#quan-tri') openEditor();
  } catch (_) {}
  finally { adminReady = true; }
})();
/* Link quản trị: ...#quan-tri */
function adminHint() { if (location.hash !== '#quan-tri' || window.CLB_STANDALONE) return; const wait = () => { if (!adminReady) return setTimeout(wait, 400); if ($('editor')) openEditor(); else toast('🔒 Trang quản trị: hãy đăng nhập Claude bằng tài khoản quản trị rồi mở lại link này.'); }; setTimeout(wait, 1500); }
window.addEventListener('hashchange', adminHint); setTimeout(() => { if (!window.claude) { adminReady = true; } adminHint(); }, 0);

/* =====================================================================
   SÂN CHƠI AI – XP, cấp độ, chuỗi ngày, nhiệm vụ, hiệu ứng, 2 game mới
   ===================================================================== */
const REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const todayVN = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
const dayShift = (ymd, n) => { const d = new Date(ymd + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const pickOne = (a) => a[Math.floor(Math.random() * a.length)];

/* ---------- Pháo giấy ---------- */
const FX = { parts: [], running: false };
function confetti(n = 120, x, y) {
  if (REDUCED) return; const c = $('fxCanvas'); if (!c) return;
  c.width = innerWidth; c.height = innerHeight;
  const cx = x ?? innerWidth / 2, cy = y ?? innerHeight / 3; const cols = ['#ff6b9a', '#7b5cff', '#22c39a', '#ffc23d', '#3fa9ff', '#ff8a3d'];
  for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = 4 + Math.random() * 9; FX.parts.push({ x: cx, y: cy, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 6, r: 4 + Math.random() * 6, c: pickOne(cols), rot: Math.random() * 6, vr: (Math.random() - .5) * .4, life: 90 + Math.random() * 50 }); }
  if (!FX.running) { FX.running = true; requestAnimationFrame(fxLoop); }
}
function fxLoop() {
  const c = $('fxCanvas'), g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height);
  FX.parts = FX.parts.filter((p) => p.life > 0);
  FX.parts.forEach((p) => { p.vy += .25; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.life--; g.save(); g.globalAlpha = Math.min(1, p.life / 40); g.translate(p.x, p.y); g.rotate(p.rot); g.fillStyle = p.c; g.fillRect(-p.r / 2, -p.r / 3, p.r, p.r * .66); g.restore(); });
  if (FX.parts.length) requestAnimationFrame(fxLoop); else { FX.running = false; g.clearRect(0, 0, c.width, c.height); }
}

/* ---------- XP & cấp độ ---------- */
const LEVELS = [
  [0, '🌰', 'Hạt mầm'], [100, '🌱', 'Nảy mầm'], [250, '🌿', 'Chồi non'], [450, '☘️', 'Lá xanh'], [700, '🪴', 'Cây con'],
  [1000, '🌳', 'Cây khỏe'], [1400, '🔍', 'Thợ săn tập sự'], [1900, '🕵️', 'Thợ săn lành nghề'], [2500, '🛡️', 'Hiệp sĩ AI'], [3200, '🚀', 'Phi công cầm lái'], [4000, '🏆', 'Bậc thầy AI'],
];
const levelOf = (xp) => { let i = 0; LEVELS.forEach((l, k) => { if (xp >= l[0]) i = k; }); return i; };
const PRAISE = [
  'Tuyệt vời! Mỗi ngày một chút, bạn đang tiến bộ thật sự! 🌟', 'Đỉnh quá! Não bộ của bạn vừa được tập thể dục đó 💪', 'Giỏi ghê! Bạn cầm lái AI ngày càng vững tay rồi 🚗',
  'Xuất sắc! Thợ săn lỗi AI đây rồi 🔍', 'Quá chất! Cứ giữ phong độ này nhé 🔥', 'Bạn làm tốt lắm! Mầm tự hào về bạn 🌱', 'Cừ thật! Hôm nay bạn giỏi hơn hôm qua rồi đó ✨',
];
const BADGES = [
  { id: 'first', e: '🎮', t: 'Lần đầu ra sân', ok: (s) => s.games >= 1 },
  { id: 'perfect', e: '💯', t: 'Thợ săn hoàn hảo', ok: (s) => s.perfect >= 1 },
  { id: 'shield', e: '🛡️', t: 'Lá chắn thép (200 điểm)', ok: (s) => s.shieldBest >= 200 },
  { id: 'tower', e: '🧱', t: 'Kiến trúc sư câu lệnh (3 tháp)', ok: (s) => s.towers >= 3 },
  { id: 'streak3', e: '🔥', t: 'Chuỗi 3 ngày', ok: (s) => s.streak >= 3 },
  { id: 'streak7', e: '⚡', t: 'Chuỗi 7 ngày', ok: (s) => s.streak >= 7 },
  { id: 'lv5', e: '🌳', t: 'Đạt cấp 5', ok: (s) => levelOf(s.xp) >= 4 },
  { id: 'lv10', e: '🏆', t: 'Đạt cấp 10', ok: (s) => levelOf(s.xp) >= 9 },
];
const P0 = { xp: 0, streak: 0, lastPlay: '', games: 0, perfect: 0, shieldBest: 0, towers: 0, days: {} };
const player = () => Object.assign({}, P0, store.get('player', {}));
function savePlayer(p) { const keep = {}; Object.keys(p.days || {}).sort().slice(-14).forEach((k) => { keep[k] = p.days[k]; }); p.days = keep; store.set('player', p); }

/* Nhiệm vụ ngày: 3 nhiệm vụ đổi theo ngày */
const MISSIONS = [
  { id: 'q5', t: 'Trả lời đúng 5 câu Đấu trường Đúng – Sai', k: 'quizOk', n: 5 },
  { id: 'qr', t: 'Hoàn thành 1 trận Đấu trường Đúng – Sai', k: 'quizRounds', n: 1 },
  { id: 's100', t: 'Đạt 100 điểm Lá chắn dữ liệu', k: 'shieldTop', n: 100 },
  { id: 's2', t: 'Chơi Lá chắn dữ liệu 2 lượt', k: 'shieldRuns', n: 2 },
  { id: 't1', t: 'Xây xong 1 tháp câu lệnh 3D', k: 'towers', n: 1 },
  { id: 't8', t: 'Vượt 8 thử thách nhỏ (kéo thả, ghép cặp, mật thư…)', k: 'blocks', n: 8 },
  { id: 'xp', t: 'Kiếm 80 XP trong hôm nay', k: 'xp', n: 80 },
  { id: 'tree', t: 'Tưới cây Mầm hôm nay 💧', k: 'tree', n: 1 },
];
function todayMissions() {
  const d = todayVN(); let h = 0; for (const ch of d) h = (h * 33 + ch.charCodeAt(0)) % 9973;
  const out = []; let k = h; while (out.length < 3) { const m = MISSIONS[k % MISSIONS.length]; if (!out.includes(m)) out.push(m); k = Math.floor(k / 3) + 7 + out.length * 5; }
  return out;
}
function dayStats() { const d = store.get('daystats', {}); return d.date === todayVN() ? d : { date: todayVN(), done: {}, chest: false }; }
function bumpDay(k, v, mode = 'add') {
  const s = dayStats(); s[k] = mode === 'max' ? Math.max(s[k] || 0, v) : (s[k] || 0) + v; store.set('daystats', s); checkMissions();
}
function checkMissions() {
  const s = dayStats(); let changed = false;
  const dates = Object.values(store.get('cdates', {})); s.tree = dates.includes(todayVN()) ? 1 : 0;
  todayMissions().forEach((m) => { if (!s.done[m.id] && (s[m.k] || 0) >= m.n) { s.done[m.id] = true; changed = true; store.set('daystats', s); gainXP(20, null, true); toast(`✅ Xong nhiệm vụ: ${m.t} · +20 XP`); } });
  if (!s.chest && todayMissions().every((m) => s.done[m.id])) { s.chest = true; store.set('daystats', s); gainXP(50, null, true); setTimeout(() => { confetti(180); toast('🎁 Mở rương ngày: +50 XP! ' + pickOne(PRAISE)); }, 600); changed = true; }
  store.set('daystats', s); if (changed) renderPlayer();
}
function gainXP(n, game, silent) {
  if (!n) return; const p = player(); const before = levelOf(p.xp); const t = todayVN();
  if (p.lastPlay !== t) { p.streak = p.lastPlay === dayShift(t, -1) ? p.streak + 1 : 1; p.lastPlay = t; if (p.streak > 1) setTimeout(() => toast(`🔥 Chuỗi ${p.streak} ngày liên tiếp! Giữ lửa nhé!`), 900); }
  p.xp = Math.min(99999, p.xp + n); p.days[t] = (p.days[t] || 0) + n; savePlayer(p);
  if (!silent) floatXP(n);
  const after = levelOf(p.xp);
  if (after > before) setTimeout(() => { confetti(200); toast(`🎉 LÊN CẤP ${after + 1}: ${LEVELS[after][1]} ${LEVELS[after][2]}! ${pickOne(PRAISE)}`); }, 400);
  const s = dayStats(); s.xp = p.days[t]; store.set('daystats', s);
  renderPlayer(); if (game !== 'mission') checkMissions(); renderSaveCode && renderSaveCode();
}
function floatXP(n) {
  const card = $('playerCard'); if (!card || REDUCED) return; const f = el('span', 'xp-float', `+${n} XP`); card.appendChild(f); setTimeout(() => f.remove(), 1300);
}
function renderPlayer() {
  if (!$('playerCard')) return; const p = player(); const L = levelOf(p.xp); const cur = LEVELS[L], nxt = LEVELS[L + 1];
  $('pcAvatar').textContent = cur[1]; $('pcLevelNo').textContent = 'Cấp ' + (L + 1); $('pcLevelName').textContent = cur[2];
  const alive = p.lastPlay === todayVN() || p.lastPlay === dayShift(todayVN(), -1); const st = alive ? p.streak : 0;
  $('pcStreak').textContent = `🔥 ${st} ngày`; $('pcStreak').classList.toggle('hot', st >= 3);
  const pct = nxt ? (p.xp - cur[0]) / (nxt[0] - cur[0]) * 100 : 100; $('pcXpFill').style.width = Math.max(3, pct) + '%';
  $('pcXpText').textContent = nxt ? `${p.xp} / ${nxt[0]} XP · còn ${nxt[0] - p.xp} XP lên cấp` : `${p.xp} XP · Cấp tối đa!`;
  const today = p.days[todayVN()] || 0;
  $('pcPraise').textContent = p.xp === 0 ? 'Chơi một game bất kì để bắt đầu hành trình nhé! 🌱' : today ? `Hôm nay bạn đã kiếm ${today} XP. ${today >= 80 ? 'Quá đỉnh! 🔥' : 'Cố thêm chút nữa nhé! 💪'}` : 'Hôm nay chưa chơi đâu nha – vào sân giữ chuỗi 🔥 nào!';
  const sv = Object.assign({}, p, { streak: st }); const bx = $('pcBadges'); bx.innerHTML = '';
  BADGES.forEach((b) => { const on = b.ok(sv) || (store.get('badges', {})[b.id]); if (b.ok(sv)) { const bb = store.get('badges', {}); if (!bb[b.id]) { bb[b.id] = true; store.set('badges', bb); setTimeout(() => toast(`🏅 Huy hiệu mới: ${b.e} ${b.t}!`), 1200); } } const s = el('span', 'pc-badge' + (on ? ' on' : ''), b.e); s.title = b.t + (on ? '' : ' (chưa mở)'); bx.appendChild(s); });
  const ds = dayStats(); const ul = $('pcMissions'); ul.innerHTML = '';
  todayMissions().forEach((m) => { const v = m.k === 'tree' ? (Object.values(store.get('cdates', {})).includes(todayVN()) ? 1 : 0) : (ds[m.k] || 0); const done = ds.done[m.id]; const li = el('li', done ? 'done' : ''); li.append(el('i', '', done ? '✅' : '⬜'), el('span', '', m.t), el('em', '', done ? '+20' : `${Math.min(v, m.n)}/${m.n}`)); ul.appendChild(li); });
  $('pcChest').textContent = ds.chest ? '🎉' : '🎁'; $('pcChest').title = ds.chest ? 'Đã mở rương hôm nay' : 'Xong cả 3 nhiệm vụ để mở rương +50 XP';
  const ch = $('pcChart'); ch.innerHTML = ''; const vals = []; for (let i = 6; i >= 0; i--) { const d = dayShift(todayVN(), -i); vals.push([d, p.days[d] || 0]); }
  const mx = Math.max(40, ...vals.map((v) => v[1]));
  vals.forEach(([d, v], i) => { const col = el('div', 'pc-col' + (i === 6 ? ' today' : '')); const bar = el('i'); bar.style.height = Math.max(4, v / mx * 100) + '%'; bar.title = `${d.slice(8)}/${d.slice(5, 7)}: ${v} XP`; col.append(el('b', '', v ? String(v) : ''), bar, el('small', '', i === 6 ? 'Nay' : d.slice(8) + '/' + d.slice(5, 7))); ch.appendChild(col); });
  const code = typeof makeCode === 'function' ? makeCode() : ''; $('pcCode').textContent = code || 'chơi để nhận mã';
}

/* ---------- Tab game ---------- */
function showGame(g) {
  document.querySelectorAll('.gtab').forEach((b) => b.classList.toggle('active', b.dataset.g === g));
  document.querySelectorAll('.game-panel').forEach((p) => { const on = p.dataset.p === g; p.hidden = !on; p.classList.toggle('active', on); });
  if (g === 'shield') Shield.resize(); else Shield.pause();
  if (g === 'tower') Tower.init(); else Tower.sleep();
}

/* =====================================================================
   GAME 2D – LÁ CHẮN DỮ LIỆU
   ===================================================================== */

/* ===== KHO DỮ LIỆU GAME: Lá chắn dữ liệu (90 thẻ) & Tháp câu lệnh (36 tình huống) ===== */
/* [chữ trên thẻ, là thông tin KHÔNG được đưa cho AI?, mức 1-3, giải thích] */
const SH_BANK = [
  ['🔑 Mật khẩu', 1, 1, 'Mật khẩu là chìa khóa tài khoản – không đưa cho ai, kể cả AI.'],
  ['🔢 Mã OTP', 1, 1, 'Ai có OTP là có thể chiếm tài khoản hoặc rút tiền của bạn.'],
  ['🪪 Số CCCD', 1, 1, 'Số CCCD có thể bị dùng để giả danh, mở tài khoản lừa đảo.'],
  ['🏦 Số tài khoản', 1, 1, 'Thông tin ngân hàng phải giữ kín tuyệt đối.'],
  ['💳 Số thẻ ngân hàng', 1, 1, 'Lộ số thẻ có thể bị mất tiền.'],
  ['🔐 Mật khẩu Zalo', 1, 1, 'Lộ mật khẩu Zalo → kẻ xấu nhắn tin lừa người thân.'],
  ['🔐 Mật khẩu Facebook', 1, 1, 'Tài khoản mạng xã hội bị chiếm rất khó lấy lại.'],
  ['🔢 Mã PIN ATM', 1, 1, 'Mã PIN chỉ mình chủ thẻ được biết.'],
  ['📸 Ảnh CCCD', 1, 1, 'Ảnh CCCD bị dùng để vay tiền, lập tài khoản giả.'],
  ['📧 Mật khẩu email', 1, 1, 'Email là “chìa khóa vạn năng” của nhiều tài khoản khác.'],
  ['🏠 Địa chỉ nhà', 1, 2, 'Địa chỉ nhà là thông tin riêng, có thể bị kẻ xấu lợi dụng.'],
  ['📱 SĐT của bạn bè', 1, 2, 'Đó là thông tin của người khác – không được tự ý chia sẻ.'],
  ['📞 SĐT của bố mẹ', 1, 2, 'Kẻ lừa đảo hay dùng SĐT người thân để giả danh.'],
  ['🖼️ Ảnh riêng tư', 1, 2, 'Ảnh riêng tư có thể bị phát tán, cắt ghép.'],
  ['🤳 Ảnh mặt bạn bè', 1, 2, 'Ảnh mặt có thể bị dùng làm deepfake – phải được đồng ý.'],
  ['🆔 Mã đăng nhập VNeID', 1, 2, 'VNeID chứa giấy tờ quan trọng – tuyệt đối giữ kín.'],
  ['🚗 Biển số xe nhà', 1, 2, 'Biển số xe + địa chỉ có thể giúp kẻ xấu theo dõi.'],
  ['🎫 Ảnh thẻ học sinh', 1, 2, 'Thẻ học sinh lộ tên, lớp, trường, ảnh mặt của bạn.'],
  ['📅 Họ tên + ngày sinh', 1, 2, 'Họ tên kèm ngày sinh đủ để giả danh bạn.'],
  ['✉️ Email + mật khẩu', 1, 2, 'Không bao giờ gửi cặp email và mật khẩu ở bất cứ đâu.'],
  ['📍 Vị trí GPS lúc này', 1, 3, 'Vị trí thật cho người lạ biết bạn đang ở đâu.'],
  ['🗓️ Lịch đi học hằng ngày', 1, 3, 'Lịch di chuyển cố định có thể bị kẻ xấu theo dõi.'],
  ['📊 Ảnh bảng điểm có tên', 1, 3, 'Bảng điểm có họ tên, lớp – là thông tin cá nhân.'],
  ['💬 Tin nhắn riêng của bạn', 1, 3, 'Tin nhắn của bạn bè là chuyện riêng của họ.'],
  ['🔳 Mã QR thanh toán', 1, 3, 'Mã QR thanh toán gắn với tài khoản ngân hàng.'],
  ['📜 Ảnh giấy khai sinh', 1, 3, 'Giấy khai sinh có đủ thông tin để giả mạo danh tính.'],
  ['🏥 Bệnh án người thân', 1, 3, 'Thông tin sức khỏe là dữ liệu nhạy cảm.'],
  ['🤫 Bí mật của bạn thân', 1, 3, 'Chuyện riêng của bạn không phải của mình để kể.'],
  ['🖥️ Ảnh màn hình có OTP', 1, 3, 'Ảnh chụp màn hình vẫn làm lộ mã OTP.'],
  ['👥 Ảnh tin nhắn nhóm lớp', 1, 3, 'Ảnh nhóm lớp lộ tên, SĐT, tin nhắn của nhiều bạn.'],
  ['☎️ SĐT riêng của thầy cô', 1, 3, 'Không chia sẻ thông tin liên lạc của người khác.'],
  ['🏫 Họ tên + lớp + trường', 1, 3, 'Ghép đủ 3 thông tin này là người lạ tìm được bạn.'],
  ['📘 Câu hỏi bài học', 0, 1, 'Hỏi AI về bài học là cách dùng AI an toàn.'],
  ['🧮 Gợi ý bài Toán', 0, 1, 'Xin gợi ý để tự làm – rất nên!'],
  ['🌍 Hỏi về Địa lí', 0, 1, 'Kiến thức chung – an toàn.'],
  ['🔤 Từ vựng mới', 0, 1, 'Hỏi nghĩa từ vựng – an toàn.'],
  ['🏛️ Mốc lịch sử', 0, 1, 'Kiến thức chung – an toàn, nhớ kiểm chứng với SGK.'],
  ['💡 Mẹo ghi nhớ', 0, 1, 'Hỏi mẹo học – an toàn.'],
  ['📅 Lập lịch ôn bài', 0, 1, 'Nhờ AI gợi ý lịch học – an toàn.'],
  ['🧪 Hiện tượng Hóa', 0, 1, 'Câu hỏi khoa học – an toàn.'],
  ['⚡ Công thức Vật lí', 0, 1, 'Hỏi công thức – an toàn.'],
  ['✍️ Cách viết mở bài', 0, 1, 'Hỏi cách làm – an toàn.'],
  ['📝 Nhận xét dàn ý', 0, 2, 'Nhờ AI góp ý bài em tự làm – rất tốt.'],
  ['🗂️ Dàn ý em tự lập', 0, 2, 'Bài em tự làm, không có thông tin riêng – an toàn.'],
  ['🇬🇧 Câu tiếng Anh cần sửa', 0, 2, 'Nhờ AI chỉ lỗi – an toàn.'],
  ['📗 Đề bài trong SGK', 0, 2, 'Đề trong sách là nội dung chung – an toàn.'],
  ['🧠 Sơ đồ tư duy của em', 0, 2, 'Sản phẩm học tập – an toàn để xin góp ý.'],
  ['🔬 Ý tưởng dự án KHKT', 0, 2, 'Trao đổi ý tưởng – an toàn (nhớ khai báo khi dùng AI).'],
  ['📈 Cách đọc biểu đồ', 0, 2, 'Kỹ năng học tập – an toàn.'],
  ['⚖️ So sánh 2 khái niệm', 0, 2, 'Câu hỏi kiến thức – an toàn.'],
  ['❓ Câu hỏi ôn tập', 0, 2, 'Nhờ AI ra câu hỏi ôn – rất nên.'],
  ['💻 Đoạn code bị lỗi', 0, 2, 'Code bài tập không chứa thông tin riêng – an toàn.'],
  ['👤 Tên nhân vật lịch sử', 0, 3, 'Thông tin công khai – an toàn, không phải dữ liệu cá nhân của bạn.'],
  ['🗺️ Tên địa danh nổi tiếng', 0, 3, 'Địa danh công khai – an toàn.'],
  ['📚 Tên tác phẩm văn học', 0, 3, 'Kiến thức chung – an toàn.'],
  ['🌸 Bài thơ trong SGK', 0, 3, 'Nội dung sách giáo khoa – an toàn.'],
  ['👥 Dân số Việt Nam', 0, 3, 'Số liệu công khai – an toàn.'],
  ['🎂 Năm sinh của Bác Hồ', 0, 3, 'Đây là kiến thức lịch sử công khai, không phải ngày sinh của bạn.'],
  ['🌳 Tên một loài cây', 0, 3, 'Kiến thức chung – an toàn.'],
  ['🏞️ Tên một con sông', 0, 3, 'Kiến thức chung – an toàn.'],
  ['📄 Đoạn văn em tự viết', 0, 3, 'Bài viết của em (không có thông tin riêng) – an toàn để xin góp ý.'],
  ['🛡️ Hỏi về an toàn mạng', 0, 3, 'Hỏi cách tự bảo vệ – rất nên!'],
  ['🧾 Mẫu khai báo dùng AI', 0, 3, 'Hỏi cách khai báo trung thực – rất nên.'],
  ['🗳️ Ý nghĩa ngày Quốc khánh', 0, 3, 'Kiến thức lịch sử chung – an toàn.'],
  ['🏔️ Khí hậu Lâm Đồng', 0, 3, 'Kiến thức Địa lí chung – an toàn.'],
  ['🎵 Cách luyện phát âm', 0, 3, 'Kỹ năng học tập – an toàn.'],
];

/* Tháp câu lệnh: phương án đầu tiên của mỗi tầng là đáp án đúng (khi chơi sẽ được xáo trộn). */
const TW_BANK = [
  /* ---------- MỨC DỄ ---------- */
  { lv: 1, s: 'Lịch sử', sit: 'Ngày mai kiểm tra bài Cách mạng tháng Tám, em muốn tự ôn cho chắc.', o: [
    ['Bạn là gia sư Lịch sử kiên nhẫn.', 'Bạn là người làm bài hộ thật nhanh.', 'Bạn là máy tra đáp án có sẵn.'],
    ['Em đã đọc bài trong SGK.', 'Em chưa đọc, lười lắm.', 'Không cần biết em học gì.'],
    ['Hỏi em 5 câu từ dễ đến khó.', 'Viết sẵn đề cương để em chép.', 'Đưa luôn đáp án đề kiểm tra.'],
    ['Chờ em trả lời rồi mới nhận xét.', 'Trả lời càng dài, càng chi tiết càng tốt.', 'Không cần giải thích gì cho em cả.']] },
  { lv: 1, s: 'Toán', sit: 'Em làm bài phương trình được nửa chừng thì bí.', o: [
    ['Bạn là gia sư Toán biết gợi mở.', 'Bạn là máy giải toán siêu tốc.', 'Bạn là bạn thân chép bài hộ.'],
    ['Đây là đề và phần em đã làm.', 'Em không muốn nghĩ nữa đâu.', 'Đề bài thì em quên mất rồi.'],
    ['Gợi ý bước tiếp theo cho em.', 'Giải hết và cho đáp số luôn.', 'Làm hộ cả 10 bài còn lại.'],
    ['Đừng giải hết, để em tự làm.', 'Chỉ cần ghi đáp số cuối cùng.', 'Viết thật nhanh, khỏi giải thích.']] },
  { lv: 1, s: 'Ngữ văn', sit: 'Em đã lập dàn ý bài nghị luận nhưng thấy còn sơ sài.', o: [
    ['Bạn là giáo viên Văn tận tâm.', 'Bạn là người viết văn thuê.', 'Bạn là kho bài văn mẫu.'],
    ['Đây là dàn ý em tự lập.', 'Em chưa lập dàn ý gì cả.', 'Em muốn nộp bài cho xong.'],
    ['Nhận xét dàn ý còn thiếu gì.', 'Viết giúp em cả bài văn 600 chữ.', 'Tìm bài văn mẫu để em chép lại.'],
    ['Đừng viết hộ, chỉ góp ý thôi.', 'Viết sao cho thầy cô khó phát hiện.', 'Càng giống văn mẫu càng tốt.']] },
  { lv: 1, s: 'Tiếng Anh', sit: 'Em vừa viết đoạn văn tiếng Anh về sở thích của mình.', o: [
    ['Bạn là giáo viên tiếng Anh.', 'Bạn là máy dịch tự động.', 'Bạn là người viết hộ bài.'],
    ['Đây là đoạn văn em tự viết.', 'Em sẽ dán bài của bạn khác.', 'Em chưa viết chữ nào cả.'],
    ['Chỉ ra lỗi và giải thích vì sao.', 'Viết lại cả đoạn văn thật hay giúp em.', 'Dịch hết đoạn văn sang tiếng Việt.'],
    ['Để em tự sửa lại từng lỗi.', 'Sửa hết, em khỏi cần đọc.', 'Không cần giải thích lỗi đâu.']] },
  { lv: 1, s: 'Địa lí', sit: 'Em có biểu đồ dân số nhưng chưa biết cách nhận xét.', o: [
    ['Bạn là gia sư Địa lí dễ hiểu.', 'Bạn là người làm bài tập hộ.', 'Bạn là trang chép đáp án.'],
    ['Em đã đọc số liệu trên biểu đồ.', 'Em không thèm nhìn kĩ cái biểu đồ.', 'Biểu đồ em làm mất rồi, chịu thôi.'],
    ['Gợi ý các bước để em tự viết.', 'Viết sẵn bài nhận xét đầy đủ.', 'Cho em đáp án để chép nhanh.'],
    ['Hỏi lại em 1 câu để kiểm tra.', 'Viết thật dài cho đủ điểm.', 'Không cần em hiểu, chỉ cần nộp.']] },
  { lv: 1, s: 'An toàn mạng', sit: 'Em thấy một tin “giật gân” lan truyền trên mạng xã hội.', o: [
    ['Bạn là người hướng dẫn kiểm chứng.', 'Bạn là người chuyên tung tin nóng hổi.', 'Bạn là người tin mọi thứ trên mạng.'],
    ['Đây là nội dung tin em thấy.', 'Em đã chia sẻ cho cả lớp rồi.', 'Em chỉ đọc mỗi cái tiêu đề.'],
    ['Chỉ em các bước kiểm tra nguồn.', 'Khẳng định ngay tin đó là thật.', 'Viết thêm bài cho tin lan nhanh.'],
    ['Gợi ý trang chính thống để đối chiếu.', 'Đừng nhắc tới nguồn tin làm gì cho mệt.', 'Cứ đoán thôi, miễn là nghe hợp lí.']] },
  { lv: 1, s: 'Sinh học', sit: 'Em hay nhầm giữa nguyên phân và giảm phân.', o: [
    ['Bạn là gia sư Sinh học vui tính.', 'Bạn là máy làm đề cương hộ học sinh.', 'Bạn là người chép bài nhanh và giỏi.'],
    ['Em đã học bài nhưng hay nhầm.', 'Em chưa mở sách lần nào.', 'Em chỉ cần điểm, không cần hiểu.'],
    ['Lập bảng so sánh thật ngắn gọn.', 'Làm giúp hết bài tập trong sách nhé.', 'Đưa đáp án đề thi năm ngoái cho em.'],
    ['Sau đó hỏi em 3 câu kiểm tra.', 'Không cần em trả lời gì cả.', 'Viết càng nhiều chữ càng tốt.']] },
  { lv: 1, s: 'Hóa học', sit: 'Em chưa cân bằng được một phương trình hóa học.', o: [
    ['Bạn là gia sư Hóa học tỉ mỉ.', 'Bạn là máy cân bằng tự động.', 'Bạn là người làm bài thay em.'],
    ['Đây là phương trình em đang làm.', 'Em chẳng nhớ phương trình nào.', 'Em chỉ muốn chép cho nhanh.'],
    ['Gợi ý cách đếm số nguyên tử.', 'Cân bằng hộ tất cả phương trình.', 'Cho đáp án, khỏi cần cách làm.'],
    ['Để em tự điền hệ số cuối cùng.', 'Làm luôn cả bài tập về nhà giúp em.', 'Không cần em hiểu bước nào hết.']] },
  { lv: 1, s: 'Vật lí', sit: 'Em chưa hiểu vì sao đi xe đạp phanh gấp thì người lao về trước.', o: [
    ['Bạn là gia sư Vật lí vui tính.', 'Bạn là người làm bài thuê lấy tiền.', 'Bạn là kho đáp án có sẵn mọi bài.'],
    ['Em đã đọc bài quán tính trong SGK.', 'Em chưa học bài này bao giờ cả.', 'Em chỉ cần có đáp án để nộp thôi.'],
    ['Giải thích bằng ví dụ đời thường.', 'Làm hộ em cả phiếu bài tập về nhà.', 'Chép nguyên văn trong sách ra cho em.'],
    ['Ngắn gọn, rồi hỏi lại em 1 câu.', 'Càng nhiều công thức khó càng tốt.', 'Không cần em hiểu, chỉ cần chép.']] },
  { lv: 1, s: 'Tin học', sit: 'Chương trình Python của em chạy bị báo lỗi.', o: [
    ['Bạn là gia sư Tin học kiên nhẫn.', 'Bạn là người viết code thuê cho em.', 'Bạn là máy sinh code tự động hoàn toàn.'],
    ['Đây là code và dòng báo lỗi.', 'Em chưa viết dòng code nào.', 'Em sẽ chép code của bạn khác.'],
    ['Chỉ ra lỗi nằm ở dòng nào.', 'Viết lại toàn bộ chương trình.', 'Làm luôn các bài còn lại.'],
    ['Để em tự sửa rồi chạy thử.', 'Sửa hết, em khỏi cần đọc.', 'Không cần giải thích vì sao lỗi.']] },
  { lv: 1, s: 'GDCD', sit: 'Em đọc một tình huống về bắt nạt trên mạng nhưng chưa biết xử lí.', o: [
    ['Bạn là người hướng dẫn kĩ năng sống.', 'Bạn là người thích trêu chọc các bạn.', 'Bạn là người chỉ biết đứng ngoài xem.'],
    ['Đây là tình huống trong bài học.', 'Em đang muốn trả đũa bạn kia ngay.', 'Em định đăng ảnh bạn ấy lên mạng.'],
    ['Đặt câu hỏi để em tự tìm cách xử lí.', 'Viết sẵn câu trả lời để em chép vào vở.', 'Bày em cách nói xấu lại bạn ấy.'],
    ['Nhắc em cách nhờ người lớn giúp đỡ.', 'Bảo em giữ kín, đừng kể với ai hết.', 'Không cần nghĩ tới hậu quả làm gì.']] },
  { lv: 1, s: 'Kĩ năng học', sit: 'Tháng sau thi học kì, mỗi tối em rảnh khoảng 1 tiếng.', o: [
    ['Bạn là người hướng dẫn học tập.', 'Bạn là người học thay cho em luôn.', 'Bạn là người làm hết bài hộ em.'],
    ['Mỗi tối em rảnh 1 tiếng để ôn.', 'Em không muốn ôn bài gì cả.', 'Em định thức trắng đêm cuối.'],
    ['Gợi ý lịch ôn để em tự chọn.', 'Làm hộ đề cương tất cả các môn.', 'Tìm đề thi thật để em chép.'],
    ['Có giờ nghỉ và tự kiểm tra.', 'Học liền 5 tiếng không nghỉ.', 'Bỏ hết các môn em thấy khó.']] },
  /* ---------- MỨC VỪA ---------- */
  { lv: 2, s: 'Lịch sử', sit: 'Em muốn hiểu vì sao Cách mạng tháng Tám năm 1945 thành công.', tip: 'Đặt câu hỏi gợi mở giúp em TỰ rút ra nguyên nhân – nhớ lâu hơn là đọc danh sách có sẵn.', o: [
    ['Bạn là gia sư Sử biết đặt câu hỏi.', 'Bạn là nhà sử học, viết thật dài.', 'Bạn là trợ lí tóm tắt sách nhanh.'],
    ['Em đã đọc mục nguyên nhân trong SGK.', 'Em đang học lớp 12 và sắp thi rồi.', 'Em thấy phần này vừa khó vừa chán quá.'],
    ['Đặt câu hỏi gợi ý để em tự rút ra.', 'Liệt kê sẵn các nguyên nhân cho em.', 'Tóm tắt toàn bộ bài thành 1 trang.'],
    ['Đối chiếu lại với SGK sau mỗi ý.', 'Trả lời ngắn gọn, khỏi cần nguồn.', 'Viết thành văn mẫu để em học thuộc.']] },
  { lv: 2, s: 'Toán', sit: 'Em giải xong bài hình học nhưng kết quả khác bạn cùng bàn.', tip: 'Nhờ AI chỉ ra CHỖ SAI để tự sửa – không nhờ AI giải lại cả bài.', o: [
    ['Bạn là gia sư Toán biết soát lỗi.', 'Bạn là máy giải hình học tự động.', 'Bạn là trọng tài phân xử đúng sai.'],
    ['Đây là bài giải từng bước của em.', 'Đây là đáp số của em và của bạn.', 'Bạn em làm khác, chắc em sai rồi.'],
    ['Chỉ ra bước nào em có thể bị sai.', 'Giải lại toàn bộ để em so sánh.', 'Cho biết ai đúng, khỏi giải thích.'],
    ['Đừng sửa hộ, để em tự làm lại.', 'Sửa luôn giúp em cho nhanh nhé.', 'Chỉ cần nói đúng hay sai thôi.']] },
  { lv: 2, s: 'Ngữ văn', sit: 'Em đọc bài thơ “Tây Tiến” nhưng chưa cảm được cái hay.', tip: 'Câu hỏi gợi mở giúp em tự cảm nhận – bài phân tích sẵn sẽ là cảm nhận của AI, không phải của em.', o: [
    ['Bạn là giáo viên Văn giàu cảm xúc.', 'Bạn là nhà phê bình viết rất dài.', 'Bạn là kho bài phân tích mẫu.'],
    ['Em đã đọc kĩ bài thơ hai lần.', 'Em đã tìm được vài bài phân tích.', 'Em không thích thơ lắm đâu.'],
    ['Đặt câu hỏi để em tự cảm nhận.', 'Phân tích sẵn từng khổ thơ giúp em.', 'Gợi ý bài văn mẫu hay nhất cho em.'],
    ['Để em viết cảm nhận bằng lời mình.', 'Dùng thật nhiều từ ngữ hoa mĩ vào bài.', 'Viết sao cho thật giống văn mẫu.']] },
  { lv: 2, s: 'Tiếng Anh', sit: 'Em muốn luyện nói tiếng Anh để chuẩn bị thi nói.', tip: 'Luyện nói phải là EM nói – AI chỉ hỏi và sửa sau khi em trả lời.', o: [
    ['Bạn là bạn luyện nói tiếng Anh.', 'Bạn là người đọc mẫu thật hay.', 'Bạn là máy dịch Việt – Anh.'],
    ['Em đang ở trình độ cơ bản.', 'Em muốn có câu trả lời mẫu.', 'Em sợ nói sai nên ngại nói.'],
    ['Hỏi em từng câu về chủ đề trường học.', 'Viết sẵn bài nói để em học thuộc lòng.', 'Dịch hết các câu trả lời giúp em.'],
    ['Chờ em trả lời rồi mới sửa lỗi.', 'Sửa luôn trước khi em trả lời.', 'Không cần sửa, khen là được rồi.']] },
  { lv: 2, s: 'Địa lí', sit: 'Em khó nhớ các vùng kinh tế và thế mạnh của từng vùng.', tip: 'Mẹo ghi nhớ + câu hỏi kiểm tra lại giúp em nhớ thật, không chỉ đọc qua.', o: [
    ['Bạn là gia sư Địa lí có nhiều mẹo.', 'Bạn là cuốn atlat biết nói.', 'Bạn là người đọc bài cho em nghe.'],
    ['Em đã học nhưng nhanh quên.', 'Em chưa xem atlat bao giờ.', 'Em cần học thuộc trong 10 phút.'],
    ['Gợi ý mẹo nhớ rồi hỏi lại em.', 'Chép lại toàn bộ bài cho em.', 'Lập bảng dài thật đầy đủ chi tiết.'],
    ['Hỏi em 3 câu sau khi đưa mẹo.', 'Không cần hỏi lại, em tự nhớ.', 'Viết thật dài cho em học thuộc.']] },
  { lv: 2, s: 'Sinh học', sit: 'Em vừa học xong bài quang hợp, muốn tự kiểm tra.', tip: 'Tự kiểm tra hiệu quả là làm bài TRƯỚC, xem đáp án SAU.', o: [
    ['Bạn là gia sư Sinh học ra đề.', 'Bạn là người tóm tắt bài học.', 'Bạn là người kể chuyện khoa học.'],
    ['Em vừa học xong bài quang hợp.', 'Em sắp kiểm tra 15 phút rồi.', 'Em chưa hiểu bài lắm đâu.'],
    ['Ra 5 câu trắc nghiệm cho em làm.', 'Tóm tắt bài quang hợp thật ngắn.', 'Ra 5 câu kèm đáp án bên dưới.'],
    ['Chờ em làm xong mới chấm điểm.', 'Đưa đáp án ngay để em đối chiếu.', 'Chấm luôn, khỏi giải thích sai.']] },
  { lv: 2, s: 'Hóa học', sit: 'Em làm bài tính số mol, đến bước 2 thì ra kết quả lạ.', tip: 'Cho AI xem đúng phần em đã làm và xin giải thích lỗi – em sẽ không lặp lại lỗi đó.', o: [
    ['Bạn là gia sư Hóa biết tìm lỗi sai.', 'Bạn là máy tính số mol tự động.', 'Bạn là người chấm bài thật nghiêm.'],
    ['Đây là bài em làm đến bước 2.', 'Đây là đề bài, em chưa làm.', 'Bạn em làm ra đáp số khác.'],
    ['Giải thích vì sao bước 2 bị sai.', 'Làm lại từ đầu cho em xem cách giải.', 'Cho đáp số đúng để em so lại.'],
    ['Đừng cho đáp án, để em tự làm lại.', 'Giải thật nhanh, bỏ qua phần giải thích.', 'Làm luôn giúp em các câu tiếp theo.']] },
  { lv: 2, s: 'Vật lí', sit: 'Em có công thức nhưng không biết đổi đơn vị trước khi thay số.', tip: 'Xin quy tắc và cách làm – để AI tính hộ thì lần sau em vẫn không biết đổi đơn vị.', o: [
    ['Bạn là gia sư Vật lí tỉ mỉ.', 'Bạn là máy tính bỏ túi thông minh.', 'Bạn là người giải đề siêu tốc.'],
    ['Em có công thức và số liệu đề cho.', 'Em có đáp số ở cuối sách rồi.', 'Em muốn xong bài này trong 1 phút thôi.'],
    ['Nhắc em quy tắc đổi đơn vị.', 'Thay số và tính hộ em luôn.', 'Cho biết kết quả cuối cùng.'],
    ['Để em tự thay số rồi kiểm tra.', 'Tính sẵn từng bước cho em chép.', 'Không cần giải thích đơn vị.']] },
  { lv: 2, s: 'An toàn mạng', sit: 'Em nhận tin nhắn trúng thưởng, yêu cầu bấm link nhận quà.', tip: 'Hỏi AI cách NHẬN BIẾT lừa đảo – không bấm link, không gửi thông tin để “thử”.', o: [
    ['Bạn là chuyên gia an toàn mạng.', 'Bạn là người hay săn quà online.', 'Bạn là người bấm thử mọi link.'],
    ['Đây là nội dung tin, em chưa bấm.', 'Em đã bấm link và điền thông tin.', 'Em gửi link này cho bạn bè rồi.'],
    ['Chỉ em dấu hiệu nhận biết lừa đảo.', 'Hướng dẫn em cách nhận quà nhanh.', 'Bấm thử link xem có thật không.'],
    ['Nhắc em báo người lớn nếu nghi ngờ.', 'Bảo em giữ bí mật với bố mẹ cho lành.', 'Khuyên em gửi OTP để xác minh.']] },
  { lv: 2, s: 'Tin học', sit: 'Em muốn hiểu vòng lặp for hoạt động thế nào.', tip: 'Ví dụ nhỏ + bài tập tự làm giúp em hiểu cách chạy, không chỉ thuộc cú pháp.', o: [
    ['Bạn là gia sư lập trình dễ hiểu.', 'Bạn là tài liệu kĩ thuật rất dài.', 'Bạn là người viết code hộ em.'],
    ['Em đã biết in ra màn hình bằng print.', 'Em đã tự học hết Python ở nhà từ lâu rồi.', 'Em không thích môn lập trình lắm.'],
    ['Giải thích bằng 1 ví dụ thật nhỏ.', 'Viết sẵn 10 chương trình mẫu.', 'Giải thích hết các loại vòng lặp.'],
    ['Cho em 1 bài tập nhỏ để tự làm.', 'Làm hộ luôn bài tập trên lớp.', 'Không cần em thực hành gì.']] },
  { lv: 2, s: 'Kĩ năng học', sit: 'Em làm xong bài thuyết trình nhóm, muốn được góp ý.', tip: 'Xin góp ý cụ thể (điểm tốt, điểm cần sửa) và tự sửa – sản phẩm vẫn là của nhóm em.', o: [
    ['Bạn là người phản biện thẳng thắn.', 'Bạn là người khen mọi thứ đều hay.', 'Bạn là người làm slide chuyên nghiệp.'],
    ['Đây là dàn ý bài thuyết trình nhóm.', 'Nhóm em chưa làm gì cả, hết giờ rồi.', 'Nhóm em chỉ muốn được điểm cao nhất.'],
    ['Chỉ ra 2 điểm tốt, 2 điểm cần sửa.', 'Làm lại toàn bộ slide cho nhóm.', 'Viết sẵn lời thuyết trình cho em.'],
    ['Để nhóm em tự sửa và khai báo AI.', 'Đừng nói với cô là nhóm có dùng AI.', 'Sửa hết, nhóm em chỉ việc đọc thôi.']] },
  { lv: 2, s: 'GDCD', sit: 'Em cần hiểu quyền và nghĩa vụ của công dân để làm bài tập tình huống.', tip: 'AI giúp em hiểu luật bằng ví dụ – còn câu trả lời tình huống phải do em tự lập luận.', o: [
    ['Bạn là gia sư GDCD gần gũi.', 'Bạn là luật sư nói thuật ngữ khó.', 'Bạn là người soạn đáp án sẵn.'],
    ['Em đã đọc bài nhưng chưa hiểu rõ.', 'Em cần đáp án để nộp ngay trong tối nay.', 'Em chưa đọc đề bài tình huống.'],
    ['Giải thích bằng ví dụ gần gũi.', 'Trả lời luôn bài tập tình huống.', 'Chép nguyên văn điều luật ra.'],
    ['Để em tự trả lời tình huống.', 'Viết sẵn đáp án dài 1 trang.', 'Không cần em hiểu, chỉ cần chép.']] },
  /* ---------- MỨC KHÓ ---------- */
  { lv: 3, s: 'Lịch sử', sit: 'Em cần ôn chiến dịch Điện Biên Phủ cho bài kiểm tra 45 phút.', tip: 'Bối cảnh tốt nói rõ em YẾU ở đâu. Hỏi từng câu và chờ em trả lời thì em mới thật sự nhớ.', o: [
    ['Bạn là gia sư Sử, hỏi để em tự nhớ.', 'Bạn là gia sư Sử, giảng lại toàn bộ.', 'Bạn là gia sư Sử, soạn đề cương sẵn.'],
    ['Em nhớ diễn biến, hay quên mốc thời gian.', 'Em đã học rồi, giờ muốn ôn lại cho thật chắc.', 'Em sắp kiểm tra 45 phút môn Lịch sử.'],
    ['Hỏi em các mốc, sai thì gợi ý lại.', 'Lập bảng mốc thời gian để em học.', 'Hỏi em các mốc rồi đưa đáp án ngay.'],
    ['Mỗi lần 1 câu, chờ em trả lời.', 'Hỏi hết 10 câu một lượt cho nhanh.', 'Nếu em sai thì cứ bỏ qua câu đó.']] },
  { lv: 3, s: 'Lịch sử', sit: 'Em đọc trên mạng một thông tin lịch sử khác với SGK.', tip: 'AI cũng có thể sai! Câu lệnh tốt yêu cầu chỉ nguồn chính thống và để em tự đối chiếu.', o: [
    ['Bạn là người hướng dẫn kiểm chứng sử liệu.', 'Bạn là nhà sử học luôn có câu trả lời đúng.', 'Bạn là người kể chuyện lịch sử hấp dẫn.'],
    ['Đây là thông tin và nơi em đọc được.', 'Em thấy thông tin trên mạng hay hơn.', 'Em không nhớ đã đọc ở trang nào.'],
    ['Gợi ý cách đối chiếu với nguồn tin cậy.', 'Cho em biết ngay thông tin nào là đúng nhé.', 'Viết lại câu chuyện cho dễ nhớ hơn.'],
    ['Nói rõ chỗ nào AI chưa chắc chắn.', 'Trả lời chắc chắn, đừng nói “có thể”.', 'Không cần nêu nguồn, em tin bạn.']] },
  { lv: 3, s: 'Toán', sit: 'Em cần ôn dạng bài cực trị hàm số, em hay sai dấu đạo hàm.', tip: 'Biết rõ lỗi hay mắc + bài tương tự + tự làm trước = cách luyện Toán hiệu quả nhất.', o: [
    ['Bạn là gia sư Toán chuyên sửa lỗi sai.', 'Bạn là gia sư Toán giải bài thật nhanh gọn.', 'Bạn là gia sư Toán soạn tài liệu ôn.'],
    ['Em hiểu cách làm nhưng hay sai dấu.', 'Em sắp thi nên cần ôn dạng này.', 'Em thấy dạng này khó nhất chương.'],
    ['Ra 3 bài tương tự để em tự luyện.', 'Giải mẫu 3 bài để em xem cách làm.', 'Ra 3 bài kèm lời giải ở bên dưới.'],
    ['Em làm xong mới chỉ ra lỗi sai dấu.', 'Nhắc đáp số trước để em tự so sánh kết quả.', 'Giải thích hết trước khi em làm.']] },
  { lv: 3, s: 'Ngữ văn', sit: 'Em viết xong bài nghị luận xã hội về tinh thần tự học.', tip: 'Xin góp ý CÓ TIÊU CHÍ, chỉ ra vị trí cần sửa và để em tự viết lại – bài vẫn mang giọng văn của em.', o: [
    ['Bạn là giáo viên Văn chấm theo tiêu chí.', 'Bạn là giáo viên Văn viết lại bài hay.', 'Bạn là giáo viên Văn khen động viên.'],
    ['Đây là bài em tự viết, khoảng 600 chữ.', 'Đây là bài em viết cùng một bạn khác.', 'Em muốn bài đạt điểm thật cao.'],
    ['Nhận xét lập luận, dẫn chứng, diễn đạt.', 'Sửa lại các câu văn cho mượt mà, trôi chảy hơn.', 'Viết lại đoạn mở bài thật ấn tượng.'],
    ['Chỉ ra vị trí cần sửa, em tự sửa.', 'Sửa trực tiếp vào bài cho nhanh.', 'Chỉ khen để em có động lực viết.']] },
  { lv: 3, s: 'Tiếng Anh', sit: 'Em chuẩn bị bài viết email tiếng Anh cho kì thi.', tip: 'Giữ lại bài của em, chỉ ra lỗi theo nhóm và để em tự sửa – học được nhiều hơn là có bản sửa sẵn.', o: [
    ['Bạn là giám khảo chấm bài viết tiếng Anh.', 'Bạn là người viết email tiếng Anh mẫu chuẩn.', 'Bạn là công cụ sửa ngữ pháp tự động.'],
    ['Đây là email em viết theo đề thi mẫu.', 'Đây là đề thi mẫu, em cần một bài viết mẫu.', 'Em muốn email nghe thật “Tây”.'],
    ['Chỉ lỗi theo nhóm: ngữ pháp, từ, bố cục.', 'Viết lại email hoàn chỉnh, thật chuẩn cho em.', 'Sửa hết lỗi và in bản đã sửa.'],
    ['Đừng viết lại, để em tự sửa từng lỗi.', 'Sửa luôn những câu em viết sai cho nhanh.', 'Gợi ý câu thay thế cho mọi câu.']] },
  { lv: 3, s: 'Địa lí', sit: 'Em phải viết đoạn nhận xét biểu đồ cơ cấu kinh tế.', tip: 'Khung các bước giúp em tự viết; tự tính số liệu giúp em hiểu biểu đồ thật sự.', o: [
    ['Bạn là gia sư Địa lí dạy cách lập luận.', 'Bạn là gia sư Địa lí viết bài nhận xét mẫu.', 'Bạn là gia sư Địa lí đọc số liệu hộ.'],
    ['Em đã tính tỉ trọng các ngành từ bảng.', 'Em có bảng số liệu nhưng chưa tính.', 'Em cần bài nhận xét nộp ngay tối nay.'],
    ['Đưa khung 4 bước để em tự nhận xét.', 'Viết đoạn nhận xét mẫu để em tham khảo.', 'Tính sẵn tỉ trọng các ngành giúp em.'],
    ['Đọc bài em viết rồi chỉ chỗ thiếu.', 'Viết sẵn câu kết luận thật hay cho em.', 'Không cần đọc lại bài em viết.']] },
  { lv: 3, s: 'Sinh học', sit: 'Em muốn ôn chương Di truyền nhưng lí thuyết quá nhiều.', tip: 'Sơ đồ do EM vẽ + AI chỉ chỗ thiếu = nhớ lâu. Sơ đồ AI vẽ sẵn chỉ là của AI.', o: [
    ['Bạn là gia sư Sinh giúp em hệ thống bài.', 'Bạn là gia sư Sinh tóm tắt thật đầy đủ.', 'Bạn là gia sư Sinh đọc chậm cho em chép.'],
    ['Em đã tự vẽ sơ đồ tư duy chương này.', 'Em có tài liệu tóm tắt của lớp khác.', 'Em định học thuộc lòng cả chương.'],
    ['Nhận xét sơ đồ của em còn thiếu gì.', 'Vẽ lại sơ đồ tư duy đẹp hơn cho em.', 'Tóm tắt chương thành 20 gạch đầu dòng.'],
    ['Hỏi em 3 câu ở phần em còn thiếu.', 'Đưa luôn ý còn thiếu để em chép vào.', 'Không cần hỏi lại, em tự xem.']] },
  { lv: 3, s: 'Hóa học', sit: 'Em làm bài tập hữu cơ, không chắc mình viết đồng phân đủ chưa.', tip: 'Gợi ý CÁCH kiểm tra (theo mạch carbon) giúp em tự tìm ra đồng phân còn thiếu.', o: [
    ['Bạn là gia sư Hóa giúp em tự soát bài.', 'Bạn là gia sư Hóa liệt kê đáp án đủ.', 'Bạn là gia sư Hóa giải bài mẫu nhanh.'],
    ['Em đã viết được 4 đồng phân.', 'Em chưa biết đồng phân là gì cả.', 'Em cần đủ đáp án để nộp ngay.'],
    ['Gợi ý cách xét mạch carbon để soát lại.', 'Liệt kê giúp em đủ tất cả các đồng phân.', 'Nói số đồng phân đúng là bao nhiêu.'],
    ['Để em tự tìm đồng phân còn thiếu.', 'Vẽ luôn đồng phân em còn thiếu.', 'Chỉ cần xác nhận đủ hay chưa đủ.']] },
  { lv: 3, s: 'Vật lí', sit: 'Em làm thí nghiệm đo gia tốc, kết quả lệch nhiều so với lí thuyết.', tip: 'Nhà khoa học nhí tự phân tích sai số – AI chỉ gợi ý nguyên nhân, không sửa số liệu.', o: [
    ['Bạn là người hướng dẫn thí nghiệm.', 'Bạn là người viết báo cáo thí nghiệm hộ.', 'Bạn là người chỉnh số liệu cho đẹp.'],
    ['Đây là bảng số liệu em đo được.', 'Kết quả của em xấu quá, em ngại.', 'Em cần báo cáo đạt điểm tối đa.'],
    ['Gợi ý các nguyên nhân gây sai số.', 'Sửa số liệu cho gần lí thuyết.', 'Viết sẵn phần nhận xét kết quả.'],
    ['Để em tự viết nhận xét và đề xuất.', 'Làm sao để cô không nhận ra lệch.', 'Viết thật dài cho báo cáo dày.']] },
  { lv: 3, s: 'An toàn mạng', sit: 'Em thấy một video có vẻ là người nổi tiếng nói điều rất lạ.', tip: 'Deepfake ngày càng giống thật. Câu lệnh tốt nhờ AI chỉ DẤU HIỆU và nguồn đối chiếu – không tin ngay, không chia sẻ vội.', o: [
    ['Bạn là người hướng dẫn nhận biết deepfake.', 'Bạn là người phân xử thật giả giúp em ngay.', 'Bạn là người bình luận tin nóng.'],
    ['Đây là mô tả video, em chưa chia sẻ.', 'Video này đang lan truyền rất mạnh.', 'Em đã chia sẻ video vào nhóm lớp.'],
    ['Chỉ em các dấu hiệu video bị làm giả.', 'Khẳng định giúp em video thật hay giả.', 'Viết bình luận phản bác người trong video.'],
    ['Gợi ý nguồn chính thống để đối chiếu.', 'Trả lời chắc chắn, đừng bảo em tự xem.', 'Khuyên em chia sẻ để mọi người cảnh giác.']] },
  { lv: 3, s: 'Kĩ năng học', sit: 'Em dùng AI để tìm ý cho bài dự án, cần khai báo khi nộp.', tip: 'Khai báo trung thực: dùng AI ở phần nào, công cụ gì – đó là quy định mới khi học sinh dùng AI.', o: [
    ['Bạn là người hướng dẫn liêm chính học tập.', 'Bạn là người giúp giấu việc dùng AI trong bài.', 'Bạn là người viết dự án hộ em.'],
    ['Em dùng AI gợi ý ý tưởng, tự làm phần còn lại.', 'Em đã dùng AI viết gần hết các phần của bài dự án.', 'Em không nhớ đã dùng AI ở phần nào.'],
    ['Gợi ý mẫu khai báo AI trung thực.', 'Sửa lời văn để không ai biết dùng AI.', 'Viết nốt phần dự án còn lại.'],
    ['Ghi rõ công cụ và phần AI hỗ trợ.', 'Chỉ ghi chung chung “có tham khảo”.', 'Không cần khai báo nếu AI chỉ giúp ít.']] },
  { lv: 3, s: 'Tin học', sit: 'Em nhờ AI viết code, chương trình chạy được nhưng em không hiểu.', tip: 'Code chạy được mà em không hiểu thì chưa phải của em. Nhờ AI giải thích từng dòng và tự viết lại.', o: [
    ['Bạn là gia sư giải thích code từng dòng.', 'Bạn là trợ lí viết thêm tính năng mới cho em.', 'Bạn là máy tối ưu code tự động.'],
    ['Đây là code chạy được nhưng em chưa hiểu.', 'Code chạy được rồi, em chỉ cần nộp cho kịp thôi.', 'Em muốn code ngắn và đẹp hơn.'],
    ['Giải thích từng dòng bằng lời dễ hiểu.', 'Viết thêm chức năng cho bài trông đẹp hơn hẳn.', 'Rút gọn code để em nộp cho xịn.'],
    ['Sau đó cho em tự viết lại 1 đoạn.', 'Không cần em viết lại gì cả.', 'Thêm chú thích để cô tưởng em tự viết.']] },
];

const Shield = {
  c: null, g: null, W: 800, H: 440, items: [], fx: [], run: false, paused: false, score: 0, hearts: 3, time: 60, t0: 0, spawn: 0, combo: 0, last: 0,
  mode: 1,
  init() {
    this.c = $('shieldCanvas'); if (!this.c) return; this.g = this.c.getContext('2d');
    const hit = (e) => { if (!this.run) return; const r = this.c.getBoundingClientRect(); const pt = e.touches ? e.touches[0] : e; this.tap((pt.clientX - r.left) * (this.W / r.width), (pt.clientY - r.top) * (this.H / r.height)); e.preventDefault(); };
    this.c.addEventListener('pointerdown', hit);
    $('shStart').addEventListener('click', () => this.start());
    document.querySelectorAll('#shOverlay [data-lv]').forEach((bt) => bt.addEventListener('click', () => { this.mode = Number(bt.dataset.lv); this.start(); }));
    this.resize(); this.drawIdle(); const b = store.get('shieldBest', 0); $('shBest').textContent = b ? `🏅 Kỷ lục của bạn: ${b} điểm` : '';
  },
  resize() { if (!this.c) return; const w = Math.max(320, this.c.parentElement.clientWidth); this.W = w; this.H = Math.round(w < 600 ? Math.min(640, w * 1.65) : Math.min(600, w * .52)); this.fs = w < 600 ? 17 : 21; const dpr = Math.min(2, devicePixelRatio || 1); this.c.width = this.W * dpr; this.c.height = this.H * dpr; this.g.setTransform(dpr, 0, 0, dpr, 0, 0); if (!this.run) this.drawIdle(); else if (this.paused) { this.paused = false; this.last = performance.now(); requestAnimationFrame((t) => this.loop(t)); } },
  pause() { if (this.run) this.paused = true; },
  start() {
    this.mult = [1, 1, 1.5, 2][this.mode]; this.pool = SH_BANK.filter((x) => x[2] <= this.mode); this.items = []; this.fx = []; this.score = 0; this.hearts = 3; this.time = 60; this.spawn = 0; this.combo = 0; this.run = true; this.paused = false; this.speed = 1; $('shStart').hidden = true;
    $('shOverlay').hidden = true; this.last = performance.now(); this.hud(); requestAnimationFrame((t) => this.loop(t));
  },
  hud() { $('shScore').textContent = `⭐ ${this.score}` + (this.combo >= 3 ? ` · x${Math.min(4, 1 + Math.floor(this.combo / 3))}` : ''); $('shTime').textContent = `⏱ ${Math.ceil(this.time)}`; $('shHearts').textContent = '❤️'.repeat(Math.max(0, this.hearts)) + '🤍'.repeat(Math.max(0, 3 - this.hearts)); },
  add() {
    const red = Math.random() < .55; let cand = this.pool.filter((x) => Boolean(x[1]) === red); if (this.mode === 3 && Math.random() < .6) cand = cand.filter((x) => x[2] >= 2); const pick = pickOne(cand); const txt = pick[0]; this.g.font = `700 ${this.fs || 21}px Quicksand, system-ui, sans-serif`;
    const w = this.g.measureText(txt).width + 30; const hh = (this.fs || 21) + 24; const x = 20 + Math.random() * (this.W - w - 40);
    this.items.push({ red, txt, why: pick[3], x, y: -40, w, h: hh, vy: (50 + Math.random() * 30) * this.speed * [1, .8, 1, 1.3][this.mode], wob: Math.random() * 6 });
  },
  tap(x, y) {
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i]; if (x >= it.x - 6 && x <= it.x + it.w + 6 && y >= it.y - 8 && y <= it.y + it.h + 8) {
        this.items.splice(i, 1);
        if (it.red) { this.combo++; const mult = Math.min(4, 1 + Math.floor(this.combo / 3)); this.score += 10 * mult; this.burst(it, '#22c39a', `+${10 * mult}`); }
        else { this.combo = 0; this.hearts--; this.burst(it, '#ff6b9a', 'Chặn nhầm!'); this.shake = 10; toast(`🙆 “${it.txt.replace(/^\S+\s/, '')}” hỏi AI được mà! ${it.why}`); }
        this.hud(); if (this.hearts <= 0) this.end(); return;
      }
    }
  },
  burst(it, col, label) { for (let k = 0; k < 16; k++) { const a = Math.random() * 6.28; this.fx.push({ x: it.x + it.w / 2, y: it.y + it.h / 2, vx: Math.cos(a) * 3.5, vy: Math.sin(a) * 3.5, life: 34, col }); } this.fx.push({ txt: label, x: it.x + it.w / 2, y: it.y, life: 50, col }); },
  rr(x, y, w, h, r) { const g = this.g; g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); },
  bg(t) {
    const g = this.g; const gr = g.createLinearGradient(0, 0, 0, this.H); gr.addColorStop(0, '#2b1f6e'); gr.addColorStop(1, '#5b3fd6'); g.fillStyle = gr; g.fillRect(0, 0, this.W, this.H);
    for (let i = 0; i < 40; i++) { const x = (i * 97) % this.W, y = (i * 53 + (t || 0) * .01 * (1 + i % 3)) % this.H; g.globalAlpha = .25 + (i % 4) * .12; g.fillStyle = '#fff'; g.fillRect(x, y, 2, 2); } g.globalAlpha = 1;
    // robot AI + lá chắn
    const bx = this.W / 2, by = this.H - 52; g.fillStyle = '#7b5cff55'; g.beginPath(); g.ellipse(bx, by + 30, 150, 26, 0, 0, 6.28); g.fill();
    g.strokeStyle = '#7fe3ff'; g.lineWidth = 4; g.globalAlpha = .55 + Math.sin((t || 0) / 300) * .2; g.beginPath(); g.arc(bx, by + 10, 110, Math.PI * 1.08, Math.PI * 1.92); g.stroke(); g.globalAlpha = 1;
    g.font = '64px system-ui, "Apple Color Emoji", "Segoe UI Emoji", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('🤖', bx, by);
  },
  drawIdle() { if (!this.g) return; this.bg(0); },
  loop(t) {
    if (!this.run || this.paused) return; const dt = Math.min(.05, (t - this.last) / 1000); this.last = t; const g = this.g;
    this.time -= dt; this.speed = 1 + (60 - this.time) / 45; this.spawn -= dt; if (this.spawn <= 0) { this.add(); this.spawn = Math.max(.42, 1.05 - (60 - this.time) / 80); }
    g.save(); if (this.shake > 0) { g.translate((Math.random() - .5) * this.shake, (Math.random() - .5) * this.shake); this.shake *= .85; if (this.shake < .5) this.shake = 0; }
    this.bg(t); g.textAlign = 'left'; g.textBaseline = 'middle';
    for (let i = this.items.length - 1; i >= 0; i--) {
      const it = this.items[i]; it.y += it.vy * dt; const wx = Math.sin(t / 400 + it.wob) * 3;
      const tint = this.mode === 1; this.rr(it.x + wx, it.y, it.w, it.h, 16); g.fillStyle = tint ? (it.red ? '#fff0f4' : '#effff8') : '#ffffff'; g.fill(); g.lineWidth = 4; g.strokeStyle = tint ? (it.red ? '#ff4f7f' : '#22c39a') : '#9a7bff'; g.stroke();
      g.fillStyle = tint ? (it.red ? '#c2185b' : '#0e7a5f') : '#3b2a8f'; g.font = `700 ${this.fs || 21}px Quicksand, system-ui, sans-serif`; g.fillText(it.txt, it.x + wx + 17, it.y + it.h / 2 + 1);
      if (it.y + it.h > this.H - 90) {
        this.items.splice(i, 1);
        if (it.red) { this.hearts--; this.combo = 0; this.shake = 14; this.burst(it, '#ff4f7f', 'Lộ dữ liệu!'); toast(`⚠️ Lọt “${it.txt.replace(/^\S+\s/, '')}”! ${it.why}`); }
        else { this.score += 5; this.burst(it, '#7fe3ff', '+5'); }
        this.hud(); if (this.hearts <= 0) { g.restore(); this.end(); return; }
      }
    }
    this.fx = this.fx.filter((f) => f.life > 0);
    this.fx.forEach((f) => { f.life--; if (f.txt) { f.y -= 1.2; g.globalAlpha = f.life / 50; g.fillStyle = f.col; g.font = '800 24px Quicksand, system-ui'; g.textAlign = 'center'; g.fillText(f.txt, f.x, f.y); g.textAlign = 'left'; } else { f.x += f.vx; f.y += f.vy; g.globalAlpha = f.life / 34; g.fillStyle = f.col; g.beginPath(); g.arc(f.x, f.y, 4, 0, 6.28); g.fill(); } g.globalAlpha = 1; });
    g.restore();
    if (Math.ceil(this.time) !== Number($('shTime').textContent.replace(/\D/g, ''))) this.hud();
    if (this.time <= 0) { this.end(); return; }
    requestAnimationFrame((tt) => this.loop(tt));
  },
  end() {
    this.run = false; const sc = this.score; const best = Math.max(sc, store.get('shieldBest', 0)); const isBest = sc > store.get('shieldBest', 0) && sc > 0; store.set('shieldBest', best);
    const xp = Math.min(160, Math.round(sc / 5 * this.mult)); const p = player(); p.games++; p.shieldBest = Math.max(p.shieldBest, sc); savePlayer(p);
    bumpDay('shieldRuns', 1); bumpDay('shieldTop', sc, 'max'); gainXP(xp, 'shield');
    $('shOvTitle').textContent = this.hearts <= 0 ? '💥 Hết lượt bảo vệ!' : '⏰ Hết giờ!';
    $('shOvText').innerHTML = `Mức <b>${['', 'Dễ 🌱', 'Vừa 🔥', 'Khó 💀'][this.mode]}</b>: bạn được <b>${sc} điểm</b> → nhận <b>+${xp} XP</b>.<br>${isBest ? '🏅 KỶ LỤC MỚI! ' : ''}${sc >= 200 ? 'Lá chắn thép! Dữ liệu của bạn an toàn tuyệt đối 🛡️' : sc >= 100 ? 'Giỏi lắm! Bạn đã biết thông tin nào phải giữ kín 👏' : 'Nhớ nhé: mật khẩu, OTP, số CCCD, số tài khoản… tuyệt đối không đưa cho AI!'}`;
    $('shStart').textContent = `↻ Chơi lại mức ${['', 'Dễ', 'Vừa', 'Khó'][this.mode]}`; $('shStart').hidden = false; $('shHow').hidden = true; $('shBest').textContent = `🏅 Kỷ lục của bạn: ${best} điểm`; $('shOverlay').hidden = false; if (isBest || sc >= 150) confetti(150);
  },
};

/* =====================================================================
   GAME 3D – THÁP CÂU LỆNH (Three.js, có phương án dự phòng CSS 3D)
   ===================================================================== */
const TW_LAYERS = ['VAI TRÒ', 'BỐI CẢNH', 'NHIỆM VỤ', 'GIỚI HẠN'];
const TW_COLORS = [0x7b5cff, 0x3fa9ff, 0x22c39a, 0xffb21e];
const Tower = {
  lv: 1, mult: 1, ready: false, loading: false, three: false, scene: null, cam: null, ren: null, group: null, blocks: [], cur: null, step: 0, stars: 3, raf: 0, awake: false, order: [], built: 0,
  init() {
    this.awake = true; if (this.ready) { this.resize(); this.animate(); return; } if (this.loading) return; this.loading = true;
    const go = () => { this.ready = true; this.setup(); };
    if (window.THREE) { this.three = true; go(); return; }
    const s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    s.onload = () => { this.three = Boolean(window.THREE); go(); }; s.onerror = () => { this.three = false; go(); };
    document.head.appendChild(s); setTimeout(() => { if (!this.ready) { this.three = false; go(); } }, 7000);
  },
  sleep() { this.awake = false; cancelAnimationFrame(this.raf); },
  setup() {
    const box = $('towerCanvas'); box.innerHTML = '';
    if (!this.three) { box.classList.add('css3d'); this.css = el('div', 'css-tower'); box.appendChild(this.css); return; }
    const T = window.THREE; const w = box.clientWidth, h = box.clientHeight;
    this.scene = new T.Scene(); this.scene.fog = new T.Fog(0x241a5c, 14, 30);
    this.cam = new T.PerspectiveCamera(45, w / h, .1, 100); this.cam.position.set(7, 6, 9); this.cam.lookAt(0, 2, 0);
    this.ren = new T.WebGLRenderer({ antialias: true, alpha: true }); this.ren.setPixelRatio(Math.min(2, devicePixelRatio || 1)); this.ren.setSize(w, h); box.appendChild(this.ren.domElement);
    this.scene.add(new T.AmbientLight(0xffffff, .6)); const dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(5, 10, 6); this.scene.add(dl); const pl = new T.PointLight(0xff6b9a, .8, 20); pl.position.set(-5, 4, -3); this.scene.add(pl);
    this.group = new T.Group(); this.scene.add(this.group);
    const base = new T.Mesh(new T.CylinderGeometry(3.4, 3.8, .5, 48), new T.MeshStandardMaterial({ color: 0xffffff, roughness: .4, metalness: .1 })); base.position.y = -.25; this.group.add(base);
    const ring = new T.Mesh(new T.TorusGeometry(3.6, .07, 12, 80), new T.MeshBasicMaterial({ color: 0x7fe3ff })); ring.rotation.x = Math.PI / 2; ring.position.y = .02; this.group.add(ring);
    const sg = new T.BufferGeometry(); const pts = []; for (let i = 0; i < 400; i++) pts.push((Math.random() - .5) * 40, Math.random() * 20 - 2, (Math.random() - .5) * 40); sg.setAttribute('position', new T.Float32BufferAttribute(pts, 3));
    this.stars3 = new T.Points(sg, new T.PointsMaterial({ color: 0xffffff, size: .08, transparent: true, opacity: .8 })); this.scene.add(this.stars3);
    window.addEventListener('resize', () => this.resize());
    this.animate();
  },
  resize() { if (!this.ren) return; const box = $('towerCanvas'); const w = box.clientWidth, h = box.clientHeight; this.ren.setSize(w, h); this.cam.aspect = w / h; this.cam.updateProjectionMatrix(); },
  label(text, color) {
    const T = window.THREE; const c = document.createElement('canvas'); c.width = 512; c.height = 128; const g = c.getContext('2d');
    g.fillStyle = '#' + color.toString(16).padStart(6, '0'); g.fillRect(0, 0, 512, 128); g.fillStyle = '#fff'; g.font = '800 54px Quicksand, system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 256, 68);
    const tx = new T.CanvasTexture(c); return tx;
  },
  addBlock(i, wrong) {
    if (!this.three) { const b = el('div', 'css-block' + (wrong ? ' wrong' : ''), wrong ? '✕' : TW_LAYERS[i]); b.style.setProperty('--c', wrong ? '#ff4f7f' : '#' + TW_COLORS[i].toString(16).padStart(6, '0')); b.style.setProperty('--i', this.blocks.length); if (wrong) { this.css.appendChild(b); setTimeout(() => b.remove(), 900); } else { this.css.appendChild(b); this.blocks.push(b); } return; }
    const T = window.THREE; const col = wrong ? 0xff4f7f : TW_COLORS[i]; const side = new T.MeshStandardMaterial({ color: col, roughness: .35, metalness: .15 });
    const face = new T.MeshStandardMaterial({ map: this.label(wrong ? '✕ CHƯA ĐÚNG' : TW_LAYERS[i], col), roughness: .4 });
    const m = new T.Mesh(new T.BoxGeometry(3.6, .8, 2.2), [side, side, side, side, face, face]);
    const target = .4 + this.blocks.length * .86; m.position.set(0, target + 7, 0); m.rotation.y = (Math.random() - .5) * .6;
    m.userData = { target, wrong, vy: 0, life: 0 }; this.group.add(m); if (!wrong) this.blocks.push(m); else this.fallers = (this.fallers || []).concat(m);
  },
  clear() { const old = this.blocks; this.blocks = []; if (this.three) { old.forEach((b) => { b.userData.fly = true; b.userData.vx = (Math.random() - .5) * .3; }); this.flyers = (this.flyers || []).concat(old); setTimeout(() => { old.forEach((b) => this.group.remove(b)); this.flyers = (this.flyers || []).filter((b) => !old.includes(b)); }, 1200); } else if (this.css) this.css.innerHTML = ''; },
  animate() {
    cancelAnimationFrame(this.raf); if (!this.awake || !this.three) return;
    const tick = () => {
      if (!this.awake) return; this.group.rotation.y += REDUCED ? 0 : .004; if (this.stars3) this.stars3.rotation.y -= .0006;
      (this.flyers || []).concat(this.blocks).forEach((b) => { const u = b.userData; if (u.fly) { b.position.y += .25; b.position.x += u.vx; b.rotation.z += .05; return; } if (b.position.y > u.target) { u.vy += .018; b.position.y = Math.max(u.target, b.position.y - u.vy); if (b.position.y === u.target) { u.vy = 0; b.scale.set(1.08, .86, 1.08); } } else { b.scale.lerp(new window.THREE.Vector3(1, 1, 1), .15); } });
      (this.fallers || []).forEach((b) => { const u = b.userData; u.life++; if (u.life < 30) { b.position.y -= (b.position.y - (u.target + .3)) * .2; } else { b.position.x += .12; b.position.y -= .18; b.rotation.z -= .08; } if (u.life > 80) { this.group.remove(b); u.dead = true; } });
      this.fallers = (this.fallers || []).filter((b) => !b.userData.dead);
      const top = .4 + this.blocks.length * .86; this.cam.position.y += ((5 + top * .7) - this.cam.position.y) * .05; this.cam.lookAt(0, 1.2 + top * .45, 0);
      this.ren.render(this.scene, this.cam); this.raf = requestAnimationFrame(tick);
    };
    tick();
  },
  begin(lv) { this.lv = lv; this.mult = [1.5, 1, 1.5, 2][lv]; this.order = []; $('twIntro').hidden = true; $('twPlay').hidden = false; $('twLv').textContent = ['🎲 Trộn', '🌱 Dễ', '🔥 Vừa', '💀 Khó'][lv]; if (!this.ready) this.init(); const w = () => { if (this.ready) this.next(); else setTimeout(w, 200); }; w(); },
  next() {
    const pool = TW_BANK.map((t, i) => [t, i]).filter(([t]) => !this.lv || t.lv === this.lv).map(([, i]) => i);
    if (!this.order.length) this.order = shuffle(pool);
    this.cur = TW_BANK[this.order.shift()]; this.step = 0; this.stars = 3; this.chosen = []; this.clear();
    $('twDone').hidden = true; $('twPrompt').hidden = true; $('twSubject').textContent = '📚 ' + this.cur.s.toUpperCase() + ' · ' + ['', 'DỄ', 'VỪA', 'KHÓ'][this.cur.lv]; $('twSituation').textContent = this.cur.sit; this.renderStep();
  },
  renderStep() {
    $('twStars').textContent = '⭐'.repeat(this.stars) + '☆'.repeat(3 - this.stars); $('twCount').textContent = `🏗️ Tháp: ${player().towers}`;
    const st = $('twSteps'); st.innerHTML = ''; TW_LAYERS.forEach((l, i) => { const s = el('span', 'g3-step' + (i < this.step ? ' ok' : i === this.step ? ' now' : ''), (i < this.step ? '✓ ' : '') + l); s.style.setProperty('--c', '#' + TW_COLORS[i].toString(16).padStart(6, '0')); st.appendChild(s); });
    const box = $('twOpts'); box.innerHTML = '';
    if (this.step >= 4) { $('twAsk').textContent = ''; return; }
    $('twAsk').innerHTML = `Khối ${this.step + 1}/4 – chọn <b>${TW_LAYERS[this.step]}</b> phù hợp:`;
    const opts = this.cur.o[this.step].map((t, k) => ({ t, ok: k === 0 })); shuffle(opts).forEach((o) => {
      const b = el('button', 'g3-opt', o.t); b.type = 'button'; b.style.setProperty('--c', '#' + TW_COLORS[this.step].toString(16).padStart(6, '0'));
      b.addEventListener('click', () => this.choose(o, b)); box.appendChild(b);
    });
  },
  choose(o, btn) {
    if (o.ok) {
      this.addBlock(this.step); this.chosen.push(o.t); bumpDay('blocks', 1); gainXP(Math.round(15 * this.mult), 'tower'); this.step++; this.renderStep(); if (this.step >= 4) this.finish();
    } else {
      this.addBlock(this.step, true); btn.disabled = true; btn.classList.add('bad'); this.stars = Math.max(0, this.stars - 1); $('twStars').textContent = '⭐'.repeat(this.stars) + '☆'.repeat(3 - this.stars);
      toast(['🟪 Vai trò tốt: AI là người HƯỚNG DẪN, không phải người làm hộ hay phán xử thay em.', '🟦 Bối cảnh tốt: nói rõ em ĐÃ LÀM ĐƯỢC GÌ và đang vướng ở đâu.', '🟩 Nhiệm vụ tốt: xin GỢI Ý, giải thích, câu hỏi – không xin đáp án hay bài làm sẵn.', '🟨 Giới hạn tốt: đặt luật để EM tự làm, tự kiểm chứng, trung thực.'][this.step]);
    }
  },
  finish() {
    const p = player(); p.towers++; p.games++; savePlayer(p); bumpDay('towers', 1); const bonus = Math.round((30 + this.stars * 5) * this.mult); gainXP(bonus, 'tower');
    const pr = $('twPrompt'); pr.hidden = false; pr.innerHTML = ''; pr.appendChild(el('b', '', '🎉 Câu lệnh hoàn chỉnh của bạn:')); const full = this.chosen.join(' '); pr.appendChild(el('p', '', full)); pr.appendChild(el('div', 'g3-tip', '💡 ' + (this.cur.tip || 'Câu lệnh tốt = AI gợi ý, em tự làm. Đủ 4 khối giúp AI hiểu đúng điều em cần.')));
    const cp = el('button', 'mini', '📋 Chép câu lệnh'); cp.type = 'button'; cp.addEventListener('click', async () => { cp.textContent = (await copyText(full)) ? '✓ Đã chép' : 'Chép thủ công'; });
    const nx = el('button', 'btn btn-primary btn-small', 'Xây tháp mới →'); nx.type = 'button'; nx.addEventListener('click', () => this.next()); pr.append(cp, nx);
    const d = $('twDone'); d.hidden = false; d.textContent = this.stars === 3 ? '🏆 HOÀN HẢO!' : this.stars === 2 ? '🌟 TUYỆT VỜI!' : '👍 HOÀN THÀNH!';
    confetti(160); toast(`${pickOne(PRAISE)} +${bonus} XP`); $('twCount').textContent = `🏗️ Tháp: ${p.towers}`;
  },
};

/* =====================================================================
   HIỆU ỨNG ĐỘNG CHO TRANG
   ===================================================================== */
const REVEAL_SEL = '.section-heading, .feature-card, .article-card, .doc-card, .poster-card, .pcard, .vote-card, .news-card, .member-card, .process-card, .hb-card, .player-card, .game-tabs, .quiz-card, .garden-card, .day-item, .join-copy, .qr-card, .journey-layout, .mission-banner';
let revObs = null;
function revealScan() {
  if (REDUCED || !('IntersectionObserver' in window)) return;
  if (!revObs) revObs = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); revObs.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll(REVEAL_SEL).forEach((n) => { if (n.classList.contains('rv')) return; const sib = n.parentElement ? [...n.parentElement.children].indexOf(n) : 0; n.classList.add('rv'); n.style.setProperty('--d', (Math.min(sib, 6) * 70) + 'ms'); const r = n.getBoundingClientRect(); if (r.top < innerHeight * .95 && r.bottom > 0) requestAnimationFrame(() => n.classList.add('in')); else revObs.observe(n); });
}
function countUp() {
  document.querySelectorAll('.hero-stats strong').forEach((s) => { const end = parseInt(s.textContent, 10); if (!end || REDUCED) return; let v = 0; const pad = s.textContent.length; const st = performance.now(); const f = (t) => { v = Math.round(Math.min(1, (t - st) / 1200) * end); s.textContent = String(v).padStart(pad, '0'); if (v < end) requestAnimationFrame(f); }; requestAnimationFrame(f); });
}
function heroSparkles() {
  const h = document.querySelector('.hero'); if (!h || REDUCED || h.querySelector('.sparkle')) return;
  for (let i = 0; i < 14; i++) { const s = el('span', 'sparkle', pickOne(['✦', '✧', '⋆', '✦'])); s.style.left = (5 + Math.random() * 90) + '%'; s.style.top = (8 + Math.random() * 84) + '%'; s.style.setProperty('--dl', (Math.random() * 4).toFixed(2) + 's'); s.style.setProperty('--sz', (10 + Math.random() * 16) + 'px'); h.appendChild(s); }
}
function tiltCards() {
  if (REDUCED || !window.matchMedia('(hover:hover)').matches) return;
  document.addEventListener('pointermove', (e) => { const c = e.target.closest && e.target.closest('.article-card, .doc-card, .poster-card, .vote-card, .feature-card'); document.querySelectorAll('.tilt-on').forEach((x) => { if (x !== c) { x.classList.remove('tilt-on'); x.style.transform = ''; } }); if (!c) return; const r = c.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; c.classList.add('tilt-on'); c.style.transform = `perspective(800px) rotateX(${(-y * 6).toFixed(2)}deg) rotateY(${(x * 8).toFixed(2)}deg) translateY(-6px)`; });
}

/* ---------- Khởi động sân chơi ---------- */
function initArcade() {
  document.querySelectorAll('.gtab').forEach((b) => b.addEventListener('click', () => showGame(b.dataset.g)));
  $('pcCopy').addEventListener('click', async () => { const c = $('pcCode').textContent; if (!/^MAM/.test(c)) return; $('pcCopy').textContent = (await copyText(c)) ? '✓' : '!'; setTimeout(() => { $('pcCopy').textContent = '📋'; }, 1500); });
  Shield.init(); renderPlayer(); checkMissions();
  document.querySelectorAll('#twIntro [data-tw]').forEach((bt) => bt.addEventListener('click', () => Tower.begin(Number(bt.dataset.tw))));
  $('twChange').addEventListener('click', () => { $('twIntro').hidden = false; $('twPlay').hidden = true; });
  window.addEventListener('resize', () => { if (!$('shieldCanvas').closest('.game-panel').hidden) Shield.resize(); });
  heroSparkles(); countUp(); tiltCards(); revealScan(); setTimeout(revealScan, 800);
  let mt = 0; new MutationObserver(() => { clearTimeout(mt); mt = setTimeout(revealScan, 250); }).observe(document.querySelector('main') || document.body, { childList: true, subtree: true });
}
initArcade();


/* ===== KHO NỘI DUNG 5 GAME MỚI – chủ đề: AI tạo sinh & năng lực tự học ===== */
/* Đấu trường Đúng – Sai: [nhận định, đúng?, giải thích] */
const TF_BANK = [
  ['AI tạo sinh có thể đưa ra câu trả lời sai nhưng nghe rất tự tin.', 1, 'Đúng. Hiện tượng này gọi là “ảo giác AI” – AI bịa ra thông tin trông rất hợp lí.'],
  ['Câu trả lời của AI luôn đúng vì AI đã đọc rất nhiều tài liệu.', 0, 'Sai. AI học từ dữ liệu có thể cũ hoặc sai, nên vẫn mắc lỗi. Luôn kiểm chứng với SGK.'],
  ['Năng lực tự học gồm cả việc tự lập kế hoạch học tập.', 1, 'Đúng. Tự lập kế hoạch là bước đầu tiên của năng lực tự học.'],
  ['Tự học nghĩa là học một mình, không bao giờ hỏi ai.', 0, 'Sai. Người tự học giỏi biết chủ động hỏi thầy cô, bạn bè và công cụ khi cần.'],
  ['Nên tự suy nghĩ khoảng 15 phút trước khi hỏi AI.', 1, 'Đúng. “Tự nghĩ trước – Hỏi AI sau” giúp não làm việc và nhớ bài lâu hơn.'],
  ['Chép nguyên văn bài AI viết rồi nộp là cách tự học hiệu quả.', 0, 'Sai. Đó là để AI học hộ. Bạn không rèn được kĩ năng và còn thiếu trung thực.'],
  ['Khi bài làm có dùng AI, học sinh nên khai báo đã dùng AI ở phần nào.', 1, 'Đúng. Khai báo trung thực là yêu cầu khi dùng AI trong học tập.'],
  ['Nhờ AI ra câu hỏi để tự kiểm tra là cách dùng AI tốt.', 1, 'Đúng. Tự kiểm tra giúp phát hiện chỗ chưa hiểu – một kĩ năng tự học quan trọng.'],
  ['Mật khẩu và mã OTP có thể gửi cho chatbot nếu cần hỗ trợ.', 0, 'Sai. Không bao giờ gửi mật khẩu, OTP cho bất kì ai, kể cả AI.'],
  ['Câu lệnh càng rõ bối cảnh thì AI càng hỗ trợ đúng điều mình cần.', 1, 'Đúng. Cho AI biết môn, phần đã làm và chỗ đang bí thì AI gợi ý sát hơn.'],
  ['Học sinh giỏi thì không cần kiểm chứng thông tin AI đưa ra.', 0, 'Sai. Ai cũng cần kiểm chứng, vì lỗi nằm ở AI chứ không phải ở người hỏi.'],
  ['Dùng AI nhiều hơn chắc chắn giúp học sinh học giỏi hơn.', 0, 'Sai. Kết quả phụ thuộc vào CÁCH dùng: dùng để hiểu bài thì tiến bộ, dùng để chép thì đi lùi.'],
  ['Tự đánh giá sau mỗi buổi học là một biểu hiện của năng lực tự học.', 1, 'Đúng. Biết mình đã hiểu gì, còn hổng gì giúp điều chỉnh cách học.'],
  ['Deepfake là video hoặc giọng nói giả được tạo bằng AI.', 1, 'Đúng. Deepfake có thể giả khuôn mặt, giọng nói người thật – cần cảnh giác.'],
  ['Ảnh do AI tạo luôn dễ nhận ra bằng mắt thường.', 0, 'Sai. Ảnh AI ngày càng giống thật; cần xem nguồn gốc và kiểm tra thêm.'],
  ['AI có thể giải thích một khái niệm khó bằng ví dụ đời thường.', 1, 'Đúng. Đây là một cách dùng AI rất hữu ích để hiểu bài.'],
  ['Nếu AI và SGK nói khác nhau, nên tin AI vì AI mới hơn.', 0, 'Sai. Hãy đối chiếu SGK, hỏi thầy cô – không mặc định tin AI.'],
  ['Thông tin cá nhân của bạn bè cũng cần được bảo vệ khi dùng AI.', 1, 'Đúng. Không đưa ảnh, số điện thoại, chuyện riêng của người khác cho AI.'],
  ['Chỉ cần gõ “giải giúp mình” là một câu lệnh tốt.', 0, 'Sai. Câu lệnh tốt cần vai trò, bối cảnh, nhiệm vụ và giới hạn rõ ràng.'],
  ['Một ngày tự học không dùng AI giúp kiểm tra mình có phụ thuộc AI không.', 1, 'Đúng. Đây là cách tự đánh giá mức độ phụ thuộc vào công cụ.'],
  ['AI tạo sinh có thể tạo ra văn bản, hình ảnh và âm thanh mới.', 1, 'Đúng. “Tạo sinh” nghĩa là tạo ra nội dung mới từ yêu cầu của người dùng.'],
  ['Học sinh chỉ cần nhớ đáp án AI đưa, không cần hiểu cách làm.', 0, 'Sai. Gặp bài khác đi một chút là bí ngay. Hiểu cách làm mới là học thật.'],
  ['Nhờ AI nhận xét dàn ý tự lập là cách dùng AI hợp lí.', 1, 'Đúng. Bài vẫn là của em, AI chỉ góp ý để em tự sửa.'],
  ['Tin “giật gân” trên mạng nên chia sẻ ngay để mọi người biết.', 0, 'Sai. Cần kiểm chứng nguồn chính thống trước khi chia sẻ để tránh lan tin giả.'],
  ['Giải thích lại bài cho bạn nghe giúp mình nhớ bài lâu hơn.', 1, 'Đúng. Dạy lại người khác là một trong những cách học nhớ lâu nhất.'],
  ['AI có thể thay thế hoàn toàn vai trò của thầy cô.', 0, 'Sai. AI là công cụ hỗ trợ; thầy cô định hướng, động viên và đánh giá con người.'],
  ['Đặt mục tiêu học tập cụ thể giúp tự học hiệu quả hơn.', 1, 'Đúng. Mục tiêu rõ ràng (học gì, đến khi nào) giúp tập trung và đo được tiến bộ.'],
  ['Chụp ảnh bảng điểm có họ tên gửi cho AI là hoàn toàn an toàn.', 0, 'Sai. Bảng điểm chứa thông tin cá nhân, không nên đưa cho AI.'],
  ['Nên hỏi AI từng bước gợi ý thay vì xin cả lời giải.', 1, 'Đúng. Gợi ý từng bước giúp em tự đi đến đáp án.'],
  ['Nếu AI trả lời ngay, nghĩa là câu trả lời chắc chắn chính xác.', 0, 'Sai. Tốc độ trả lời không liên quan đến độ chính xác.'],
  ['Phân tích kết quả bài kiểm tra để rút kinh nghiệm là tự học.', 1, 'Đúng. Học từ lỗi sai là kĩ năng tự đánh giá – tự điều chỉnh.'],
  ['Nhờ AI viết hộ bài văn rồi đổi vài từ là được coi là tự làm.', 0, 'Sai. Ý tưởng và lập luận vẫn là của AI – đó không phải bài của em.'],
  ['AI có thể dùng dữ liệu bạn nhập vào để cải thiện hệ thống.', 1, 'Đúng. Nhiều dịch vụ AI có thể lưu và dùng dữ liệu – vì vậy đừng nhập thông tin riêng tư.'],
  ['Học sinh nên đặt câu hỏi “AI nói vậy có đúng không?”.', 1, 'Đúng. Đây là tư duy phản biện – kĩ năng quan trọng khi dùng AI.'],
  ['Sơ đồ tư duy do AI vẽ sẵn giúp em nhớ bài bằng sơ đồ em tự vẽ.', 0, 'Sai. Tự vẽ sơ đồ buộc não sắp xếp kiến thức, nên nhớ lâu hơn nhiều.'],
  ['Chatbot là chương trình có thể trò chuyện với con người bằng ngôn ngữ tự nhiên.', 1, 'Đúng. ChatGPT, Gemini… là các chatbot dùng AI tạo sinh.'],
  ['Tự học hiệu quả là học thật nhiều giờ liền không nghỉ.', 0, 'Sai. Học có kế hoạch, có nghỉ ngắn và tự kiểm tra hiệu quả hơn học dồn.'],
  ['Hỏi AI mẹo ghi nhớ rồi tự kiểm tra lại là cách học chủ động.', 1, 'Đúng. Kết hợp mẹo nhớ và tự kiểm tra giúp nhớ lâu.'],
  ['Video có khuôn mặt và giọng người quen thì chắc chắn là thật.', 0, 'Sai. Deepfake có thể giả cả mặt lẫn giọng. Hãy gọi lại trực tiếp để xác minh.'],
  ['Năng lực tự học giúp học sinh học suốt đời, kể cả sau khi ra trường.', 1, 'Đúng. Đó là lí do năng lực tự học rất quan trọng trong thời đại AI.'],
];

/* Ghép cặp: [khái niệm, định nghĩa] */
const PAIR_BANK = [
  ['AI tạo sinh', 'AI tạo ra nội dung mới: chữ, ảnh, âm thanh'],
  ['Câu lệnh (prompt)', 'Lời yêu cầu ta gõ cho AI'],
  ['Ảo giác AI', 'AI bịa thông tin sai nhưng nghe rất tự tin'],
  ['Deepfake', 'Video, giọng nói giả tạo bằng AI'],
  ['Chatbot', 'Chương trình trò chuyện bằng ngôn ngữ tự nhiên'],
  ['Kiểm chứng', 'Đối chiếu thông tin với nguồn tin cậy'],
  ['Khai báo AI', 'Ghi rõ đã dùng AI ở phần nào của bài'],
  ['Năng lực tự học', 'Tự đặt mục tiêu, tự học và tự đánh giá'],
  ['Tự đánh giá', 'Biết mình đã hiểu gì, còn hổng gì'],
  ['Lập kế hoạch học', 'Xác định học gì, khi nào, bao lâu'],
  ['Tư duy phản biện', 'Đặt câu hỏi “điều này có đúng không?”'],
  ['Dữ liệu cá nhân', 'Thông tin như tên, địa chỉ, số CCCD'],
  ['Mã OTP', 'Mã xác thực dùng một lần, không đưa ai'],
  ['Luật 15 phút', 'Tự nghĩ trước rồi mới hỏi AI'],
  ['Phụ thuộc AI', 'Không tự làm được nếu thiếu AI'],
  ['Tin giả', 'Thông tin sai lan truyền trên mạng'],
  ['Xác thực 2 bước', 'Thêm lớp bảo vệ ngoài mật khẩu'],
  ['Sơ đồ tư duy', 'Cách hệ thống kiến thức bằng nhánh'],
  ['Vai trò trong câu lệnh', 'Cho AI biết đóng vai gia sư, người hướng dẫn'],
  ['Giới hạn trong câu lệnh', 'Luật để AI không làm hộ em'],
  ['Dữ liệu huấn luyện', 'Kho dữ liệu AI dùng để học'],
  ['Liêm chính học tập', 'Trung thực trong học tập và thi cử'],
  ['Tự kiểm tra', 'Tự làm câu hỏi để biết mình nhớ đến đâu'],
  ['Học chủ động', 'Tự tìm hiểu, đặt câu hỏi, không chờ đáp án'],
];

/* Kéo thả: mỗi bộ có các ô (bins) và thẻ [chữ, số thứ tự ô đúng] */
const DRAG_SETS = [
  { t: 'Tự học thật hay phụ thuộc AI?', bins: ['🌱 Tự học chủ động', '⚠️ Phụ thuộc AI'], cards: [
    ['Tự làm 15 phút rồi mới hỏi AI', 0], ['Chép nguyên lời giải AI vào vở', 1], ['Nhờ AI giải thích chỗ chưa hiểu', 0], ['Nhờ AI viết hộ cả bài văn', 1],
    ['Tự kiểm chứng lại với SGK', 0], ['Không tự làm được khi thiếu AI', 1], ['Nhờ AI ra câu hỏi để tự kiểm tra', 0], ['Nộp bài AI làm, không đọc lại', 1]] },
  { t: 'Xếp vào đúng thành phần của năng lực tự học', bins: ['🎯 Lập kế hoạch', '📖 Tự tìm hiểu', '✅ Tự kiểm tra – đánh giá'], cards: [
    ['Đặt mục tiêu học trong tuần', 0], ['Chia thời gian ôn từng môn', 0], ['Đọc SGK và ghi ý chính', 1], ['Tra cứu thêm tài liệu tin cậy', 1],
    ['Làm đề rồi tự chấm điểm', 2], ['Ghi lại lỗi sai để sửa', 2], ['Nhờ AI giải thích khái niệm khó', 1], ['Cuối tuần xem mình tiến bộ gì', 2]] },
  { t: 'Việc nào AI hỗ trợ tốt, việc nào phải để con người quyết định?', bins: ['🤖 AI hỗ trợ tốt', '🧑 Con người phải tự làm'], cards: [
    ['Gợi ý ý tưởng ban đầu', 0], ['Quyết định đáp án cuối cùng', 1], ['Giải thích từ vựng mới', 0], ['Chịu trách nhiệm về bài làm', 1],
    ['Gợi ý lịch ôn tập', 0], ['Đánh giá thông tin đúng hay sai', 1], ['Ra câu hỏi luyện tập', 0], ['Khai báo đã dùng AI', 1]] },
  { t: 'Thông tin nào đáng tin, thông tin nào cần cảnh giác?', bins: ['✅ Đáng tin hơn', '🚩 Cần cảnh giác'], cards: [
    ['Có nguồn từ cơ quan chính thống', 0], ['Tiêu đề giật gân, nhiều dấu chấm than', 1], ['Nhiều báo uy tín cùng đưa tin', 0], ['Yêu cầu chia sẻ gấp kẻo “mất lượt”', 1],
    ['Ghi rõ tác giả, ngày đăng', 0], ['Không rõ ai viết, đăng khi nào', 1], ['Khớp với nội dung SGK', 0], ['Đòi bấm link lạ để nhận quà', 1]] },
  { t: 'Sắp xếp 4 bước hỏi AI thông minh vào đúng thứ tự', order: true, bins: ['Bước 1', 'Bước 2', 'Bước 3', 'Bước 4'], cards: [
    ['🧭 Tự định hướng: xác định mình cần gì', 0], ['💡 Hỏi AI gợi ý, không xin đáp án', 1], ['✍️ Tự làm và phản biện câu trả lời', 2], ['📊 Tự đánh giá: mình học được gì', 3]] },
  { t: 'Xếp các bước một buổi tự học hiệu quả', order: true, bins: ['1', '2', '3', '4', '5'], cards: [
    ['🎯 Đặt mục tiêu buổi học', 0], ['📖 Tự đọc bài, ghi ý chính', 1], ['🤔 Tự làm bài tập 15 phút', 2], ['🤖 Hỏi AI chỗ còn bí', 3], ['✅ Tự kiểm tra và ghi lại', 4]] },
];

/* Câu hỏi 3 lựa chọn (Mật thư & Vượt chướng ngại vật): {lv, q, o:[đúng, sai, sai], e} */
const MCQ_BANK = [
  { lv: 1, q: '“Prompt” trong AI nghĩa là gì?', o: ['Câu lệnh ta gõ cho AI', 'Tên một loại máy tính', 'Một phần mềm diệt virus'], e: 'Prompt là câu lệnh, lời yêu cầu gửi cho AI.' },
  { lv: 1, q: 'Trước khi hỏi AI, nên tự nghĩ khoảng bao lâu?', o: ['Khoảng 15 phút', 'Không cần nghĩ', 'Khoảng 2 giây'], e: 'Luật 15 phút: tự nghĩ trước rồi mới hỏi AI.' },
  { lv: 1, q: 'Thông tin nào KHÔNG được gửi cho AI?', o: ['Mã OTP ngân hàng', 'Câu hỏi bài Sinh học', 'Từ vựng tiếng Anh'], e: 'OTP, mật khẩu, số tài khoản tuyệt đối giữ kín.' },
  { lv: 1, q: 'Khi bài làm có dùng AI, em nên làm gì?', o: ['Khai báo trung thực', 'Giấu kín không nói', 'Xóa dấu vết AI'], e: 'Dùng AI thì khai báo – trung thực là cách học an toàn nhất.' },
  { lv: 1, q: 'Cách nào giúp kiểm chứng câu trả lời của AI?', o: ['Đối chiếu với SGK', 'Hỏi lại đúng câu đó', 'Tin vì AI rất giỏi'], e: 'SGK, thầy cô, nguồn chính thống là chỗ dựa để kiểm chứng.' },
  { lv: 1, q: 'Deepfake là gì?', o: ['Video, giọng nói giả bằng AI', 'Một trò chơi điện tử mới ra', 'Một loại mạng xã hội'], e: 'Deepfake dùng AI để giả mặt, giả giọng người thật.' },
  { lv: 1, q: 'Câu lệnh nào giúp em học thật?', o: ['Gợi ý bước tiếp theo cho em', 'Giải hết bài này giúp em nhé', 'Viết hộ bài văn cho em'], e: 'Xin gợi ý để tự làm, không xin đáp án sẵn.' },
  { lv: 1, q: 'Tự học có nghĩa là gì?', o: ['Chủ động học, biết hỏi khi cần', 'Học một mình, không hỏi ai cả', 'Chỉ học khi có AI'], e: 'Người tự học chủ động và biết tìm sự hỗ trợ đúng lúc.' },
  { lv: 1, q: 'Gặp tin “giật gân” trên mạng, em nên làm gì?', o: ['Kiểm chứng trước khi chia sẻ', 'Chia sẻ ngay cho cả lớp biết', 'Bình luận thật sôi nổi'], e: 'Kiểm chứng nguồn để không vô tình lan tin giả.' },
  { lv: 1, q: 'Chatbot nào sau đây là AI tạo sinh?', o: ['Gemini', 'Máy tính bỏ túi', 'Bàn phím máy tính'], e: 'Gemini, ChatGPT… là chatbot dùng AI tạo sinh.' },
  { lv: 1, q: 'AI có thể mắc lỗi không?', o: ['Có, kể cả khi rất tự tin', 'Không bao giờ, AI luôn đúng', 'Chỉ khi mất mạng'], e: 'AI có thể “ảo giác” – bịa thông tin nghe rất hợp lí.' },
  { lv: 1, q: 'Bước đầu tiên của năng lực tự học là gì?', o: ['Đặt mục tiêu, lập kế hoạch', 'Nhờ AI làm bài tập về nhà', 'Chép bài của bạn'], e: 'Có mục tiêu rõ thì mới biết học gì, học bao lâu.' },
  { lv: 1, q: 'Bạn nhờ em gửi mã OTP “để giúp”. Em làm gì?', o: ['Từ chối, báo người lớn', 'Gửi ngay cho bạn cho nhanh', 'Gửi một nửa mã thôi'], e: 'Không bao giờ chia sẻ OTP – đó là dấu hiệu lừa đảo.' },
  { lv: 1, q: 'Sau khi đọc gợi ý của AI, em nên làm gì?', o: ['Tự làm lại bằng cách hiểu', 'Chép nguyên văn vào vở ghi', 'Đóng máy, đi chơi luôn'], e: 'Tự làm lại giúp kiến thức thành của mình.' },
  { lv: 1, q: 'Ai chịu trách nhiệm về bài làm có dùng AI?', o: ['Chính người làm bài', 'Công ty làm ra AI', 'Không ai cả'], e: 'Người nộp bài chịu trách nhiệm về nội dung bài.' },
  { lv: 2, q: 'Câu lệnh tốt gồm những phần nào?', o: ['Vai trò, bối cảnh, nhiệm vụ, giới hạn', 'Chỉ cần gõ thật nhiều chữ, càng dài càng tốt', 'Tên AI và dấu chấm hỏi'], e: 'Đủ 4 khối giúp AI hiểu đúng điều em cần.' },
  { lv: 2, q: '“Ảo giác AI” là hiện tượng gì?', o: ['AI bịa thông tin trông như thật', 'AI bị mất kết nối mạng giữa chừng', 'AI trả lời quá chậm'], e: 'AI có thể tạo ra nguồn, số liệu không có thật.' },
  { lv: 2, q: 'Đâu là biểu hiện của tự đánh giá?', o: ['Ghi lại lỗi sai và cách sửa', 'Nhờ bạn làm hộ bài tập về nhà', 'Học thuộc đáp án AI đưa'], e: 'Biết mình sai ở đâu là bước để tiến bộ.' },
  { lv: 2, q: 'Vì sao không nên chép nguyên bài AI viết?', o: ['Em không rèn được kĩ năng', 'Vì AI viết quá ngắn', 'Vì chép mất nhiều thời gian'], e: 'AI làm hộ được bài, nhưng không học hộ được tư duy.' },
  { lv: 2, q: 'Cách nào giúp nhớ bài lâu nhất?', o: ['Tự giải thích lại cho người khác', 'Đọc lướt bản tóm tắt AI viết sẵn', 'Chụp ảnh lời giải lưu lại'], e: 'Dạy lại người khác buộc não sắp xếp và nhớ sâu.' },
  { lv: 2, q: 'Bối cảnh trong câu lệnh nên có gì?', o: ['Phần em đã làm, chỗ em bí', 'Họ tên, lớp và trường của em', 'Số điện thoại của em'], e: 'Cho AI biết em đang ở đâu để gợi ý đúng chỗ.' },
  { lv: 2, q: 'AI và SGK nói khác nhau, em làm gì?', o: ['Đối chiếu, hỏi thầy cô', 'Tin AI vì AI mới hơn', 'Bỏ qua, không cần biết'], e: 'Đối chiếu nguồn tin cậy và hỏi thầy cô.' },
  { lv: 2, q: 'Cách tự kiểm tra hiệu quả khi dùng AI là gì?', o: ['Làm câu hỏi trước, xem đáp án sau', 'Xem đáp án trước rồi mới làm bài', 'Chỉ đọc câu hỏi, không làm'], e: 'Làm trước – chấm sau giúp biết mình thật sự nhớ gì.' },
  { lv: 2, q: 'Mẫu khai báo dùng AI cần ghi những gì?', o: ['Công cụ và phần AI hỗ trợ', 'Chỉ cần ghi “có dùng AI”', 'Mật khẩu tài khoản AI'], e: 'Ví dụ: “Dùng Gemini – AI gợi ý dàn ý – em tự viết bài”.' },
  { lv: 2, q: 'Ảnh nào KHÔNG nên đưa cho AI?', o: ['Ảnh thẻ học sinh', 'Ảnh đề bài trong SGK', 'Ảnh biểu đồ dân số'], e: 'Thẻ học sinh lộ họ tên, lớp, trường và khuôn mặt.' },
  { lv: 2, q: 'Học sinh phụ thuộc AI thường có dấu hiệu nào?', o: ['Không tự làm được khi thiếu AI', 'Hay hỏi thầy cô khi gặp chỗ bí', 'Tự lập kế hoạch học tập'], e: 'Nếu thiếu AI là bí hoàn toàn – đó là đang phụ thuộc.' },
  { lv: 2, q: 'Giới hạn nào phù hợp khi nhờ AI học Toán?', o: ['Đừng giải hết, để em làm', 'Giải thật nhanh, khỏi nói', 'Chỉ ghi đáp số cuối cùng'], e: 'Giới hạn giữ cho AI là người gợi ý, không phải làm hộ.' },
  { lv: 2, q: 'Video người quen xin tiền gấp, em nên làm gì?', o: ['Gọi lại trực tiếp để xác minh', 'Chuyển tiền ngay cho kịp lúc', 'Gửi video cho bạn bè xem'], e: 'Kẻ gian có thể dùng deepfake giả người quen.' },
  { lv: 2, q: 'Vai trò nào phù hợp khi nhờ AI ôn bài?', o: ['Gia sư biết đặt câu hỏi', 'Người làm bài thay em', 'Máy tra đáp án nhanh'], e: 'Vai trò gia sư giúp AI hỏi – gợi – để em tự học.' },
  { lv: 2, q: 'Mục tiêu học tập nào cụ thể nhất?', o: ['Làm đúng 8/10 câu ôn chương 2', 'Cố gắng học cho giỏi hơn trước', 'Cố gắng chăm chỉ'], e: 'Mục tiêu cụ thể thì đo được và biết khi nào đạt.' },
  { lv: 3, q: 'Câu lệnh nào thể hiện tư duy phản biện?', o: ['Chỉ ra chỗ nào bạn chưa chắc chắn', 'Trả lời thật chắc chắn, đừng do dự', 'Viết thật dài cho đầy đủ'], e: 'Yêu cầu AI nói rõ chỗ chưa chắc giúp em biết cần kiểm chứng gì.' },
  { lv: 3, q: 'Vì sao AI có thể trả lời sai về sự kiện mới?', o: ['Dữ liệu huấn luyện có thể đã cũ', 'Vì AI cố tình nói dối người dùng', 'Vì người hỏi gõ sai dấu'], e: 'AI học từ dữ liệu đến một thời điểm, có thể chưa cập nhật.' },
  { lv: 3, q: 'Cách nào đánh giá mình có phụ thuộc AI không?', o: ['Thử một ngày học không dùng AI', 'Hỏi AI xem mình có phụ thuộc', 'Đếm số lần mở ứng dụng AI'], e: 'Tự làm khi không có AI cho biết năng lực thật của em.' },
  { lv: 3, q: 'Dùng AI tóm tắt bài, bước tiếp theo tốt nhất là?', o: ['So bản tóm tắt với SGK', 'Học thuộc bản tóm tắt', 'Chia sẻ lên nhóm lớp ngay'], e: 'Bản tóm tắt có thể thiếu hoặc sai ý – cần đối chiếu.' },
  { lv: 3, q: 'Câu lệnh nào phù hợp nhất để ôn Lịch sử?', o: ['Hỏi em từng câu, chờ em trả lời', 'Hỏi em 10 câu, kèm đáp án bên dưới', 'Lập bảng mốc để em học thuộc'], e: 'Chờ em trả lời giúp em nhớ lại thật sự (gợi nhớ chủ động).' },
  { lv: 3, q: 'Thông tin nào ghép lại dễ khiến người lạ tìm ra em?', o: ['Họ tên, lớp và trường', 'Tên một con sông', 'Năm sinh của Bác Hồ'], e: 'Ghép đủ họ tên + lớp + trường là lộ danh tính.' },
  { lv: 3, q: 'Kết quả AI ảnh hưởng đến tự học phụ thuộc chủ yếu vào?', o: ['Cách học sinh sử dụng AI', 'Tên công cụ AI đang dùng', 'Tốc độ mạng internet'], e: 'Cùng là AI, dùng để hiểu bài hay để chép sẽ cho kết quả ngược nhau.' },
  { lv: 3, q: 'Khi AI đưa nguồn tham khảo, em nên làm gì?', o: ['Mở kiểm tra nguồn có thật', 'Ghi ngay nguồn đó vào bài làm', 'Bỏ qua phần nguồn'], e: 'AI có thể bịa tên sách, đường link không tồn tại.' },
  { lv: 3, q: 'Đâu là cách dùng AI rèn năng lực tự học?', o: ['Nhờ AI hỏi ngược để em tự nghĩ', 'Nhờ AI làm hết bài tập về nhà', 'Nhờ AI viết đề cương sẵn'], e: 'AI hỏi ngược buộc em suy nghĩ – đó là học chủ động.' },
  { lv: 3, q: 'Nhóm dùng AI viết gần hết dự án, nên làm gì?', o: ['Khai báo rõ và tự làm lại phần chính', 'Sửa lại lời văn để giấu việc dùng AI', 'Ghi chung chung “có tham khảo”'], e: 'Liêm chính học tập: khai báo rõ ràng, sản phẩm phải là của mình.' },
];


/* =====================================================================
   5 GAME MỚI: Đấu trường Đúng–Sai · Kéo thả · Ghép cặp · Mật thư · Vượt chướng ngại vật
   ===================================================================== */
/* ---------- Âm thanh (WebAudio, không cần file) ---------- */
const SND = { on: true, ctx: null };
function snd(kind) {
  if (!SND.on) return; try {
    SND.ctx = SND.ctx || new (window.AudioContext || window.webkitAudioContext)(); const c = SND.ctx; if (c.state === 'suspended') c.resume();
    const seq = { ok: [[660, .08], [880, .14]], bad: [[220, .12], [180, .18]], win: [[523, .1], [659, .1], [784, .1], [1047, .28]], tick: [[1000, .03]], pick: [[520, .05]] }[kind] || [[440, .1]];
    let t = c.currentTime; seq.forEach(([f, d]) => { const o = c.createOscillator(), g = c.createGain(); o.type = kind === 'bad' ? 'sawtooth' : 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(kind === 'tick' ? .05 : .18, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + d); o.connect(g).connect(c.destination); o.start(t); o.stop(t + d + .02); t += d * .9; });
  } catch (_) { /* bỏ qua nếu trình duyệt chặn âm thanh */ }
}
const TEAMS = [{ n: 'Đội Xanh', e: '🔵', c: '#3fa9ff' }, { n: 'Đội Đỏ', e: '🔴', c: '#ff5f7f' }];

/* ---------- Khung chung cho mỗi game ---------- */
function gShell(box, cfg) {
  box.innerHTML = '';
  const intro = el('div', 'gs-intro'); intro.append(el('div', 'gs-emoji', cfg.emoji), el('h3', '', cfg.title), el('p', 'gs-sub', cfg.sub));
  const ul = el('ol', 'gs-how'); cfg.how.forEach((h) => { const li = el('li'); li.innerHTML = h; ul.appendChild(li); }); intro.appendChild(ul);
  const opt = el('div', 'gs-opts');
  const modeRow = el('div', 'gs-row'); modeRow.appendChild(el('b', '', 'Chế độ:'));
  const st = { mode: 'solo', extra: cfg.extra ? cfg.extra.def : null };
  [['solo', '🙋 Cá nhân'], ['team', '🔵🔴 Thi đua 2 đội']].forEach(([v, t]) => { const b = el('button', 'gs-chip' + (v === 'solo' ? ' on' : ''), t); b.type = 'button'; b.addEventListener('click', () => { st.mode = v; modeRow.querySelectorAll('.gs-chip').forEach((x) => x.classList.toggle('on', x === b)); }); modeRow.appendChild(b); });
  opt.appendChild(modeRow);
  if (cfg.extra) { const r = el('div', 'gs-row'); r.appendChild(el('b', '', cfg.extra.label)); cfg.extra.items.forEach(([v, t]) => { const b = el('button', 'gs-chip' + (v === cfg.extra.def ? ' on' : ''), t); b.type = 'button'; b.addEventListener('click', () => { st.extra = v; r.querySelectorAll('.gs-chip').forEach((x) => x.classList.toggle('on', x === b)); }); r.appendChild(b); }); opt.appendChild(r); }
  intro.appendChild(opt);
  const go = el('button', 'btn btn-primary btn-shine gs-start', '▶ Bắt đầu'); go.type = 'button'; intro.appendChild(go);
  const stage = el('div', 'gs-stage'); stage.hidden = true;
  const top = el('div', 'gs-top'); const score = el('div', 'gs-score'); const tools = el('div', 'gs-tools');
  const mute = el('button', 'mini', SND.on ? '🔊' : '🔇'); mute.type = 'button'; mute.title = 'Bật/tắt âm thanh'; mute.addEventListener('click', () => { SND.on = !SND.on; document.querySelectorAll('.gs-mute').forEach((m) => { m.textContent = SND.on ? '🔊' : '🔇'; }); }); mute.classList.add('gs-mute');
  const quit = el('button', 'mini', '↩ Về màn hình đầu'); quit.type = 'button'; quit.addEventListener('click', () => { cfg.stop && cfg.stop(); stage.hidden = true; res.hidden = true; intro.hidden = false; });
  tools.append(mute, quit); top.append(score, tools); stage.appendChild(top);
  const body = el('div', 'gs-body'); stage.appendChild(body);
  const res = el('div', 'gs-result'); res.hidden = true;
  box.append(intro, stage, res);
  go.addEventListener('click', () => { snd('pick'); intro.hidden = true; res.hidden = true; stage.hidden = false; cfg.start(st); });
  return {
    st, body, score, res, stage, intro,
    setScore(html) { score.innerHTML = html; },
    finish(html, again) {
      stage.hidden = true; res.hidden = false; res.innerHTML = ''; const c = el('div', 'gs-res-box'); c.innerHTML = html;
      const a = el('button', 'btn btn-primary', '↻ Chơi lại'); a.type = 'button'; a.addEventListener('click', () => { res.hidden = true; stage.hidden = false; cfg.start(st); });
      const b = el('button', 'btn btn-outline', '⚙️ Đổi chế độ'); b.type = 'button'; b.addEventListener('click', () => { res.hidden = true; intro.hidden = false; });
      const row = el('div', 'gs-res-act'); row.append(a, b); if (again) row.appendChild(again); c.appendChild(row); res.appendChild(c); snd('win'); confetti(160);
    },
  };
}
function scoreHTML(st, sc, turn, extra) {
  if (st.mode === 'team') return TEAMS.map((t, i) => `<span class="gs-team${turn === i ? ' turn' : ''}" style="--tc:${t.c}">${t.e} ${t.n}: <b>${sc[i]}</b></span>`).join('') + (extra || '');
  return `<span class="gs-pts">⭐ <b>${sc[0]}</b> điểm</span>` + (extra || '');
}
function timerBar(sec, onEnd) {
  const wrap = el('div', 'gs-timer'); const bar = el('i'); const lab = el('span'); wrap.append(bar, lab); let left = sec, id = 0;
  const draw = () => { bar.style.width = (left / sec * 100) + '%'; lab.textContent = `⏱ ${Math.ceil(left)} giây`; wrap.classList.toggle('low', left <= 5); };
  return { el: wrap, start() { left = sec; draw(); clearInterval(id); id = setInterval(() => { left -= .25; if (left <= 5 && Math.abs(left - Math.round(left)) < .01 && left > 0) snd('tick'); draw(); if (left <= 0) { clearInterval(id); onEnd(); } }, 250); }, stop() { clearInterval(id); }, left: () => left };
}
const praiseFor = (p) => (p >= .9 ? '🏆 Xuất sắc! Bạn đúng là “người cầm lái AI” thực thụ!' : p >= .7 ? '🌟 Rất giỏi! Chỉ còn chút xíu nữa là hoàn hảo.' : p >= .5 ? '👍 Khá lắm! Xem lại phần giải thích để lần sau bứt phá nhé.' : '🌱 Không sao! Mỗi lần chơi là một lần học – thử lại nào!');
function teamResult(sc) { if (sc[0] === sc[1]) return '🤝 Hai đội hòa nhau – quá ngang tài ngang sức!'; const w = sc[0] > sc[1] ? 0 : 1; return `🏆 <b>${TEAMS[w].e} ${TEAMS[w].n}</b> chiến thắng với <b>${sc[w]}</b> điểm!`; }

/* =====================================================================
   1) ĐẤU TRƯỜNG ĐÚNG – SAI (gộp cả kho “Thợ săn lỗi AI” 201 câu)
   ===================================================================== */
function tfPool(kind) {
  const ai = TF_BANK.map(([s, t, e]) => ({ s, t: Boolean(t), e, tag: 'AI & Tự học' }));
  const mon = (DATA.quiz || []).map((q) => { const m = String(q.q).match(/^\[(.+?)\]\s*AI nói:\s*(“.+?”)/); if (!m) return null; const right = q.options[q.ans] || ''; return { s: 'AI nói: ' + m[2], t: /^Đúng/.test(right), e: (right && !/^Đúng/.test(right) ? right + ' ' : '') + (q.explain || ''), tag: m[1] }; }).filter(Boolean);
  return kind === 'ai' ? ai : kind === 'mon' ? mon : ai.concat(mon);
}
const Arena = { init() {
  const S = gShell($('gArena'), {
    emoji: '⚔️', title: 'Đấu trường Đúng – Sai', sub: `Kho ${TF_BANK.length + (DATA.quiz || []).length} nhận định về AI, tự học và “lời AI nói” ở 9 môn học.`,
    how: ['Đọc nhận định thật nhanh nhưng thật kĩ.', 'Bấm <b>✅ ĐÚNG</b> hoặc <b>❌ SAI</b> trước khi hết <b>20 giây</b>.', 'Đúng được <b>+10 điểm</b>, sai không bị trừ. Đọc giải thích để nhớ kiến thức.', 'Chế độ 2 đội: hai đội <b>thay phiên</b> trả lời, mỗi đội 6 câu.'],
    extra: { label: 'Kho câu:', def: 'ai', items: [['ai', '🤖 AI & Tự học'], ['mon', '🔍 Thợ săn lỗi (9 môn)'], ['mix', '🎲 Trộn']] },
    start: (st) => run(st), stop: () => T.stop(),
  });
  let Q = [], i = 0, sc = [0, 0], right = 0, lock = false; const T = timerBar(20, () => answer(null));
  function run(st) { const n = st.mode === 'team' ? 12 : 10; Q = shuffle(tfPool(st.extra)).slice(0, n); i = 0; sc = [0, 0]; right = 0; show(); }
  function show() {
    const st = S.st, q = Q[i], turn = st.mode === 'team' ? i % 2 : 0; lock = false;
    S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Câu ${i + 1}/${Q.length}</span>`));
    S.body.innerHTML = ''; S.body.appendChild(T.el);
    const card = el('div', 'tf-card'); if (st.mode === 'team') card.appendChild(el('div', 'tf-turn', `Lượt của ${TEAMS[turn].e} ${TEAMS[turn].n}`));
    card.append(el('span', 'tf-tag', q.tag), el('p', 'tf-q', q.s)); S.body.appendChild(card);
    const btns = el('div', 'tf-btns'); const y = el('button', 'tf-btn yes', '✅ ĐÚNG'), n = el('button', 'tf-btn no', '❌ SAI'); y.type = n.type = 'button';
    y.addEventListener('click', () => answer(true)); n.addEventListener('click', () => answer(false)); btns.append(y, n); S.body.appendChild(btns);
    const fb = el('div', 'tf-fb'); fb.hidden = true; S.body.appendChild(fb); T.start();
  }
  function answer(v) {
    if (lock) return; lock = true; T.stop(); const st = S.st, q = Q[i], turn = st.mode === 'team' ? i % 2 : 0; const ok = v === q.t;
    if (ok) { sc[turn] += 10; right++; snd('ok'); bumpDay('quizOk', 1); gainXP(10, 'arena'); } else snd('bad');
    S.body.querySelectorAll('.tf-btn').forEach((b) => { b.disabled = true; b.classList.toggle('pick', (b.classList.contains('yes') && v === true) || (b.classList.contains('no') && v === false)); b.classList.toggle('truth', (b.classList.contains('yes') && q.t) || (b.classList.contains('no') && !q.t)); });
    const fb = S.body.querySelector('.tf-fb'); fb.hidden = false; fb.className = 'tf-fb ' + (ok ? 'ok' : 'bad');
    fb.innerHTML = `<b>${v === null ? '⏰ Hết giờ!' : ok ? pickOne(['🎉 Chính xác!', '👏 Quá đỉnh!', '✨ Chuẩn luôn!']) : '😅 Chưa đúng rồi!'}</b> Đáp án: <b>${q.t ? 'ĐÚNG' : 'SAI'}</b>. ${esc(String(q.e).replace(/^(Đúng|Sai)\.\s*/, ''))}`;
    const nx = el('button', 'btn btn-primary btn-small', i + 1 < Q.length ? 'Câu tiếp theo →' : '🏁 Xem kết quả'); nx.type = 'button'; nx.addEventListener('click', () => { i++; if (i < Q.length) show(); else end(); }); fb.appendChild(nx);
    S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Câu ${i + 1}/${Q.length}</span>`));
  }
  function end() {
    const st = S.st; bumpDay('quizRounds', 1); const P = player(); P.games++; if (right === Q.length) P.perfect++; savePlayer(P); if (right / Q.length >= .7) gainXP(20, 'arena');
    S.finish(st.mode === 'team' ? `<div class="gs-big">⚔️</div><h3>Kết thúc trận đấu!</h3><p>${teamResult(sc)}</p><p>${TEAMS[0].e} ${sc[0]} điểm · ${TEAMS[1].e} ${sc[1]} điểm</p>` : `<div class="gs-big">🏅</div><h3>Bạn trả lời đúng ${right}/${Q.length} câu</h3><p class="gs-pt">${sc[0]} điểm</p><p>${praiseFor(right / Q.length)}</p>`);
  }
} };

/* =====================================================================
   2) KÉO THẢ KIẾN THỨC (chuột + cảm ứng; chạm để chọn rồi chạm ô)
   ===================================================================== */
const Drag = { init() {
  const S = gShell($('gDrag'), {
    emoji: '🧲', title: 'Kéo thả kiến thức', sub: `${DRAG_SETS.length} nhiệm vụ: phân loại thói quen tự học, sắp xếp các bước hỏi AI, nhận diện tin đáng tin…`,
    how: ['<b>Kéo</b> từng thẻ thả vào đúng ô. Trên điện thoại: <b>chạm thẻ</b> rồi <b>chạm ô</b>.', 'Thẻ đúng sẽ khóa lại (xanh) và được <b>+10 điểm</b>; thẻ sai rung lên và quay về.', 'Mỗi nhiệm vụ có <b>90 giây</b>. Xong nhiệm vụ được <b>thưởng thêm điểm thời gian</b>.', 'Chế độ 2 đội: mỗi đội làm 1 nhiệm vụ, luân phiên nhau.'],
    start: (st) => run(st), stop: () => T.stop(),
  });
  let sets = [], k = 0, sc = [0, 0], placed = 0, total = 0, sel = null, done = [], T = timerBar(90, () => endSet(true));
  function run(st) { sets = shuffle(DRAG_SETS.slice()).slice(0, st.mode === 'team' ? 4 : 3); k = 0; sc = [0, 0]; done = []; showSet(); }
  function showSet() {
    const st = S.st, set = sets[k], turn = st.mode === 'team' ? k % 2 : 0; placed = 0; total = set.cards.length; sel = null;
    S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Nhiệm vụ ${k + 1}/${sets.length}</span>`));
    S.body.innerHTML = ''; S.body.appendChild(T.el);
    const head = el('div', 'dg-head'); if (st.mode === 'team') head.appendChild(el('div', 'tf-turn', `Lượt của ${TEAMS[turn].e} ${TEAMS[turn].n}`)); head.appendChild(el('h4', '', set.t));
    const pb = el('div', 'dg-prog'); pb.appendChild(el('i')); head.appendChild(pb); S.body.appendChild(head);
    const bins = el('div', 'dg-bins' + (set.order ? ' order' : '')); bins.style.setProperty('--n', set.bins.length);
    set.bins.forEach((b, bi) => { const z = el('div', 'dg-bin'); z.dataset.bin = bi; z.appendChild(el('div', 'dg-bin-t', b)); z.appendChild(el('div', 'dg-bin-in')); z.addEventListener('click', () => { if (sel) drop(sel, z); }); bins.appendChild(z); });
    const tray = el('div', 'dg-tray');
    shuffle(set.cards.map((c, ci) => ({ t: c[0], b: c[1], ci }))).forEach((c) => {
      const d = el('div', 'dg-card', c.t); d.dataset.b = c.b; d.tabIndex = 0;
      d.addEventListener('click', () => { if (d.classList.contains('lock')) return; tray.querySelectorAll('.dg-card').forEach((x) => x.classList.remove('sel')); sel = d; d.classList.add('sel'); snd('pick'); });
      d.addEventListener('pointerdown', (e) => startDrag(e, d)); tray.appendChild(d);
    });
    S.body.append(tray, bins); T.start(); updProg();
  }
  function updProg() { const p = S.body.querySelector('.dg-prog i'); if (p) p.style.width = (placed / total * 100) + '%'; }
  function startDrag(e, d) {
    if (d.classList.contains('lock') || e.button > 0) return; const r = d.getBoundingClientRect(); const ox = e.clientX - r.left, oy = e.clientY - r.top; let moved = false, ghost = null;
    const mv = (ev) => { if (!moved && Math.hypot(ev.clientX - e.clientX, ev.clientY - e.clientY) < 6) return; if (!moved) { moved = true; ghost = d.cloneNode(true); ghost.classList.add('ghost'); ghost.style.width = r.width + 'px'; document.body.appendChild(ghost); d.classList.add('dragging'); }
      ghost.style.left = (ev.clientX - ox) + 'px'; ghost.style.top = (ev.clientY - oy) + 'px'; document.querySelectorAll('.dg-bin').forEach((z) => z.classList.remove('hover')); const z = document.elementFromPoint(ev.clientX, ev.clientY); const bin = z && z.closest('.dg-bin'); if (bin) bin.classList.add('hover'); ev.preventDefault(); };
    const up = (ev) => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); if (!moved) return; ghost.remove(); d.classList.remove('dragging'); document.querySelectorAll('.dg-bin').forEach((z) => z.classList.remove('hover')); const z = document.elementFromPoint(ev.clientX, ev.clientY); const bin = z && z.closest('.dg-bin'); if (bin) drop(d, bin); };
    addEventListener('pointermove', mv, { passive: false }); addEventListener('pointerup', up);
  }
  function drop(d, bin) {
    const st = S.st, turn = st.mode === 'team' ? k % 2 : 0; sel = null; d.classList.remove('sel');
    const set = sets[k]; const inBin = bin.querySelector('.dg-bin-in');
    if (Number(d.dataset.b) === Number(bin.dataset.bin) && !(set.order && inBin.children.length)) {
      d.classList.add('lock'); inBin.appendChild(d); placed++; sc[turn] += 10; snd('ok'); gainXP(5, 'drag'); bin.classList.add('flash'); setTimeout(() => bin.classList.remove('flash'), 500); updProg();
      S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Nhiệm vụ ${k + 1}/${sets.length}</span>`)); if (placed === total) endSet(false);
    } else { snd('bad'); d.classList.add('shake'); bin.classList.add('nope'); setTimeout(() => { d.classList.remove('shake'); bin.classList.remove('nope'); }, 500); }
  }
  function endSet(timeout) {
    T.stop(); const st = S.st, turn = st.mode === 'team' ? k % 2 : 0; const bonus = timeout ? 0 : Math.round(T.left() / 3); sc[turn] += bonus; done.push({ set: sets[k], placed, total });
    if (!timeout) { snd('win'); bumpDay('blocks', 1); }
    const box = el('div', 'dg-done'); box.innerHTML = timeout ? `⏰ Hết giờ! Bạn xếp đúng <b>${placed}/${total}</b> thẻ.` : `🎉 Hoàn thành! Thưởng thời gian <b>+${bonus}</b> điểm.`;
    const nx = el('button', 'btn btn-primary btn-small', k + 1 < sets.length ? 'Nhiệm vụ tiếp theo →' : '🏁 Xem tổng kết'); nx.type = 'button'; nx.addEventListener('click', () => { k++; if (k < sets.length) showSet(); else end(); });
    box.appendChild(nx); S.body.appendChild(box); S.body.querySelectorAll('.dg-card:not(.lock)').forEach((c) => c.classList.add('lock', 'miss'));
  }
  function end() {
    const st = S.st; const P = player(); P.games++; savePlayer(P); const all = done.reduce((a, x) => a + x.placed, 0), tot = done.reduce((a, x) => a + x.total, 0);
    const ans = el('details', 'gs-ans'); ans.appendChild(el('summary', '', '📖 Xem đáp án các nhiệm vụ'));
    done.forEach(({ set }) => { const d = el('div', 'gs-ans-set'); d.appendChild(el('b', '', set.t)); set.bins.forEach((b, bi) => { d.appendChild(el('p', '', `${b}: ${set.cards.filter((c) => c[1] === bi).map((c) => c[0]).join(' · ')}`)); }); ans.appendChild(d); });
    S.finish(st.mode === 'team' ? `<div class="gs-big">🧲</div><h3>Tổng kết kéo thả</h3><p>${teamResult(sc)}</p>` : `<div class="gs-big">🧲</div><h3>Xếp đúng ${all}/${tot} thẻ</h3><p class="gs-pt">${sc[0]} điểm</p><p>${praiseFor(all / tot)}</p>`, ans);
  }
} };

/* =====================================================================
   3) GHÉP CẶP THỬ THÁCH
   ===================================================================== */
const Match = { init() {
  const S = gShell($('gMatch'), {
    emoji: '🧩', title: 'Ghép cặp thử thách', sub: `Kho ${PAIR_BANK.length} cặp khái niệm – định nghĩa về AI và năng lực tự học. Mỗi lượt 6 cặp ngẫu nhiên.`,
    how: ['Bấm lần lượt <b>1 thẻ tím (khái niệm)</b> và <b>1 thẻ cam (định nghĩa)</b>.', 'Ghép đúng: cặp thẻ khóa lại, <b>+10 điểm</b>. Ghép sai: thẻ rung nhẹ, chọn lại.', 'Đồng hồ tính thời gian – càng nhanh càng được thưởng!', 'Chế độ 2 đội: thay phiên mỗi lượt ghép.'],
    start: (st) => run(st), stop: () => clearInterval(tid),
  });
  let pairs = [], a = null, sc = [0, 0], turn = 0, got = 0, t0 = 0, tid = 0, tries = 0;
  function run(st) {
    pairs = shuffle(PAIR_BANK.slice()).slice(0, 6); sc = [0, 0]; turn = 0; got = 0; tries = 0; a = null; t0 = Date.now(); clearInterval(tid);
    S.body.innerHTML = ''; const clock = el('div', 'mt-clock'); S.body.appendChild(clock); tid = setInterval(() => { clock.textContent = `⏱ ${Math.floor((Date.now() - t0) / 1000)} giây · Đã ghép ${got}/6 cặp`; }, 300);
    const grid = el('div', 'mt-grid');
    shuffle(pairs.flatMap((p, i) => [{ t: p[0], i, k: 'a' }, { t: p[1], i, k: 'b' }])).forEach((c) => {
      const d = el('button', 'mt-card ' + c.k, c.t); d.type = 'button'; d.dataset.i = c.i; d.dataset.k = c.k;
      d.addEventListener('click', () => pick(d)); grid.appendChild(d);
    });
    S.body.appendChild(grid); upd();
  }
  function upd() { S.setScore(scoreHTML(S.st, sc, S.st.mode === 'team' ? turn : 0)); }
  function pick(d) {
    if (d.classList.contains('done')) return; snd('pick');
    if (!a) { a = d; d.classList.add('sel'); return; }
    if (a === d) { d.classList.remove('sel'); a = null; return; }
    if (a.dataset.k === d.dataset.k) { a.classList.remove('sel'); a = d; d.classList.add('sel'); return; }
    tries++; const t = S.st.mode === 'team' ? turn : 0;
    if (a.dataset.i === d.dataset.i) { [a, d].forEach((x) => { x.classList.remove('sel'); x.classList.add('done'); }); sc[t] += 10; got++; snd('ok'); gainXP(5, 'match'); if (got === 6) return setTimeout(end, 500); }
    else { [a, d].forEach((x) => { x.classList.remove('sel'); x.classList.add('shake'); setTimeout(() => x.classList.remove('shake'), 450); }); snd('bad'); }
    a = null; if (S.st.mode === 'team') turn = 1 - turn; upd();
  }
  function end() {
    clearInterval(tid); const sec = Math.floor((Date.now() - t0) / 1000); const st = S.st; const bonus = Math.max(0, 60 - sec); if (st.mode !== 'team') sc[0] += bonus;
    const P = player(); P.games++; savePlayer(P); bumpDay('blocks', 2);
    const ans = el('details', 'gs-ans'); ans.appendChild(el('summary', '', '📖 Xem lại 6 cặp kiến thức')); pairs.forEach((p) => ans.appendChild(el('p', '', `🟣 ${p[0]} → 🟠 ${p[1]}`)));
    S.finish(st.mode === 'team' ? `<div class="gs-big">🧩</div><h3>Ghép xong 6 cặp!</h3><p>${teamResult(sc)}</p>` : `<div class="gs-big">🧩</div><h3>Hoàn thành trong ${sec} giây</h3><p class="gs-pt">${sc[0]} điểm</p><p>Số lần thử: ${tries} · Thưởng tốc độ +${bonus}</p><p>${praiseFor(6 / Math.max(6, tries))}</p>`, ans);
  }
} };

/* =====================================================================
   4) GIẢI MÃ MẬT THƯ
   ===================================================================== */
const CIPHER_WORDS = [['TỰ HỌC', 'Điều quan trọng nhất CLB mong bạn rèn luyện'], ['CẦM LÁI', 'Bạn làm việc này, còn AI chỉ đường'], ['KHAI BÁO', 'Việc cần làm khi bài có dùng AI'], ['KIỂM CHỨNG', 'Đối chiếu thông tin AI với nguồn tin cậy'], ['PHẢN BIỆN', 'Tư duy đặt câu hỏi “điều này có đúng không?”'], ['CHỦ ĐỘNG', 'Tự tìm hiểu, không chờ đáp án'], ['SÁNG TẠO', 'Điều AI hỗ trợ nhưng ý tưởng là của bạn']];
const plain = (s) => String(s).toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g, 'D').replace(/[^A-Z]/g, '');
const Cipher = { init() {
  const S = gShell($('gCipher'), {
    emoji: '🔐', title: 'Giải mã mật thư', sub: 'Một từ khóa bí mật về cách học cùng AI đang bị khóa trong rương báu. Trả lời đúng để mở từng mảnh chữ!',
    how: ['Mỗi câu trả lời đúng mở <b>1 mảnh chữ</b> của từ khóa và được <b>+10 điểm</b>.', 'Mỗi câu có <b>30 giây</b>. Sai hoặc hết giờ: mảnh chữ vẫn khóa, chuyển câu tiếp.', 'Hết câu hỏi: đoán từ khóa! Dùng <b>💡 Gợi ý</b> (−5 điểm) nếu cần – luôn giải được.', 'Chế độ 2 đội: thay phiên trả lời, cùng mở chung một rương.'],
    start: (st) => run(st), stop: () => T.stop(),
  });
  let W = null, letters = [], open = [], Q = [], i = 0, sc = [0, 0], log = [], lock = false; const T = timerBar(30, () => answer(-1));
  function run(st) {
    W = pickOne(CIPHER_WORDS); letters = [...W[0]].map((ch, idx) => ({ ch, idx })).filter((x) => x.ch !== ' '); open = []; log = []; sc = [0, 0]; i = 0;
    const lv = (n) => shuffle(MCQ_BANK.filter((q) => q.lv === n)); const mix = [...lv(1), ...lv(2), ...lv(3)]; Q = mix.slice(0, 0); const need = letters.length;
    Q = [...lv(1).slice(0, Math.ceil(need / 3)), ...lv(2).slice(0, Math.ceil(need / 3)), ...lv(3).slice(0, need)].slice(0, need); show();
  }
  function board() {
    const b = el('div', 'cp-board'); const chest = el('div', 'cp-chest', open.length === letters.length ? '🔓' : '🔐'); b.appendChild(chest);
    const word = el('div', 'cp-word'); [...W[0]].forEach((ch, idx) => { if (ch === ' ') { word.appendChild(el('span', 'cp-gap')); return; } const isOpen = open.includes(idx); word.appendChild(el('span', 'cp-l' + (isOpen ? ' on' : ''), isOpen ? ch : '?')); });
    b.appendChild(word); b.appendChild(el('div', 'cp-hint', `🗝️ Gợi ý: ${W[1]} · Đã mở ${open.length}/${letters.length} mảnh`)); return b;
  }
  function show() {
    const st = S.st, turn = st.mode === 'team' ? i % 2 : 0, q = Q[i]; lock = false; S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Câu ${i + 1}/${Q.length}</span>`));
    S.body.innerHTML = ''; S.body.appendChild(board()); S.body.appendChild(T.el);
    const card = el('div', 'mc-card'); if (st.mode === 'team') card.appendChild(el('div', 'tf-turn', `Lượt của ${TEAMS[turn].e} ${TEAMS[turn].n}`)); card.appendChild(el('p', 'mc-q', q.q));
    const opts = el('div', 'mc-opts'); shuffle(q.o.map((t, k) => ({ t, k }))).forEach((o, n) => { const b = el('button', 'mc-opt', `${'ABC'[n]}. ${o.t}`); b.type = 'button'; b.dataset.k = o.k; b.addEventListener('click', () => answer(o.k, b)); opts.appendChild(b); });
    card.appendChild(opts); S.body.appendChild(card); T.start();
  }
  function answer(k, btn) {
    if (lock) return; lock = true; T.stop(); const st = S.st, turn = st.mode === 'team' ? i % 2 : 0, q = Q[i]; const ok = k === 0;
    S.body.querySelectorAll('.mc-opt').forEach((b) => { b.disabled = true; if (b.dataset.k === '0') b.classList.add('truth'); }); if (btn && !ok) btn.classList.add('wrong');
    log.push({ q: q.q, ok });
    if (ok) { sc[turn] += 10; snd('ok'); gainXP(10, 'cipher'); const lockd = letters.filter((x) => !open.includes(x.idx)); const pickL = pickOne(lockd); open.push(pickL.idx); const nb = board(); S.body.querySelector('.cp-board').replaceWith(nb); const ls = nb.querySelectorAll('.cp-l'); const pos = letters.findIndex((x) => x.idx === pickL.idx); if (ls[pos]) ls[pos].classList.add('pop'); }
    else snd('bad');
    const fb = el('div', 'tf-fb ' + (ok ? 'ok' : 'bad')); fb.innerHTML = `<b>${k === -1 ? '⏰ Hết giờ!' : ok ? '🔓 Mở được 1 mảnh chữ!' : '🔒 Chưa đúng – mảnh chữ vẫn khóa.'}</b> ${esc(q.e)}`;
    const nx = el('button', 'btn btn-primary btn-small', i + 1 < Q.length && open.length < letters.length ? 'Câu tiếp theo →' : '🗝️ Giải mã từ khóa'); nx.type = 'button';
    nx.addEventListener('click', () => { i++; if (i < Q.length && open.length < letters.length) show(); else guess(); }); fb.appendChild(nx); S.body.appendChild(fb);
    S.setScore(scoreHTML(st, sc, turn, `<span class="gs-prog">Câu ${i + 1}/${Q.length}</span>`));
  }
  function guess() {
    const st = S.st; S.body.innerHTML = ''; S.body.appendChild(board());
    const g = el('div', 'cp-guess'); g.appendChild(el('p', '', open.length === letters.length ? '🎉 Bạn đã mở hết các mảnh! Gõ lại từ khóa để mở rương nhé:' : 'Đoán từ khóa bí mật (có thể gõ không dấu):'));
    const f = el('form', 'cp-form'); const inp2 = el('input'); inp2.placeholder = 'Nhập từ khóa…'; inp2.autocomplete = 'off'; const ck = el('button', 'btn btn-primary btn-small', '🔑 Mở rương'); ck.type = 'submit';
    const hint = el('button', 'btn btn-outline btn-small', '💡 Gợi ý (−5)'); hint.type = 'button'; const lg = el('details', 'gs-ans'); lg.appendChild(el('summary', '', '📜 Nhật ký khóa')); log.forEach((x, n) => lg.appendChild(el('p', '', `${x.ok ? '✅' : '❌'} Câu ${n + 1}: ${x.q}`)));
    hint.addEventListener('click', () => { const lk = letters.filter((x) => !open.includes(x.idx)); if (!lk.length) { toast('Đã mở hết rồi – gõ từ khóa thôi!'); return; } open.push(lk[0].idx); sc[0] = Math.max(0, sc[0] - 5); S.body.querySelector('.cp-board').replaceWith(board()); snd('pick'); });
    f.addEventListener('submit', (e) => { e.preventDefault(); if (plain(inp2.value) === plain(W[0])) { open = letters.map((x) => x.idx); const bonus = 20; sc[0] += bonus; gainXP(20, 'cipher'); bumpDay('blocks', 2); const P = player(); P.games++; savePlayer(P);
      S.finish(`<div class="gs-big">🔓💰</div><h3>Giải mã thành công: “${W[0]}”</h3><p>${W[1]}.</p><p>${st.mode === 'team' ? teamResult(sc) : `<span class="gs-pt">${sc[0]} điểm</span>`}</p>`); }
      else { snd('bad'); inp2.classList.add('shake'); setTimeout(() => inp2.classList.remove('shake'), 450); toast('Chưa đúng rồi! Dùng 💡 Gợi ý để mở thêm mảnh chữ nhé.'); } });
    f.append(inp2, ck, hint); g.append(f, lg); S.body.appendChild(g); inp2.focus();
  }
} };

/* =====================================================================
   5) VƯỢT CHƯỚNG NGẠI VẬT
   ===================================================================== */
const RACE_THEMES = {
  space: { n: '🚀 Vũ trụ', hero: '🧑‍🚀', obs: ['🌑', '☄️', '🛸', '🪐', '🌌', '🛰️', '🌠', '🌕'], goal: '🏁', bg: 'linear-gradient(160deg,#1b1450,#3b2a8f 55%,#7b3fa0)' },
  forest: { n: '🌳 Rừng xanh', hero: '🧒', obs: ['🌵', '🪨', '🍄', '🐻', '🌲', '🦊', '🌉', '🐝'], goal: '🏕️', bg: 'linear-gradient(160deg,#0f5a3f,#22a06b 55%,#9bd86b)' },
  ocean: { n: '🌊 Đại dương', hero: '🤿', obs: ['🦀', '🪸', '🐙', '🦈', '🐡', '🐚', '🌀', '🐋'], goal: '🏝️', bg: 'linear-gradient(160deg,#0b3d78,#1f86d9 55%,#5fd0e8)' },
  treasure: { n: '💰 Kho báu', hero: '🤠', obs: ['🗝️', '🧭', '🕸️', '🐍', '🗿', '⚱️', '🏺', '🦂'], goal: '💰', bg: 'linear-gradient(160deg,#6b3b0e,#c77a1d 55%,#f5c451)' },
};
const Race = { init() {
  const S = gShell($('gRace'), {
    emoji: '🏁', title: 'Vượt chướng ngại vật', sub: 'Đưa nhân vật vượt 8 chướng ngại vật để về đích! Câu hỏi khó dần theo từng chặng.',
    how: ['Mỗi chướng ngại vật là <b>1 câu hỏi</b> (30 giây), độ khó tăng dần.', 'Trả lời đúng: nhân vật <b>tiến lên 1 chặng</b>, <b>+10 điểm</b> (thêm điểm nếu trả lời nhanh).', 'Trả lời sai: xem giải thích, nhân vật đứng yên, sang thử thách tiếp theo.', 'Chế độ 2 đội: hai nhân vật chạy song song, thay phiên trả lời – ai xa hơn thắng!'],
    extra: { label: 'Bản đồ:', def: 'space', items: Object.entries(RACE_THEMES).map(([k, v]) => [k, v.n]) },
    start: (st) => run(st), stop: () => T.stop(),
  });
  const N = 8; let th = null, Q = [], i = 0, pos = [0, 0], sc = [0, 0], lock = false; const T = timerBar(30, () => answer(-1));
  function run(st) {
    th = RACE_THEMES[st.extra] || RACE_THEMES.space; pos = [0, 0]; sc = [0, 0]; i = 0; const teams = st.mode === 'team' ? 2 : 1;
    const lv = (n) => shuffle(MCQ_BANK.filter((q) => q.lv === n)); const a = lv(1), b = lv(2), c = lv(3); const per = (arr, n) => arr.splice(0, n);
    const qs = []; for (let t = 0; t < teams; t++) qs.push([...per(a, 3), ...per(b, 3), ...per(c, 2)]);
    Q = []; for (let k = 0; k < N; k++) for (let t = 0; t < teams; t++) Q.push({ ...qs[t][k], team: t, step: k }); show();
  }
  function map() {
    const st = S.st; const m = el('div', 'rc-map'); m.style.background = th.bg;
    const lanes = st.mode === 'team' ? 2 : 1;
    for (let t = 0; t < lanes; t++) {
      const lane = el('div', 'rc-lane'); if (lanes > 1) lane.appendChild(el('span', 'rc-team', TEAMS[t].e));
      const track = el('div', 'rc-track'); const nodes = ['🚩', ...th.obs.slice(0, N), th.goal];
      nodes.forEach((e2, n) => { const nd = el('div', 'rc-node' + (n === 0 ? ' start' : n === N + 1 ? ' goal' : '') + (n <= pos[t] ? ' passed' : ''), e2); track.appendChild(nd); });
      const hero = el('div', 'rc-hero', th.hero); hero.style.setProperty('--p', pos[t]); hero.style.setProperty('--n', N + 1); if (lanes > 1) hero.style.filter = `drop-shadow(0 0 6px ${TEAMS[t].c})`; track.appendChild(hero);
      lane.appendChild(track); m.appendChild(lane);
    }
    return m;
  }
  function show() {
    const st = S.st, q = Q[i], turn = q.team; lock = false;
    S.setScore(scoreHTML(st, sc, st.mode === 'team' ? turn : 0, `<span class="gs-prog">Chặng ${q.step + 1}/${N} · ${['', 'Dễ', 'Vừa', 'Khó'][q.lv]}</span>`));
    S.body.innerHTML = ''; S.body.appendChild(map()); S.body.appendChild(T.el);
    const card = el('div', 'mc-card'); if (st.mode === 'team') card.appendChild(el('div', 'tf-turn', `Lượt của ${TEAMS[turn].e} ${TEAMS[turn].n}`)); card.appendChild(el('p', 'mc-q', `${th.obs[q.step]} ${q.q}`));
    const opts = el('div', 'mc-opts'); shuffle(q.o.map((t, k) => ({ t, k }))).forEach((o, n) => { const b = el('button', 'mc-opt', `${'ABC'[n]}. ${o.t}`); b.type = 'button'; b.dataset.k = o.k; b.addEventListener('click', () => answer(o.k, b)); opts.appendChild(b); });
    card.appendChild(opts); S.body.appendChild(card); T.start();
  }
  function answer(k, btn) {
    if (lock) return; lock = true; T.stop(); const st = S.st, q = Q[i], t = q.team; const ok = k === 0;
    S.body.querySelectorAll('.mc-opt').forEach((b) => { b.disabled = true; if (b.dataset.k === '0') b.classList.add('truth'); }); if (btn && !ok) btn.classList.add('wrong');
    if (ok) { pos[t]++; const bonus = Math.round(T.left() / 6); sc[t] += 10 + bonus; snd('ok'); gainXP(10, 'race'); const nm = map(); S.body.querySelector('.rc-map').replaceWith(nm); } else snd('bad');
    const fb = el('div', 'tf-fb ' + (ok ? 'ok' : 'bad')); fb.innerHTML = `<b>${k === -1 ? '⏰ Hết giờ! Nhân vật đứng yên.' : ok ? '🏃 Vượt chướng ngại vật thành công!' : '🧱 Chưa vượt được – cố lên ở chặng sau!'}</b> ${esc(q.e)}`;
    const nx = el('button', 'btn btn-primary btn-small', i + 1 < Q.length ? 'Thử thách tiếp theo →' : '🏁 Về đích – xem kết quả'); nx.type = 'button'; nx.addEventListener('click', () => { i++; if (i < Q.length) show(); else end(); });
    fb.appendChild(nx); S.body.appendChild(fb);
  }
  function end() {
    const st = S.st; const P = player(); P.games++; savePlayer(P); if (pos[0] === N) bumpDay('towers', 1);
    let html; if (st.mode === 'team') { const w = pos[0] === pos[1] ? (sc[0] === sc[1] ? -1 : sc[0] > sc[1] ? 0 : 1) : pos[0] > pos[1] ? 0 : 1; html = `<div class="gs-big">${th.goal}</div><h3>Kết thúc cuộc đua!</h3><p>${TEAMS[0].e} vượt ${pos[0]}/${N} chặng · ${TEAMS[1].e} vượt ${pos[1]}/${N} chặng</p><p>${w < 0 ? '🤝 Hai đội hòa nhau!' : `🏆 <b>${TEAMS[w].e} ${TEAMS[w].n}</b> chiến thắng!`}</p>`; }
    else html = `<div class="gs-big">${pos[0] === N ? '🏆' + th.goal : th.hero}</div><h3>${pos[0] === N ? 'Về đích trọn vẹn! Chúc mừng bạn!' : `Bạn vượt được ${pos[0]}/${N} chướng ngại vật`}</h3><p class="gs-pt">${sc[0]} điểm</p><p>${praiseFor(pos[0] / N)}</p>`;
    S.finish(html);
  }
} };

function initGames2() { [Arena, Drag, Match, Cipher, Race].forEach((g) => { try { g.init(); } catch (e) { console.error(e); } }); }
initGames2();

})();
